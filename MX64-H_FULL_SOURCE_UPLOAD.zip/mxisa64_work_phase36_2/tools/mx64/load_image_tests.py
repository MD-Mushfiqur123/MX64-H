#!/usr/bin/env python3
"""Tests for the software-only platform-aware MX64-H ELF loader model."""
from pathlib import Path
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from elf64 import make_executable_segments
from boot_image import make_boot_image
from load_image import load_image

profile = {
    "profile_version": 1,
    "platform": "fpga",
    "status": "test_fixture",
    "board": {"vendor": "test", "part": "test-board", "clock_hz": 50000000, "toolchain": "test-flow"},
    "cpu": {"paddr_bits": 32, "reset_vector": 0},
    "boot": {"image_platform_id": 1, "boot_source": "qspi", "rom_size_bytes": 65536},
    "memory_map": [
        {"name": "boot_rom", "base": 0, "size": 0x10000, "permissions": "rx", "kind": "rom"},
        {"name": "main_ram", "base": 0x10000, "size": 0x20000, "permissions": "rwx", "kind": "ram"},
        {"name": "mmio", "base": 0xF0000000, "size": 0x100000, "permissions": "rw", "kind": "mmio"},
    ],
}

elf = make_executable_segments(
    b"\x13\x00\x00\x00", b"ABC", 33, entry=0x10000, base=0x10000,
    data_base=0x11000, data_align=8, bss_align=64,
)
container = make_boot_image(elf, "fpga")
loaded = load_image(container, profile)
assert loaded["platform"] == "fpga" and loaded["entry"] == 0x10000
assert len(loaded["segments"]) == 2
rx, rw = loaded["segments"]
assert rx["permissions"] == "rx" and rx["memory"] == b"\x13\x00\x00\x00"
assert rw["permissions"] == "rw" and rw["file_size"] == 3
assert rw["zero_fill_size"] == rw["memory_size"] - 3
assert rw["memory"][:3] == b"ABC"
assert rw["memory"][3:] == bytes(rw["zero_fill_size"])

# Generic images require an explicit caller policy.
generic = make_boot_image(elf, "generic")
try:
    load_image(generic, profile)
except ValueError as exc:
    assert "allow_generic" in str(exc)
else:
    raise AssertionError("generic image accepted without explicit policy")
assert load_image(generic, profile, allow_generic=True)["entry"] == 0x10000

# Wrong platform ID is rejected.
asic = make_boot_image(elf, "asic")
try:
    load_image(asic, profile)
except ValueError as exc:
    assert "does not match" in str(exc)
else:
    raise AssertionError("wrong platform image accepted")

# Physical destination in MMIO is rejected even when it is otherwise in range.
mmio_elf = make_executable_segments(
    b"\x13\x00\x00\x00", b"DATA", 0, entry=0x10000, base=0x10000,
    data_base=0xF0000000,
)
try:
    load_image(make_boot_image(mmio_elf, "fpga"), profile)
except ValueError as exc:
    assert "MMIO" in str(exc)
else:
    raise AssertionError("PT_LOAD into MMIO accepted")

# Physical address width and memory-region bounds are enforced.
outside_profile = json.loads(json.dumps(profile))
outside_profile["memory_map"][1]["size"] = 0x100
try:
    load_image(container, outside_profile)
except ValueError as exc:
    assert "outside every configured" in str(exc)
else:
    raise AssertionError("out-of-region load accepted")

print("PASS: platform-aware loader preflight, segment permissions, RAM/ROM/MMIO, address bounds and BSS zero-fill")
