#!/usr/bin/env python3
"""Two-pass MXISA-64 assembler with labels and flat binary output.

Branch/JAL label displacements are signed instruction-word offsets from the
current instruction PC, matching the current reference-model proposal.
"""
from __future__ import annotations
import argparse
import re
from pathlib import Path
from encode import encode, decode

REG = re.compile(r"^[xX](\d+)$")
MEM = re.compile(r"^(.+)\((x\d+)\)$", re.I)

def parse_reg(token):
    m = REG.match(token.strip())
    if not m:
        raise ValueError(f"expected register x0..x31, got {token!r}")
    n = int(m.group(1))
    if not 0 <= n < 32:
        raise ValueError(f"register out of range: {token}")
    return n

def parse_num(token):
    return int(token, 0)

def split_operands(text):
    # Commas delimit operands; commas inside expressions are not supported.
    return [x.strip() for x in text.split(",") if x.strip()]

def clean_lines(source):
    result = []
    for line_no, raw in enumerate(source.splitlines(), 1):
        line = raw.split("#", 1)[0].split(";", 1)[0].strip()
        if line:
            result.append((line_no, line))
    return result

def first_pass(lines):
    symbols, statements = {}, []
    pc = 0
    for line_no, line in lines:
        while ":" in line:
            label, rest = line.split(":", 1)
            label = label.strip()
            if not re.match(r"^[A-Za-z_.$][\w.$]*$", label):
                raise ValueError(f"line {line_no}: invalid label {label!r}")
            if label in symbols:
                raise ValueError(f"line {line_no}: duplicate label {label}")
            symbols[label] = pc
            line = rest.strip()
            if not line:
                break
        if not line:
            continue
        if line.lower().startswith((".extern", ".global")):
            continue
        if line.lower().startswith(".org"):
            raise ValueError(f"line {line_no}: .org is not supported in flat binary mode")
        if line.lower().startswith(".word"):
            args = split_operands(line[5:].strip())
            if len(args) != 1:
                raise ValueError(f"line {line_no}: .word expects one value")
            size = 4
        elif line.lower().startswith(".space"):
            args = split_operands(line[6:].strip())
            if len(args) != 1 or parse_num(args[0]) < 0:
                raise ValueError(f"line {line_no}: .space expects a non-negative byte count")
            size = parse_num(args[0])
        else:
            size = 4
        statements.append((line_no, pc, line))
        pc += size
    return symbols, statements, pc

def assemble(source):
    lines = clean_lines(source)
    symbols, statements, total = first_pass(lines)
    output = bytearray()
    for line_no, pc, line in statements:
        try:
            lower = line.lower()
            if lower.startswith(".space"):
                n = parse_num(split_operands(line[6:].strip())[0])
                output.extend(b"\0" * n)
                continue
            if lower.startswith(".word"):
                token = split_operands(line[5:].strip())[0]
                value = symbols[token] if token in symbols else parse_num(token)
                if not -(1 << 31) <= value < (1 << 32):
                    raise ValueError(".word value outside 32-bit range")
                output.extend((value & 0xffffffff).to_bytes(4, "little"))
                continue
            pieces = line.split(None, 1)
            op = pieces[0].upper()
            args = split_operands(pieces[1]) if len(pieces) > 1 else []
            if op in ("BEQ","BNE","BLT","BGE","BLTU","BGEU") and len(args) == 3 and args[2] in symbols:
                target = symbols[args[2]]
                delta = target - pc
                if delta % 4:
                    raise ValueError("branch target is not instruction-aligned")
                args[2] = str(delta // 4)
            elif op == "JAL" and len(args) == 1 and args[0] in symbols:
                delta = symbols[args[0]] - pc
                if delta % 4:
                    raise ValueError("jump target is not instruction-aligned")
                args[0] = str(delta // 4)
            if op in ("LB","LBU","LH","LHU","LW","LWU","LD","JALR","SB","SH","SW","SD") and len(args) == 2:
                m = MEM.match(args[1])
                if m:
                    args = [args[0], m.group(2), m.group(1)]
            word = encode(op, *args)
            output.extend(word.to_bytes(4, "little"))
        except Exception as e:
            raise ValueError(f"line {line_no}, PC 0x{pc:x}: {e}") from e
    assert len(output) == total
    return bytes(output), symbols


def assemble_relocatable_source(source):
    """Assemble source to .text plus unresolved PC-relative relocations."""
    lines = clean_lines(source)
    externs, globals_ = set(), set()
    filtered = []
    for line_no, line in lines:
        low = line.lower()
        if low.startswith(".extern") or low.startswith(".global"):
            directive, _, rest = line.partition(" ")
            names = [x.strip() for x in rest.split(",") if x.strip()]
            if not names:
                raise ValueError(f"line {line_no}: {directive} requires symbol names")
            for name in names:
                if not re.match(r"^[A-Za-z_.$][\w.$]*$", name):
                    raise ValueError(f"line {line_no}: invalid symbol {name!r}")
                (externs if directive.lower()==".extern" else globals_).add(name)
            continue
        filtered.append((line_no,line))
    symbols, statements, total = first_pass(filtered)
    conflict = externs & set(symbols)
    if conflict:
        raise ValueError(f"symbols both defined and external: {sorted(conflict)}")
    output=bytearray()
    relocs=[]
    for line_no,pc,line in statements:
        try:
            low=line.lower()
            if low.startswith(".space"):
                n=parse_num(split_operands(line[6:].strip())[0])
                output.extend(bytes(n)); continue
            if low.startswith(".word"):
                token=split_operands(line[5:].strip())[0]
                if token in externs:
                    relocs.append((pc,token,3,0))
                    output.extend(bytes(4)); continue
                value=symbols[token] if token in symbols else parse_num(token)
                if not -(1<<31)<=value<(1<<32): raise ValueError(".word outside 32-bit range")
                output.extend((value&0xffffffff).to_bytes(4,"little")); continue
            pieces=line.split(None,1); op=pieces[0].upper()
            args=split_operands(pieces[1]) if len(pieces)>1 else []
            if op in ("BEQ","BNE","BLT","BGE","BLTU","BGEU") and len(args)==3:
                target=args[2]
                if target in externs:
                    relocs.append((pc,target,1,0)); args[2]="0"
                elif target in symbols:
                    delta=symbols[target]-pc
                    if delta%4: raise ValueError("branch target not instruction-aligned")
                    args[2]=str(delta//4)
                elif re.match(r"^[A-Za-z_.$]",target):
                    raise ValueError(f"undefined symbol {target}; declare .extern")
            elif op=="JAL" and len(args)==1:
                target=args[0]
                if target in externs:
                    relocs.append((pc,target,2,0)); args[0]="0"
                elif target in symbols:
                    delta=symbols[target]-pc
                    if delta%4: raise ValueError("jump target not instruction-aligned")
                    args[0]=str(delta//4)
                elif re.match(r"^[A-Za-z_.$]",target):
                    raise ValueError(f"undefined symbol {target}; declare .extern")
            if op in ("LB","LBU","LH","LHU","LW","LWU","LD","JALR","SB","SH","SW","SD") and len(args)==2:
                m=MEM.match(args[1])
                if m: args=[args[0],m.group(2),m.group(1)]
            output.extend(encode(op,*args).to_bytes(4,"little"))
        except Exception as e:
            raise ValueError(f"line {line_no}, PC 0x{pc:x}: {e}") from e
    assert len(output)==total
    for name in globals_:
        if name not in symbols: raise ValueError(f".global symbol not defined: {name}")
    return bytes(output), symbols, sorted(externs), relocs

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--symbols", help="optional symbol map output")
    ap.add_argument("--listing", help="optional disassembly listing")
    ns = ap.parse_args()
    data, symbols = assemble(Path(ns.input).read_text(encoding="utf-8"))
    Path(ns.output).write_bytes(data)
    if ns.symbols:
        Path(ns.symbols).write_text("".join(f"{name} = 0x{addr:08x}\n" for name, addr in sorted(symbols.items())), encoding="utf-8")
    if ns.listing:
        rows = []
        for pc in range(0, len(data), 4):
            word = int.from_bytes(data[pc:pc+4], "little")
            rows.append(f"{pc:08x}: {word:08x}  {decode(word)}")
        Path(ns.listing).write_text("\n".join(rows) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()


def assemble_multisection_source(source):
    """Assemble a conservative multi-section source subset for ELF linking.

    Supported sections: .text, .data, .bss.  `.align` takes a byte
    alignment (power of two); `.space`/`.zero`, `.byte`, `.word`, and `.quad`
    are supported in data sections.  Instructions are accepted only in .text.
    Returns (sections, definitions, undefined, relocations).  A definition is
    {name: {"section": section_name, "value": section_offset}} and a
    relocation is (section_name, offset, symbol, type, addend).
    """
    section_order = (".text", ".data", ".bss")
    buffers = {name: bytearray() for name in section_order}
    sizes = {name: 0 for name in section_order}
    aligns = {name: (4 if name == ".text" else 8 if name == ".data" else 1)
              for name in section_order}
    current = ".text"
    symbols = {}
    externs, globals_ = set(), set()
    statements = []

    def reserve(section, count, line_no):
        if count < 0:
            raise ValueError(f"line {line_no}: negative size")
        start = sizes[section]
        sizes[section] += count
        return start

    def parse_directive(line_no, line):
        nonlocal current
        lower = line.lower()
        if lower in (".text", ".data", ".bss"):
            current = lower
            return True
        if lower.startswith(".section"):
            parts = split_operands(line[len(".section"):].strip())
            if len(parts) != 1 or parts[0] not in section_order:
                raise ValueError(f"line {line_no}: only .text, .data and .bss sections are supported")
            current = parts[0]
            return True
        if lower.startswith(".global") or lower.startswith(".extern"):
            directive, _, rest = line.partition(" ")
            names = [x.strip() for x in rest.split(",") if x.strip()]
            if not names:
                raise ValueError(f"line {line_no}: {directive} requires symbol names")
            for name in names:
                if not re.match(r"^[A-Za-z_.$][\w.$]*$", name):
                    raise ValueError(f"line {line_no}: invalid symbol {name!r}")
                (globals_ if directive.lower() == ".global" else externs).add(name)
            return True
        return False

    # Pass 1: determine section-relative labels and reserve all emitted sizes.
    for line_no, raw in clean_lines(source):
        line = raw
        while ":" in line:
            label, rest = line.split(":", 1)
            label = label.strip()
            if not re.match(r"^[A-Za-z_.$][\w.$]*$", label):
                raise ValueError(f"line {line_no}: invalid label {label!r}")
            if label in symbols:
                raise ValueError(f"line {line_no}: duplicate label {label}")
            symbols[label] = {"section": current, "value": sizes[current]}
            line = rest.strip()
            if not line:
                break
        if not line:
            continue
        if parse_directive(line_no, line):
            continue
        lower = line.lower()
        if lower.startswith(".align"):
            args = split_operands(line[6:].strip())
            if len(args) != 1:
                raise ValueError(f"line {line_no}: .align expects one byte alignment")
            boundary = parse_num(args[0])
            if boundary <= 0 or boundary & (boundary - 1) or boundary > 4096:
                raise ValueError(f"line {line_no}: .align must be a power of two no larger than 4096")
            aligns[current] = max(aligns[current], boundary)
            before = sizes[current]
            padding = (-before) % boundary
            reserve(current, padding, line_no)
            statements.append((line_no, current, before, "ALIGN", padding))
            continue
        if lower.startswith(".space") or lower.startswith(".zero"):
            directive = ".space" if lower.startswith(".space") else ".zero"
            args = split_operands(line[len(directive):].strip())
            if len(args) != 1:
                raise ValueError(f"line {line_no}: {directive} expects one byte count")
            count = parse_num(args[0])
            offset = reserve(current, count, line_no)
            statements.append((line_no, current, offset, directive.upper(), count))
            continue
        if lower.startswith(".byte") or lower.startswith(".word") or lower.startswith(".quad"):
            directive = next(x for x in (".byte", ".word", ".quad") if lower.startswith(x))
            args = split_operands(line[len(directive):].strip())
            if not args:
                raise ValueError(f"line {line_no}: {directive} expects at least one value")
            width = {".byte": 1, ".word": 4, ".quad": 8}[directive]
            if current == ".bss":
                raise ValueError(f"line {line_no}: initialized data is not allowed in .bss")
            offset = reserve(current, len(args) * width, line_no)
            statements.append((line_no, current, offset, directive.upper(), args))
            continue
        if current != ".text":
            raise ValueError(f"line {line_no}: instructions are only allowed in .text")
        offset = reserve(current, 4, line_no)
        statements.append((line_no, current, offset, "INSTRUCTION", line))

    conflict = externs & set(symbols)
    if conflict:
        raise ValueError(f"symbols both defined and external: {sorted(conflict)}")
    for name in globals_:
        if name not in symbols:
            raise ValueError(f".global symbol not defined: {name}")
    for name, definition in symbols.items():
        if definition["section"] == ".bss":
            continue

    relocations = []
    for line_no, section, offset, kind, payload in statements:
        if section == ".bss":
            continue
        try:
            if kind in ("ALIGN", "SPACE", "ZERO"):
                buffers[section].extend(bytes(payload))
                continue
            if kind in (".BYTE", ".WORD", ".QUAD"):
                width = {".BYTE": 1, ".WORD": 4, ".QUAD": 8}[kind]
                for index, token in enumerate(payload):
                    at = offset + index * width
                    if token in symbols or token in externs:
                        if width == 1:
                            raise ValueError("symbol relocations are not supported for .byte")
                        reloc_type = 3 if width == 4 else 4
                        relocations.append((section, at, token, reloc_type, 0))
                        buffers[section].extend(bytes(width))
                    else:
                        value = parse_num(token)
                        if not -(1 << (width * 8 - 1)) <= value < (1 << (width * 8)):
                            raise ValueError(f"{kind} value outside {width * 8}-bit range")
                        buffers[section].extend((value & ((1 << (width * 8)) - 1)).to_bytes(width, "little"))
                continue
            if kind == "INSTRUCTION":
                line = payload
                pieces = line.split(None, 1)
                op = pieces[0].upper()
                args = split_operands(pieces[1]) if len(pieces) > 1 else []
                if op in ("BEQ", "BNE", "BLT", "BGE", "BLTU", "BGEU") and len(args) == 3:
                    target = args[2]
                    if target in symbols:
                        target_def = symbols[target]
                        if target_def["section"] != ".text":
                            raise ValueError("branch target must be in .text")
                        delta = target_def["value"] - offset
                        if delta % 4:
                            raise ValueError("branch target is not instruction-aligned")
                        args[2] = str(delta // 4)
                    elif target in externs:
                        relocations.append((section, offset, target, 1, 0))
                        args[2] = "0"
                    elif re.match(r"^[A-Za-z_.$]", target):
                        raise ValueError(f"undefined symbol {target}; declare .extern")
                elif op == "JAL" and len(args) == 1:
                    target = args[0]
                    if target in symbols:
                        target_def = symbols[target]
                        if target_def["section"] != ".text":
                            raise ValueError("JAL target must be in .text")
                        delta = target_def["value"] - offset
                        if delta % 4:
                            raise ValueError("jump target is not instruction-aligned")
                        args[0] = str(delta // 4)
                    elif target in externs:
                        relocations.append((section, offset, target, 2, 0))
                        args[0] = "0"
                    elif re.match(r"^[A-Za-z_.$]", target):
                        raise ValueError(f"undefined symbol {target}; declare .extern")
                if op in ("LB", "LBU", "LH", "LHU", "LW", "LWU", "LD", "JALR", "SB", "SH", "SW", "SD") and len(args) == 2:
                    m = MEM.match(args[1])
                    if m:
                        args = [args[0], m.group(2), m.group(1)]
                buffers[section].extend(encode(op, *args).to_bytes(4, "little"))
        except Exception as exc:
            raise ValueError(f"line {line_no}, section {section}, offset 0x{offset:x}: {exc}") from exc

    # The source layout is emitted in statement order per section; check sizes
    # and use zero fill for gaps created by alignment.
    out_sections = {}
    for name in section_order:
        if name == ".bss":
            out_sections[name] = {"data": b"", "size": sizes[name], "align": aligns[name], "nobits": True}
            continue
        data = buffers[name]
        if len(data) > sizes[name]:
            raise AssertionError(f"internal assembler size overflow in {name}")
        data.extend(bytes(sizes[name] - len(data)))
        out_sections[name] = {"data": bytes(data), "size": sizes[name], "align": aligns[name], "nobits": False}
    defs = {name: {**value, "global": name in globals_} for name, value in symbols.items()}
    return out_sections, defs, sorted(externs), relocations
