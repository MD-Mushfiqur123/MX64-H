#!/usr/bin/env python3
"""Reference model for validating and loading an MX64-H boot image in memory."""
from __future__ import annotations
import json
from pathlib import Path

from boot_image import parse_boot_image, PLATFORM_NAMES
from elf64 import PT_LOAD, PF_R, PF_W, PF_X
from platform_check import validate_profile

DEFAULT_MAX_LOAD_BYTES = 64 * 1024 * 1024


def load_image(container: bytes, profile: dict, *, allow_generic: bool = False,
               max_load_bytes: int = DEFAULT_MAX_LOAD_BYTES) -> dict:
    """Preflight all segments, then return memory images with BSS zero-filled.

    This is a software reference model, not a hardware bootloader.  It models
    physical placement using p_paddr and does not perform device writes.
    """
    errors = validate_profile(profile, require_complete=True)
    if errors:
        raise ValueError("invalid/incomplete platform profile: " + "; ".join(errors))
    if not isinstance(max_load_bytes, int) or isinstance(max_load_bytes, bool) or max_load_bytes <= 0:
        raise ValueError("max_load_bytes must be a positive integer")

    image = parse_boot_image(container)
    platform = profile["platform"]
    image_platform = image["platform"]
    if image_platform == "generic":
        if not allow_generic:
            raise ValueError("generic boot images require explicit allow_generic policy")
    elif image_platform != platform:
        raise ValueError(f"image platform {image_platform} does not match target {platform}")

    paddr_bits = profile["cpu"]["paddr_bits"]
    regions = profile["memory_map"]
    load_headers = [ph for ph in image["elf"]["program_headers"] if ph["type"] == PT_LOAD]
    if not load_headers:
        raise ValueError("ELF has no loadable segments")

    # Preflight *every* destination before allocating/copying any segment.
    planned = []
    total_memory = 0
    for index, ph in enumerate(load_headers):
        destination = ph["paddr"]
        size = ph["memsz"]
        if destination + size > (1 << paddr_bits):
            raise ValueError(f"PT_LOAD[{index}] exceeds configured physical address width")
        if destination + size > (1 << 64):
            raise ValueError(f"PT_LOAD[{index}] physical range overflows")
        region = next((r for r in regions
                       if r["base"] <= destination and destination + size <= r["base"] + r["size"]), None)
        if region is None:
            raise ValueError(f"PT_LOAD[{index}] is outside every configured memory region")
        if region["kind"] == "mmio":
            raise ValueError(f"PT_LOAD[{index}] cannot be placed in MMIO")
        required = "".join(ch for bit, ch in ((PF_R, "r"), (PF_W, "w"), (PF_X, "x")) if ph["flags"] & bit)
        if any(ch not in region["permissions"] for ch in required):
            raise ValueError(f"PT_LOAD[{index}] permissions {required!r} exceed region {region['name']!r}")
        if region["kind"] == "rom" and "w" in required:
            raise ValueError(f"PT_LOAD[{index}] writable segment cannot be placed in ROM")
        total_memory += size
        if total_memory > max_load_bytes:
            raise ValueError(f"load image exceeds configured model limit of {max_load_bytes} bytes")
        planned.append((index, ph, region))

    ranges = sorted((ph["paddr"], ph["paddr"] + ph["memsz"], index)
                    for index, ph, _ in planned)
    for previous, current in zip(ranges, ranges[1:]):
        if current[0] < previous[1]:
            raise ValueError(f"PT_LOAD[{previous[2]}] overlaps PT_LOAD[{current[2]}]")

    payload = image["payload"]
    loaded = []
    for index, ph, region in planned:
        file_start = ph["offset"]
        file_end = file_start + ph["filesz"]
        initialized = payload[file_start:file_end]
        memory = bytearray(ph["memsz"])
        memory[:ph["filesz"]] = initialized
        loaded.append({
            "index": index,
            "physical_address": ph["paddr"],
            "virtual_address": ph["vaddr"],
            "file_size": ph["filesz"],
            "memory_size": ph["memsz"],
            "zero_fill_size": ph["memsz"] - ph["filesz"],
            "permissions": "".join(ch for bit, ch in ((PF_R, "r"), (PF_W, "w"), (PF_X, "x")) if ph["flags"] & bit),
            "region": region["name"],
            "memory": bytes(memory),
        })
    return {
        "platform": platform,
        "entry": image["entry"],
        "segments": loaded,
        "total_memory": total_memory,
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image")
    parser.add_argument("profile")
    parser.add_argument("--allow-generic", action="store_true")
    args = parser.parse_args()
    try:
        profile = json.loads(Path(args.profile).read_text(encoding="utf-8"))
        result = load_image(Path(args.image).read_bytes(), profile,
                            allow_generic=args.allow_generic)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        raise SystemExit(f"FAIL: {exc}")
    summary = {key: value for key, value in result.items() if key != "segments"}
    summary["segments"] = [{key: value for key, value in segment.items() if key != "memory"}
                           for segment in result["segments"]]
    import json as _json
    print(_json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
