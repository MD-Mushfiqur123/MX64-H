#!/usr/bin/env python3
"""Static ISA-table/encoder consistency audit; does not execute HDL."""
from pathlib import Path
import csv, sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from encode import OPS, encode, decode

root = Path(__file__).resolve().parents[2]
rows = list(csv.DictReader((root/"docs/isa/MXISA64_OPCODE_TABLE.csv").open(encoding="utf-8")))
assert len(rows) == len(OPS)
assert len({r["operation"] for r in rows}) == len(rows)
assert all(int(r["major"],0) < 64 for r in rows)
# Encoding uniqueness is per major + format + selector.
keys = [(int(r["major"],0), r["format"], int(r["minor"],0)) for r in rows]
assert len(set(keys)) == len(keys), "duplicate major/format/minor selector"
assert all((r["format"] == "R" and int(r["minor"]) < 64) or
           (r["format"] in ("I","S","B") and int(r["minor"]) < 16) or
           (r["format"] == "U" and int(r["minor"]) < 16) or
           r["format"] == "J" for r in rows)
# Validate canonical no-operand and register-register encodings.
for op in ("NOP","HALT","ECALL","EBREAK","MRET","FENCE","FENCE.I"):
    word = encode(op)
    assert decode(word) == op, (op, hex(word), decode(word))
for op in ("ADD","SUB","AND","OR","XOR","NOR","SLT","SLTU",
           "SLL","SRL","SRA","MUL","MULH","MULHU","DIV","DIVU","REM","REMU"):
    word = encode(op, 7, 8, 9)
    assert decode(word) == f"{op} x7, x8, x9", (op, decode(word))
for op, args in [
    ("ADDI",(3,4,-17)),("LD",(3,4,24)),("SD",(3,4,-8)),
    ("BEQ",(4,5,-12)),("JAL",(120,)),("JALR",(1,2,16)),
    ("LUI",(9,12)),("AUIPC",(10,-3))
]:
    word = encode(op,*args)
    assert decode(word).startswith(op+" "), (op, hex(word), decode(word))
print(f"PASS: {len(rows)} opcode rows loaded; encoder/decoder canonical round-trips passed")
print("NOTE: this is static software validation, not ISA freeze or HDL verification.")
