#!/usr/bin/env python3
from pathlib import Path
import sys,tempfile
sys.path.insert(0,str(Path(__file__).resolve().parent))
from assembler import assemble, assemble_relocatable_source
from elf64 import parse_elf, make_relocatable, ET_REL, ET_EXEC
from mxld import link
from encode import decode

a_text,a_defs,a_undef,a_rel=assemble_relocatable_source("""
.global entry
entry: ADDI x1, x0, 1
BNE x1, x0, remote
JAL remote
.word remote
HALT
.extern remote
""")
b_text,b_defs,b_undef,b_rel=assemble_relocatable_source("""
.global remote
remote: ADDI x2, x0, 9
HALT
""")
assert a_undef==["remote"] and len(a_rel)==3
with tempfile.TemporaryDirectory() as d:
    a=Path(d)/"a.o"; b=Path(d)/"b.o"
    a.write_bytes(make_relocatable(a_text,a_defs,a_undef,a_rel))
    b.write_bytes(make_relocatable(b_text,b_defs,b_undef,b_rel))
    parsed=parse_elf(a.read_bytes())
    assert any(s["name"]==".rela.text" for s in parsed["sections"])
    exe=link([a,b],"entry")
    e=parse_elf(exe); assert e["type"]==ET_EXEC and e["entry"]==0x10000
    assert len(e["program_headers"]) == 1
    load=e["program_headers"][0]
    assert load["type"] == 1 and load["flags"] == 5
    assert load["vaddr"] == 0x10000 and load["filesz"] == load["memsz"]
    assert load["align"] == 4096 and load["offset"] % 4096 == 0
    text=next(s["data"] for s in e["sections"] if s["name"]==".text")
    w_branch=int.from_bytes(text[4:8],"little")
    w_jump=int.from_bytes(text[8:12],"little")
    assert (w_branch&0xfff)==4,hex(w_branch) # remote at byte 20, PC=4 => 4 words
    assert (w_jump&0x3ffffff)==3,hex(w_jump) # remote at byte 20, PC=8 => 3 words
    assert int.from_bytes(text[12:16],"little")==0x10014
    assert decode(w_branch).endswith(", 4")
    # Undefined references must be diagnosed.
    bad=Path(d)/"bad.o"
    bad.write_bytes(make_relocatable(a_text,a_defs,a_undef,a_rel))
    try: link([bad],"entry")
    except ValueError as ex: assert "undefined symbol" in str(ex)
    else: raise AssertionError("undefined symbol accepted")
    # Parser rejects a corrupted segment that extends beyond the file.
    broken=bytearray(exe); broken[64+32:64+40]=(len(exe)+4096).to_bytes(8,"little")
    try: parse_elf(bytes(broken))
    except ValueError as ex: assert "program segment" in str(ex)
    else: raise AssertionError("out-of-bounds PT_LOAD accepted")
print("PASS: ELF RELA, cross-object relocations, PT_LOAD executable, segment validation and undefined-symbol diagnostics")
