#!/usr/bin/env python3
"""Regression tests for multi-section assembly, ELF, relocation, and BSS."""
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from assembler import assemble_multisection_source
from elf64 import (
    make_relocatable_sections, parse_elf, ET_REL, ET_EXEC, SHT_NOBITS,
    PT_LOAD, PF_R, PF_W, PF_X, SYM, EHDR, STB_GLOBAL, SHN_UNDEF,
)
from mxld import link

source_a = """
.text
.global _start
.extern worker
_start:
    ADDI x1, x0, 42
    JAL worker
    HALT
.data
.global start_pointer
start_pointer: .quad _start
.word 0x12345678
.bss
.space 3
.align 16
.global scratch
scratch: .space 48
"""
source_b = """
.text
.global worker
worker:
    ADDI x2, x0, 7
    JALR x0, x1, 0
.data
.global data_bytes
data_bytes: .byte 0xaa, 0xbb, 0xcc
.bss
.global extra_buffer
extra_buffer: .space 32
"""

with tempfile.TemporaryDirectory(prefix="mx64h-multisection-") as temp:
    objects = []
    defs_by_object = []
    for index, source in enumerate((source_a, source_b)):
        sections, definitions, undefined, relocations = assemble_multisection_source(source)
        assert set(sections) == {".text", ".data", ".bss"}
        assert sections[".bss"]["nobits"] and not sections[".bss"]["data"]
        assert sections[".bss"]["size"] > 0
        obj_bytes = make_relocatable_sections(sections, definitions, undefined, relocations)
        parsed_obj = parse_elf(obj_bytes)
        assert parsed_obj["type"] == ET_REL
        assert any(s["name"] == ".bss" and s["type"] == SHT_NOBITS for s in parsed_obj["sections"])
        symtab = next(s for s in parsed_obj["sections"] if s["name"] == ".symtab")
        strtab = parsed_obj["sections"][symtab["link"]]
        symbol_names = []
        undefined_worker = []
        for sym_off in range(0, symtab["size"], SYM.size):
            name_off, info, other, shndx, value, size = SYM.unpack_from(symtab["data"], sym_off)
            end = strtab["data"].find(b"\0", name_off)
            name = strtab["data"][name_off:end].decode() if name_off else ""
            if name:
                symbol_names.append(name)
            if name == "worker":
                undefined_worker.append((info >> 4, shndx))
        assert len(symbol_names) == len(set(symbol_names)), "symbol table contains duplicate names"
        if index == 0:
            assert undefined_worker == [(STB_GLOBAL, SHN_UNDEF)]
        # Corrupt relocation symbol index and require parser rejection.
        rela = next((s for s in parsed_obj["sections"] if s["type"] == 4), None)
        if rela is not None:
            malformed = bytearray(obj_bytes)
            malformed[rela["offset"] + 8:rela["offset"] + 16] = (999 << 32).to_bytes(8, "little")
            try:
                parse_elf(bytes(malformed))
            except ValueError as exc:
                assert "symbol index" in str(exc)
            else:
                raise AssertionError("out-of-range relocation symbol index was accepted")
        objects.append(Path(temp) / f"unit{index}.o")
        objects[-1].write_bytes(obj_bytes)
        defs_by_object.append(definitions)

    image = link(objects, "_start")
    exe = parse_elf(image)
    assert exe["type"] == ET_EXEC
    assert exe["entry"] == 0x10000
    loads = [p for p in exe["program_headers"] if p["type"] == PT_LOAD]
    assert len(loads) == 2
    rx = next(p for p in loads if p["flags"] & PF_X)
    rw = next(p for p in loads if p["flags"] & PF_W)
    assert rx["flags"] == PF_R | PF_X
    assert rw["flags"] == PF_R | PF_W
    assert rx["filesz"] == rx["memsz"] == 20
    assert rw["filesz"] == 19 and rw["memsz"] > rw["filesz"]
    assert rw["align"] == 4096
    assert (rx["vaddr"] - rx["offset"]) % rx["align"] == 0
    assert (rw["vaddr"] - rw["offset"]) % rw["align"] == 0

    sections = {s["name"]: s for s in exe["sections"]}
    assert sections[".text"]["offset"] == rx["offset"]
    assert sections[".data"]["offset"] == rw["offset"]
    assert sections[".bss"]["type"] == SHT_NOBITS
    assert sections[".bss"]["size"] == 96
    assert sections[".bss"]["addr"] % 16 == 0
    assert sections[".bss"]["offset"] % sections[".bss"]["align"] == 0
    assert sections[".bss"]["offset"] <= len(image)
    shoff = EHDR.unpack_from(image)[6]
    assert sections[".bss"]["offset"] < shoff, "NOBITS offset overlaps the section-header table"
    # Initialized pointer in .data must resolve to the linked _start address.
    pointer = int.from_bytes(sections[".data"]["data"][:8], "little")
    assert pointer == exe["entry"]
    # Linker must preserve the declared alignment of the first BSS symbol.
    assert (sections[".bss"]["addr"] + 16) % 16 == 0

    # Malformed PT_LOAD sizes and non-power-of-two alignment must be rejected.
    bad = bytearray(image)
    # ELF64 Phdr: p_filesz starts at byte 32; p_memsz starts at byte 40.
    bad[64 + 32:64 + 40] = (rw["memsz"] + 1).to_bytes(8, "little")
    try:
        parse_elf(bytes(bad))
    except ValueError as exc:
        assert "filesz" in str(exc) or "segment" in str(exc)
    else:
        raise AssertionError("filesz greater than memsz was accepted")


print("PASS: multi-section assembly, unique ELF symbols, RELA index bounds, ABS64, RX/RW PT_LOAD, BSS, alignment and ELF bounds")
