#!/usr/bin/env python3
"""Relocation-aware MX64-H static linker for the supported ELF subset."""
import argparse
import struct
from pathlib import Path

from elf64 import (
    parse_elf, make_executable_segments, ET_REL, ET_EXEC, SHT_RELA,
    R_MX64H_BRANCH12, R_MX64H_JUMP26, R_MX64H_ABS32, R_MX64H_ABS64,
    RELA, SYM, STB_GLOBAL, SHN_UNDEF, align,
)

BASE = 0x10000
PAGE = 4096
SECTION_NAMES = (".text", ".data", ".bss")


def _read_object(path):
    obj = parse_elf(Path(path).read_bytes())
    if obj["type"] != ET_REL:
        raise ValueError(f"{path}: expected ET_REL")
    section_by_index = {section["index"]: section for section in obj["sections"]}
    sections = {}
    for name in SECTION_NAMES:
        sec = next((s for s in obj["sections"] if s["name"] == name), None)
        if sec is None:
            continue
        expected_type = 8 if name == ".bss" else 1
        if sec["type"] != expected_type:
            raise ValueError(f"{path}: {name} has invalid ELF section type")
        sections[name] = sec
    symtab = next((s for s in obj["sections"] if s["type"] == 2), None)
    if symtab is None:
        raise ValueError(f"{path}: missing .symtab")
    strtab = section_by_index.get(symtab["link"])
    if strtab is None or strtab["type"] != 3:
        raise ValueError(f"{path}: symbol table has invalid string table link")
    symbols = []
    for off in range(0, len(symtab["data"]), SYM.size):
        no, info, other, shndx, value, size = SYM.unpack_from(symtab["data"], off)
        if no >= len(strtab["data"]):
            raise ValueError(f"{path}: symbol name offset out of range")
        if no:
            end = strtab["data"].find(b"\0", no)
            if end < 0:
                raise ValueError(f"{path}: unterminated symbol name")
            name = strtab["data"][no:end].decode("utf-8")
        else:
            name = ""
        if shndx != SHN_UNDEF and shndx not in section_by_index:
            raise ValueError(f"{path}: symbol {name!r} has invalid section index")
        if shndx != SHN_UNDEF:
            target = section_by_index[shndx]
            if target["name"] not in SECTION_NAMES or value > target["size"]:
                raise ValueError(f"{path}: symbol {name!r} is outside a supported section")
        if (info >> 4) not in (0, STB_GLOBAL):
            raise ValueError(f"{path}: unsupported symbol binding for {name!r}")
        symbols.append(dict(name=name, bind=info >> 4, shndx=shndx, value=value))
    relocations = []
    for relasec in (s for s in obj["sections"] if s["type"] == SHT_RELA):
        target = section_by_index.get(relasec["info"])
        if target is None or target["name"] not in SECTION_NAMES:
            raise ValueError(f"{path}: relocation section targets unsupported section")
        for off in range(0, len(relasec["data"]), RELA.size):
            r_off, r_info, r_add = RELA.unpack_from(relasec["data"], off)
            relocations.append((target["name"], r_off, r_info >> 32,
                                r_info & 0xffffffff, r_add))
    return dict(path=str(path), sections=sections, symbols=symbols, relocations=relocations)


def link(paths, entry_symbol=None):
    """Link objects into page-separated RX and RW PT_LOAD segments."""
    objects = [_read_object(path) for path in paths]
    if not objects:
        raise ValueError("at least one object is required")

    # Lay out each input section in command-line order, honoring section alignment.
    cursors = {name: 0 for name in SECTION_NAMES}
    contributions = []
    for obj in objects:
        placement = {}
        for name in SECTION_NAMES:
            section = obj["sections"].get(name)
            if section is None:
                continue
            alignment = max(1, section["align"])
            cursor = align(cursors[name], alignment)
            placement[name] = cursor
            cursors[name] = cursor + section["size"]
        contributions.append(placement)

    text_size = cursors[".text"]
    data_size = cursors[".data"]
    bss_size = cursors[".bss"]
    data_align = max([obj["sections"][".data"]["align"] for obj in objects
                      if ".data" in obj["sections"]] or [8])
    bss_align = max([obj["sections"][".bss"]["align"] for obj in objects
                     if ".bss" in obj["sections"]] or [8])
    if text_size == 0:
        raise ValueError("linked image has no .text")
    text = bytearray(text_size)
    data = bytearray(data_size)
    output_buffers = {".text": text, ".data": data}
    section_base = {".text": BASE, ".data": align(BASE + text_size, PAGE)}
    bss_base = align(section_base[".data"] + data_size, bss_align)
    section_base[".bss"] = bss_base

    for obj, placement in zip(objects, contributions):
        for name in (".text", ".data"):
            section = obj["sections"].get(name)
            if section is None:
                continue
            start = placement[name]
            output_buffers[name][start:start + section["size"]] = section["data"]

    def resolve_symbol(obj_index, sym_index):
        obj = objects[obj_index]
        if not 0 <= sym_index < len(obj["symbols"]):
            raise ValueError(f"{obj['path']}: relocation symbol index out of range")
        sym = obj["symbols"][sym_index]
        if sym["shndx"] == SHN_UNDEF:
            if not sym["name"] or sym["name"] not in global_defs:
                raise ValueError(f"undefined symbol: {sym['name']}")
            return global_defs[sym["name"]]
        target_section = next((s for s in obj["sections"].values()
                               if s["index"] == sym["shndx"]), None)
        if target_section is None:
            raise ValueError(f"{obj['path']}: symbol {sym['name']} is not in a supported section")
        sec_name = target_section["name"]
        offset = contributions[obj_index][sec_name] + sym["value"]
        sec_limit = cursors[sec_name]
        if sym["value"] > target_section["size"]:
            raise ValueError(f"{obj['path']}: symbol {sym['name']} exceeds its section")
        return section_base[sec_name] + offset

    # Resolve global definitions only after all object tables are available.
    global_defs = {}
    for obj_index, obj in enumerate(objects):
        for sym_index, sym in enumerate(obj["symbols"]):
            if sym["name"] and sym["shndx"] != SHN_UNDEF and sym["bind"] == STB_GLOBAL:
                addr = resolve_symbol(obj_index, sym_index)
                if sym["name"] in global_defs:
                    raise ValueError(f"duplicate global symbol: {sym['name']}")
                global_defs[sym["name"]] = addr

    # Apply per-section relocations after global symbol collection.
    for obj_index, obj in enumerate(objects):
        for target, offset, sym_index, typ, addend in obj["relocations"]:
            if target not in output_buffers:
                raise ValueError(f"{obj['path']}: relocations into {target} are unsupported")
            width = 8 if typ == R_MX64H_ABS64 else 4
            local_offset = contributions[obj_index].get(target)
            if local_offset is None:
                raise ValueError(f"{obj['path']}: relocation target section missing")
            position = local_offset + offset
            buf = output_buffers[target]
            if position < 0 or position + width > len(buf):
                raise ValueError(f"{obj['path']}: relocation offset outside {target}")
            symbol_address = resolve_symbol(obj_index, sym_index)
            place = section_base[target] + position
            if typ == R_MX64H_BRANCH12:
                if target != ".text":
                    raise ValueError("BRANCH12 relocation is valid only in .text")
                delta = symbol_address + addend - place
                if delta % 4:
                    raise ValueError("branch relocation is not word-aligned")
                disp = delta // 4
                if not -(1 << 11) <= disp < (1 << 11):
                    raise ValueError("branch relocation overflow")
                word = int.from_bytes(buf[position:position + 4], "little")
                word = (word & ~0xfff) | (disp & 0xfff)
                buf[position:position + 4] = word.to_bytes(4, "little")
            elif typ == R_MX64H_JUMP26:
                if target != ".text":
                    raise ValueError("JUMP26 relocation is valid only in .text")
                delta = symbol_address + addend - place
                if delta % 4:
                    raise ValueError("jump relocation is not word-aligned")
                disp = delta // 4
                if not -(1 << 25) <= disp < (1 << 25):
                    raise ValueError("jump relocation overflow")
                word = int.from_bytes(buf[position:position + 4], "little")
                word = (word & ~0x3ffffff) | (disp & 0x3ffffff)
                buf[position:position + 4] = word.to_bytes(4, "little")
            elif typ in (R_MX64H_ABS32, R_MX64H_ABS64):
                value = symbol_address + addend
                bits = width * 8
                if not 0 <= value < (1 << bits):
                    raise ValueError(f"ABS{bits} relocation overflow")
                buf[position:position + width] = value.to_bytes(width, "little")
            else:
                raise ValueError(f"unsupported relocation type {typ}")

    entry = 0
    if entry_symbol:
        if entry_symbol not in global_defs:
            raise ValueError(f"undefined entry symbol: {entry_symbol}")
        entry = global_defs[entry_symbol]
    return make_executable_segments(bytes(text), bytes(data), bss_size,
                                    entry=entry, base=BASE,
                                    data_base=section_base[".data"], data_align=data_align,
                                    bss_align=bss_align)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("objects", nargs="+")
    parser.add_argument("-o", "--output", required=True)
    parser.add_argument("--entry", default=None)
    args = parser.parse_args()
    Path(args.output).write_bytes(link(args.objects, args.entry))


if __name__ == "__main__":
    main()
