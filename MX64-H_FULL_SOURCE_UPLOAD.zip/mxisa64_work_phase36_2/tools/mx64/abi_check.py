#!/usr/bin/env python3
"""Static consistency checks for provisional MX64-H ABI metadata."""
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[2]
abi=(ROOT/"software/abi/MX64H_ABI_DRAFT.md").read_text(encoding="utf-8")
elf=(ROOT/"tools/mx64/elf64.py").read_text(encoding="utf-8")
checks=[
    ("16-byte", "16-byte" in abi),
    ("x10–x17 args", "x10–x17" in abi),
    ("callee-saved", "callee-saved" in abi),
    ("JALR return", "JALR x0, x1, 0" in abi),
    ("BRANCH relocation", "R_MX64H_BRANCH12" in abi and "R_MX64H_BRANCH12" in elf),
    ("JUMP relocation", "R_MX64H_JUMP26" in abi and "R_MX64H_JUMP26" in elf),
    ("ABS32 relocation", "R_MX64H_ABS32" in abi and "R_MX64H_ABS32" in elf),
    ("FPGA and ASIC profiles", "FPGA bring-up" in abi and "ASIC bring-up" in abi),
]
failed=[name for name,ok in checks if not ok]
if failed:
    print("FAIL:",", ".join(failed)); sys.exit(1)
print(f"PASS: {len(checks)} ABI/toolchain consistency checks")
