#!/usr/bin/env python3
"""Minimal ELF64 little-endian writer/reader for MX64-H software prototypes."""
from __future__ import annotations
import struct
from dataclasses import dataclass

ELFCLASS64, ELFDATA2LSB, EV_CURRENT = 2, 1, 1
ET_REL, ET_EXEC = 1, 2
EM_MX64H = 0xFE64  # private experimental machine identifier
SHT_NULL, SHT_PROGBITS, SHT_SYMTAB, SHT_STRTAB, SHT_RELA, SHT_NOBITS = 0, 1, 2, 3, 4, 8
SHF_WRITE, SHF_ALLOC, SHF_EXECINSTR = 1, 2, 4
SHN_UNDEF = 0
STB_LOCAL, STB_GLOBAL = 0, 1
STT_NOTYPE, STT_FUNC, STT_SECTION = 0, 2, 3

EHDR = struct.Struct("<16sHHIQQQIHHHHHH")
SHDR = struct.Struct("<IIQQQQIIQQ")
SYM = struct.Struct("<IBBHQQ")
RELA = struct.Struct("<QQq")
PHDR = struct.Struct("<IIQQQQQQ")
PT_LOAD, PF_X, PF_W, PF_R = 1, 1, 2, 4
R_MX64H_BRANCH12 = 1
R_MX64H_JUMP26 = 2
R_MX64H_ABS32 = 3
R_MX64H_ABS64 = 4

def align(value, boundary):
    return (value + boundary - 1) & ~(boundary - 1)

def ident():
    return b"\x7fELF" + bytes([ELFCLASS64, ELFDATA2LSB, EV_CURRENT, 0, 0]) + bytes(7)

def pack_elf(etype, sections, entry=0):
    """Pack a compact ELF64 file from section dictionaries."""
    names = bytearray(b"\0")
    name_offsets = {}
    for sec in sections:
        if sec["name"] in name_offsets:
            raise ValueError(f"duplicate ELF section name: {sec['name']}")
        name_offsets[sec["name"]] = len(names)
        names.extend(sec["name"].encode("utf-8") + b"\0")
    shstr_name = ".shstrtab"
    name_offsets[shstr_name] = len(names)
    names.extend(shstr_name.encode() + b"\0")
    sections = list(sections) + [dict(name=shstr_name, type=SHT_STRTAB, flags=0,
                                      data=bytes(names), align=1)]
    blob = bytearray(EHDR.size)
    shdrs = [dict(name=0, type=SHT_NULL, flags=0, addr=0, off=0, size=0,
                  link=0, info=0, align=0, entsize=0)]
    for sec in sections:
        a = sec.get("align", 1)
        if not isinstance(a, int) or a < 0 or (a > 1 and a & (a - 1)):
            raise ValueError(f"invalid alignment for section {sec['name']}")
        a = max(1, a)
        while len(blob) % a:
            blob.append(0)
        off = len(blob)
        data = bytes(sec.get("data", b""))
        size = sec.get("size", len(data))
        if sec["type"] == SHT_NOBITS:
            if data:
                raise ValueError(f"NOBITS section {sec['name']} cannot carry file data")
        else:
            if size != len(data):
                raise ValueError(f"section {sec['name']} size/data mismatch")
            blob.extend(data)
        shdrs.append(dict(name=name_offsets[sec["name"]], type=sec["type"],
                          flags=sec.get("flags", 0), addr=sec.get("addr", 0),
                          off=off, size=size, link=sec.get("link", 0),
                          info=sec.get("info", 0), align=a,
                          entsize=sec.get("entsize", 0)))
    while len(blob) % 8:
        blob.append(0)
    shoff = len(blob)
    for h in shdrs:
        blob.extend(SHDR.pack(h["name"], h["type"], h["flags"], h["addr"], h["off"],
                              h["size"], h["link"], h["info"], h["align"], h["entsize"]))
    hdr = EHDR.pack(ident(), etype, EM_MX64H, EV_CURRENT, entry, 0, shoff, 0,
                    EHDR.size, 0, 0, SHDR.size, len(shdrs), len(shdrs) - 1)
    blob[:EHDR.size] = hdr
    return bytes(blob)


def parse_elf(data):
    """Parse the supported ELF64 subset, rejecting malformed tables/ranges."""
    if len(data) < EHDR.size:
        raise ValueError("truncated ELF header")
    h = EHDR.unpack_from(data)
    ident_bytes = h[0]
    if ident_bytes[:4] != b"\x7fELF" or ident_bytes[4:7] != bytes([ELFCLASS64, ELFDATA2LSB, EV_CURRENT]):
        raise ValueError("not ELF64 little-endian current-version")
    if ident_bytes[7] != 0:
        raise ValueError("unsupported ELF ABI OS/ABI")
    if h[2] != EM_MX64H:
        raise ValueError(f"wrong e_machine 0x{h[2]:x}")
    if h[3] != EV_CURRENT or h[8] != EHDR.size:
        raise ValueError("invalid ELF version or ELF header size")
    etype = h[1]
    if etype not in (ET_REL, ET_EXEC):
        raise ValueError(f"unsupported ELF file type {etype}")
    phoff, shoff = h[5], h[6]
    phentsize, phnum = h[9], h[10]
    shentsize, shnum, shstrndx = h[11], h[12], h[13]
    if shentsize != SHDR.size or shnum == 0 or shoff < EHDR.size or shoff + shentsize * shnum > len(data):
        raise ValueError("invalid section header table")
    if phnum:
        if phentsize != PHDR.size or phoff < EHDR.size or phoff + phentsize * phnum > len(data):
            raise ValueError("invalid program header table")
    elif phentsize not in (0, PHDR.size):
        raise ValueError("invalid empty program-header entry size")
    phdrs = []
    for i in range(phnum):
        typ, flags, off, va, pa, filesz, memsz, al = PHDR.unpack_from(data, phoff + i * phentsize)
        if off > len(data) or filesz > len(data) - off or filesz > memsz:
            raise ValueError("program segment out of bounds or filesz exceeds memsz")
        if al > 1 and al & (al - 1):
            raise ValueError("program segment alignment is not a power of two")
        if al > 1 and (va - off) % al:
            raise ValueError("program segment address/offset alignment mismatch")
        if typ == PT_LOAD and memsz == 0:
            raise ValueError("empty PT_LOAD segment")
        phdrs.append(dict(type=typ, flags=flags, offset=off, vaddr=va, paddr=pa,
                          filesz=filesz, memsz=memsz, align=al))
    if shstrndx >= shnum:
        raise ValueError("invalid shstrndx")
    headers = [SHDR.unpack_from(data, shoff + i * shentsize) for i in range(shnum)]
    if headers[0][1] != SHT_NULL:
        raise ValueError("section zero must be SHT_NULL")
    sh = headers[shstrndx]
    if sh[1] != SHT_STRTAB or sh[4] > len(data) or sh[5] > len(data) - sh[4]:
        raise ValueError("invalid section-name string table")
    names = data[sh[4]:sh[4] + sh[5]]
    if not names or names[0] != 0:
        raise ValueError("section-name string table must begin with NUL")
    sections = []
    for index, x in enumerate(headers):
        no, typ, flags, addr, off, size, link, info, al, ent = x
        if no >= len(names) and no != 0:
            raise ValueError("section name offset out of range")
        end = names.find(b"\0", no)
        if end < 0:
            raise ValueError("unterminated section name")
        try:
            name = names[no:end].decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("invalid section name encoding") from exc
        if index and typ != SHT_NOBITS and (off > len(data) or size > len(data) - off):
            raise ValueError(f"section {name} out of bounds")
        if al > 1 and al & (al - 1):
            raise ValueError(f"section {name} alignment is not a power of two")
        if al > 1 and off % al:
            raise ValueError(f"section {name} file offset is not aligned")
        if typ == SHT_NOBITS and off > len(data):
            raise ValueError(f"NOBITS section {name} offset is outside file")
        if link >= shnum and link != 0:
            raise ValueError(f"section {name} link index out of range")
        if typ == SHT_SYMTAB and ent != SYM.size:
            raise ValueError(f"section {name} has invalid symbol entry size")
        if typ == SHT_RELA and ent != RELA.size:
            raise ValueError(f"section {name} has invalid RELA entry size")
        if typ in (SHT_SYMTAB, SHT_RELA) and size % ent:
            raise ValueError(f"section {name} size is not a multiple of entry size")
        payload = b"" if typ in (SHT_NULL, SHT_NOBITS) else data[off:off + size]
        sections.append(dict(index=index, name=name, type=typ, flags=flags, addr=addr,
                              offset=off, size=size, link=link, info=info, align=al,
                              entsize=ent, data=payload))
    for sec in sections:
        if sec["type"] == SHT_SYMTAB and sections[sec["link"]]["type"] != SHT_STRTAB:
            raise ValueError(f"symbol table {sec['name']} link must reference a string table")
        if sec["type"] == SHT_SYMTAB:
            symbol_count = sec["size"] // SYM.size
            if sec["info"] > symbol_count:
                raise ValueError(f"symbol table {sec['name']} local-symbol boundary is out of range")
            if symbol_count == 0:
                raise ValueError(f"symbol table {sec['name']} is missing the null symbol")
            for sym_index in range(symbol_count):
                _, info, _, _, _, _ = SYM.unpack_from(sec["data"], sym_index * SYM.size)
                binding = info >> 4
                if sym_index < sec["info"] and binding != STB_LOCAL:
                    raise ValueError(f"symbol table {sec['name']} local symbols must precede globals")
                if sym_index >= sec["info"] and sym_index != 0 and binding == STB_LOCAL:
                    raise ValueError(f"symbol table {sec['name']} local symbol appears after sh_info boundary")
        if sec["type"] == SHT_RELA:
            if sec["link"] == 0 or sections[sec["link"]]["type"] != SHT_SYMTAB:
                raise ValueError(f"relocation section {sec['name']} link must reference a symbol table")
            if sec["info"] == 0 or sec["info"] >= shnum:
                raise ValueError(f"relocation section {sec['name']} target section index out of range")
            target = sections[sec["info"]]
            symbol_count = sections[sec["link"]]["size"] // SYM.size
            for rel_offset in range(0, sec["size"], RELA.size):
                r_offset, r_info, _ = RELA.unpack_from(sec["data"], rel_offset)
                if (r_info >> 32) >= symbol_count:
                    raise ValueError(f"relocation section {sec['name']} symbol index out of range")
                if r_offset >= target["size"]:
                    raise ValueError(f"relocation section {sec['name']} offset outside target section")
    return dict(type=etype, machine=h[2], entry=h[4], program_headers=phdrs,
                sections=sections)

def make_relocatable(text, symbols=None, undefined=None, relocations=None):
    """Emit ET_REL with .text, ELF symbols and RELA records.

    relocations are tuples (offset, symbol_name, relocation_type, addend).
    All defined symbols are global in this prototype.
    """
    symbols = symbols or {}
    undefined = sorted(set(undefined or []))
    relocations = relocations or []
    names = sorted(set(symbols) | set(undefined))
    strtab=bytearray(b"\0")
    sym_entries=[SYM.pack(0,0,0,0,0,0)]
    sym_index={}
    for name in names:
        no=len(strtab); strtab.extend(name.encode()+b"\0")
        if name in symbols:
            info=(STB_GLOBAL<<4)|STT_NOTYPE
            shndx,value=1,symbols[name]
        else:
            info=(STB_GLOBAL<<4)|STT_NOTYPE
            shndx,value=SHN_UNDEF,0
        sym_index[name]=len(sym_entries)
        sym_entries.append(SYM.pack(no,info,0,shndx,value,0))
    rela=b""
    for offset,name,typ,addend in relocations:
        if name not in sym_index: raise ValueError(f"relocation references undeclared symbol {name}")
        info=(sym_index[name]<<32)|typ
        rela += RELA.pack(offset,info,addend)
    symtab=b"".join(sym_entries)
    sections=[
      dict(name=".text",type=SHT_PROGBITS,flags=SHF_ALLOC|SHF_EXECINSTR,data=text,align=4),
      dict(name=".rela.text",type=SHT_RELA,data=rela,align=8,link=3,info=1,entsize=RELA.size),
      dict(name=".symtab",type=SHT_SYMTAB,data=symtab,align=8,link=4,info=1,entsize=SYM.size),
      dict(name=".strtab",type=SHT_STRTAB,data=bytes(strtab),align=1),
    ]
    return pack_elf(ET_REL,sections)

def make_relocatable_sections(sections, symbols=None, undefined=None, relocations=None):
    """Build ET_REL with .text/.data/.bss, symbols, and per-section RELA."""
    symbols = symbols or {}
    undefined = sorted(set(undefined or []))
    relocations = relocations or []
    section_order = [name for name in (".text", ".data", ".bss") if name in sections]
    if not section_order:
        raise ValueError("object must contain at least one supported section")
    section_index = {name: i + 1 for i, name in enumerate(section_order)}
    names = sorted(set(symbols) | set(undefined))
    # ELF requires local symbols first and sh_info to identify the first
    # non-local symbol. Undefined externals are global and must appear once.
    local_names = [n for n in names if n in symbols and not symbols[n].get("global", False)]
    global_names = [n for n in names if n in undefined or (n in symbols and symbols[n].get("global", False))]
    ordered = local_names + global_names
    strtab = bytearray(b"\0")
    sym_entries = [SYM.pack(0, 0, 0, 0, 0, 0)]
    sym_index = {}
    for name in ordered:
        no = len(strtab); strtab.extend(name.encode("utf-8") + b"\0")
        definition = symbols.get(name)
        if definition is None:
            bind, shndx, value = STB_GLOBAL, SHN_UNDEF, 0
        else:
            sec = definition["section"]
            if sec not in section_index:
                raise ValueError(f"symbol {name} references unsupported section {sec}")
            bind = STB_GLOBAL if definition.get("global", False) else STB_LOCAL
            shndx, value = section_index[sec], definition["value"]
        sym_index[name] = len(sym_entries)
        sym_entries.append(SYM.pack(no, (bind << 4) | STT_NOTYPE, 0, shndx, value, 0))
    relocs_by_section = {name: [] for name in section_order}
    for sec, offset, symbol, typ, addend in relocations:
        if sec not in relocs_by_section:
            raise ValueError(f"relocation references unsupported section {sec}")
        if symbol not in sym_index:
            raise ValueError(f"relocation references undeclared symbol {symbol}")
        relocs_by_section[sec].append(RELA.pack(offset, (sym_index[symbol] << 32) | typ, addend))
    elf_sections = []
    for sec in section_order:
        item = sections[sec]
        is_bss = bool(item.get("nobits"))
        elf_sections.append(dict(name=sec, type=SHT_NOBITS if is_bss else SHT_PROGBITS,
            flags=SHF_ALLOC | (SHF_EXECINSTR if sec == ".text" else SHF_WRITE),
            data=b"" if is_bss else item["data"], size=item["size"], align=item["align"]))
    # Add relocation sections before symbol/string tables so indices are stable.
    for sec in section_order:
        rows = relocs_by_section[sec]
        if rows:
            elf_sections.append(dict(name=f".rela{sec}", type=SHT_RELA, data=b"".join(rows),
                align=8, link=0, info=section_index[sec], entsize=RELA.size))
    symtab_index = len(elf_sections) + 1
    strtab_index = symtab_index + 1
    for item in elf_sections:
        if item["type"] == SHT_RELA:
            item["link"] = symtab_index
    elf_sections.append(dict(name=".symtab", type=SHT_SYMTAB, data=b"".join(sym_entries),
        align=8, link=strtab_index, info=1 + len(local_names), entsize=SYM.size))
    elf_sections.append(dict(name=".strtab", type=SHT_STRTAB, data=bytes(strtab), align=1))
    return pack_elf(ET_REL, elf_sections)


def make_executable_segments(text, data=b"", bss_size=0, entry=0, base=0x10000,
                             data_base=None, data_align=8, bss_align=8):
    """Create ET_EXEC with RX text and optional RW data+BSS PT_LOAD segments."""
    text = bytes(text); data = bytes(data)
    if not text:
        raise ValueError("executable .text segment must not be empty")
    if not isinstance(bss_size, int) or isinstance(bss_size, bool) or bss_size < 0:
        raise ValueError("BSS size must be a non-negative integer")
    for label, value in (("data", data_align), ("BSS", bss_align)):
        if not isinstance(value, int) or isinstance(value, bool) or value < 1 or value > 4096 or value & (value - 1):
            raise ValueError(f"{label} alignment must be a power of two no larger than 4096")
    if base < 0 or base % 4096:
        raise ValueError("text base must be non-negative and page-aligned")
    if data_base is None:
        data_base = align(base + len(text), 4096)
    if data_base < align(base + len(text), 4096) or data_base % 4096:
        raise ValueError("data base must be page-aligned and not overlap text")
    if entry == 0:
        entry = base
    if not base <= entry < base + len(text):
        raise ValueError("entry point must lie inside the executable text segment")
    has_rw = bool(data or bss_size)
    segment_count = 2 if has_rw else 1
    phoff = EHDR.size
    segment_off = align(EHDR.size + segment_count * PHDR.size, 4096)
    blob = bytearray(segment_off)
    text_off = len(blob)
    blob.extend(text)
    phdrs = [PHDR.pack(PT_LOAD, PF_R | PF_X, text_off, base, base,
                       len(text), len(text), 4096)]
    section_specs = [dict(name=".text", type=SHT_PROGBITS,
        flags=SHF_ALLOC | SHF_EXECINSTR, addr=base, data=text, off=text_off, align=4096)]
    if has_rw:
        while len(blob) % 4096:
            blob.append(0)
        data_off = len(blob)
        data_vaddr = data_base
        blob.extend(data)
        bss_addr = align(data_vaddr + len(data), bss_align) if bss_size else data_vaddr + len(data)
        bss_file_off = align(data_off + len(data), bss_align) if bss_size else data_off + len(data)
        if bss_size:
            while len(blob) < bss_file_off:
                blob.append(0)
        mem_size = (bss_addr - data_vaddr) + bss_size
        phdrs.append(PHDR.pack(PT_LOAD, PF_R | PF_W, data_off, data_vaddr,
                               data_vaddr, len(data), mem_size, 4096))
        section_specs.append(dict(name=".data", type=SHT_PROGBITS,
            flags=SHF_ALLOC | SHF_WRITE, addr=data_vaddr, data=data, off=data_off, align=data_align)) if data else None
        if bss_size:
            section_specs.append(dict(name=".bss", type=SHT_NOBITS,
                flags=SHF_ALLOC | SHF_WRITE, addr=bss_addr, data=b"", size=bss_size,
                off=bss_file_off, align=bss_align))
    names = bytearray(b"\0")
    name_offsets = {}
    for sec in section_specs:
        name_offsets[sec["name"]] = len(names)
        names.extend(sec["name"].encode() + b"\0")
    name_offsets[".shstrtab"] = len(names); names.extend(b".shstrtab\0")
    section_specs.append(dict(name=".shstrtab", type=SHT_STRTAB, data=bytes(names), align=1))
    shdrs = [dict(name=0, type=SHT_NULL, flags=0, addr=0, off=0, size=0,
                  link=0, info=0, align=0, entsize=0)]
    for sec in section_specs:
        a = max(1, sec.get("align", 1))
        if "off" in sec:
            off = sec["off"]
            size = sec.get("size", len(sec.get("data", b"")))
            if sec["type"] != SHT_NOBITS and size != len(sec.get("data", b"")):
                raise ValueError(f"section {sec['name']} size/data mismatch")
        elif sec["type"] == SHT_NOBITS:
            off = len(blob)
            size = sec["size"]
        else:
            while len(blob) % a:
                blob.append(0)
            off = len(blob); payload = bytes(sec.get("data", b"")); blob.extend(payload)
            size = len(payload)
        shdrs.append(dict(name=name_offsets[sec["name"]], type=sec["type"],
            flags=sec.get("flags", 0), addr=sec.get("addr", 0), off=off, size=size,
            link=0, info=0, align=a, entsize=0))
    while len(blob) % 8:
        blob.append(0)
    shoff = len(blob)
    for h in shdrs:
        blob.extend(SHDR.pack(h["name"], h["type"], h["flags"], h["addr"], h["off"],
            h["size"], h["link"], h["info"], h["align"], h["entsize"]))
    blob[:EHDR.size] = EHDR.pack(ident(), ET_EXEC, EM_MX64H, EV_CURRENT, entry,
        phoff, shoff, 0, EHDR.size, PHDR.size, len(phdrs), SHDR.size,
        len(shdrs), len(shdrs) - 1)
    for i, ph in enumerate(phdrs):
        start = phoff + i * PHDR.size
        blob[start:start + PHDR.size] = ph
    return bytes(blob)


def make_executable(text, entry=0, base=0x10000):
    """Backward-compatible single RX-segment executable builder."""
    return make_executable_segments(text, entry=entry, base=base)
