#!/usr/bin/env python3
"""MX64-H boot-image envelope for carrying a validated ELF64 ET_EXEC payload.

This is a file/container utility. It is not a hardware boot ROM or loader.
"""
from __future__ import annotations
import hashlib
import struct
from elf64 import parse_elf, ET_EXEC, EM_MX64H, PT_LOAD, PF_X, PF_W, PF_R

MAGIC = b"MX64HBI1"
VERSION = 1
HEADER_SIZE = 128
PAYLOAD_ELF64 = 1
PLATFORMS = {"generic": 0, "fpga": 1, "asic": 2}
PLATFORM_NAMES = {value: key for key, value in PLATFORMS.items()}
# magic, version, header_size, flags, platform_id, payload_kind, reserved0,
# payload_offset, payload_size, entry, sha256, reserved[44]
_HEADER = struct.Struct("<8sHHIIIIQQQ32s44s")
assert _HEADER.size == HEADER_SIZE


def _validate_elf(elf_bytes: bytes) -> dict:
    parsed = parse_elf(elf_bytes)
    if parsed["type"] != ET_EXEC:
        raise ValueError("boot payload must be an ELF64 ET_EXEC")
    if parsed["machine"] != EM_MX64H:
        raise ValueError("boot payload has the wrong MX64-H e_machine")
    loads = [p for p in parsed["program_headers"] if p["type"] == PT_LOAD]
    if not loads:
        raise ValueError("boot payload has no PT_LOAD segment")
    for segment in loads:
        if segment["flags"] & ~(PF_X | PF_W | PF_R):
            raise ValueError("PT_LOAD segment contains unsupported permission flags")
        if (segment["flags"] & PF_X) and (segment["flags"] & 2):
            raise ValueError("writable-executable PT_LOAD segments are rejected by boot policy")
        if segment["vaddr"] + segment["memsz"] > (1 << 64):
            raise ValueError("PT_LOAD address range overflows 64-bit address space")
    ranges = sorted((p["vaddr"], p["vaddr"] + p["memsz"]) for p in loads)
    for previous, current in zip(ranges, ranges[1:]):
        if current[0] < previous[1]:
            raise ValueError("PT_LOAD memory ranges overlap")
    entry = parsed["entry"]
    if not any((p["flags"] & PF_X) and p["vaddr"] <= entry < p["vaddr"] + p["memsz"] for p in loads):
        raise ValueError("ELF entry point is not inside an executable PT_LOAD segment")
    return parsed


def make_boot_image(elf_bytes: bytes, platform: str = "generic") -> bytes:
    """Wrap an MX64-H ELF executable in the version-1 boot-image envelope."""
    if platform not in PLATFORMS:
        raise ValueError(f"unsupported platform {platform!r}; choose {', '.join(PLATFORMS)}")
    parsed = _validate_elf(elf_bytes)
    digest = hashlib.sha256(elf_bytes).digest()
    header = _HEADER.pack(
        MAGIC, VERSION, HEADER_SIZE, 0, PLATFORMS[platform], PAYLOAD_ELF64,
        0, HEADER_SIZE, len(elf_bytes), parsed["entry"], digest, bytes(44)
    )
    return header + elf_bytes


def parse_boot_image(image: bytes) -> dict:
    """Validate an envelope and its embedded ELF, returning metadata and payload."""
    if len(image) < HEADER_SIZE:
        raise ValueError("truncated MX64-H boot-image header")
    (magic, version, header_size, flags, platform_id, payload_kind, reserved0,
     payload_offset, payload_size, entry, digest, reserved) = _HEADER.unpack_from(image)
    if magic != MAGIC:
        raise ValueError("invalid MX64-H boot-image magic")
    if version != VERSION or header_size != HEADER_SIZE:
        raise ValueError("unsupported boot-image version or header size")
    if flags != 0 or reserved0 != 0 or reserved != bytes(44):
        raise ValueError("unsupported flags or nonzero reserved header fields")
    if platform_id not in PLATFORM_NAMES:
        raise ValueError("unknown boot-image platform identifier")
    if payload_kind != PAYLOAD_ELF64:
        raise ValueError("unsupported boot-image payload type")
    if payload_offset != HEADER_SIZE:
        raise ValueError("invalid payload offset")
    payload_end = payload_offset + payload_size
    if payload_end != len(image):
        raise ValueError("payload size does not match container length")
    payload = image[payload_offset:payload_end]
    if hashlib.sha256(payload).digest() != digest:
        raise ValueError("boot-image payload SHA-256 mismatch")
    parsed = _validate_elf(payload)
    if parsed["entry"] != entry:
        raise ValueError("container entry point does not match ELF entry point")
    return {
        "version": version,
        "platform": PLATFORM_NAMES[platform_id],
        "platform_id": platform_id,
        "payload_type": "ELF64_ET_EXEC",
        "payload_offset": payload_offset,
        "payload_size": payload_size,
        "entry": entry,
        "sha256": digest.hex(),
        "elf": parsed,
        "payload": payload,
    }
