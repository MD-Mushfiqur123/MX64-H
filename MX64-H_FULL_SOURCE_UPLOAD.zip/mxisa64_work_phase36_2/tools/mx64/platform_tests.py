#!/usr/bin/env python3
from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from platform_check import validate_profile

root = Path(__file__).resolve().parents[2]
for rel in ("platforms/fpga/template.json", "platforms/asic/template.json"):
    profile = json.loads((root / rel).read_text(encoding="utf-8"))
    assert validate_profile(profile) == []
    assert validate_profile(profile, require_complete=True)

base = {
    "profile_version": 1,
    "platform": "fpga",
    "board": {"vendor": "example-vendor", "part": "example-part", "clock_hz": 50000000, "toolchain": "example-toolchain"},
    "cpu": {"paddr_bits": 32, "reset_vector": 0x00000000},
    "boot": {"image_platform_id": 1, "boot_source": "qspi"},
    "memory_map": [
        {"name": "boot_rom", "base": 0x00000000, "size": 0x10000, "permissions": "rx", "kind": "rom"},
        {"name": "main_ram", "base": 0x10000000, "size": 0x100000, "permissions": "rwx", "kind": "ram"},
        {"name": "mmio", "base": 0xF0000000, "size": 0x100000, "permissions": "rw", "kind": "mmio"}
    ]
}
assert validate_profile(base, require_complete=True) == []
not_executable_reset = json.loads(json.dumps(base))
not_executable_reset["cpu"]["reset_vector"] = 0x10000000
not_executable_reset["memory_map"][1]["permissions"] = "rw"
assert any("not inside an executable" in e for e in validate_profile(not_executable_reset))
overlap = json.loads(json.dumps(base))
overlap["memory_map"][1]["base"] = 0x8000
assert any("overlap" in e for e in validate_profile(overlap))
out_of_range = json.loads(json.dumps(base))
out_of_range["memory_map"][1]["base"] = 1 << 32
assert any("exceeds" in e for e in validate_profile(out_of_range))
print("PASS: FPGA/ASIC platform templates, completeness, overlap and address-width checks")
