#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from boot_image import make_boot_image, parse_boot_image
from elf64 import make_executable, make_executable_segments

elf = make_executable(b"\x13\x00\x00\x00", entry=0x10000)
for platform in ("generic", "fpga", "asic"):
    image = make_boot_image(elf, platform)
    parsed = parse_boot_image(image)
    assert parsed["platform"] == platform
    assert parsed["entry"] == 0x10000
    assert parsed["payload"] == elf
    assert parsed["payload_size"] == len(elf)

# Two load segments with BSS are accepted; the RW segment is zero-fill extended.
segmented_elf = make_executable_segments(b"\x13\x00\x00\x00", b"abc", 17,
                                         entry=0x10000, base=0x10000, data_base=0x11000,
                                         data_align=8, bss_align=16)
segmented = parse_boot_image(make_boot_image(segmented_elf, "fpga"))
loads = segmented["elf"]["program_headers"]
assert len(loads) == 2 and loads[1]["filesz"] == 3 and loads[1]["memsz"] >= 20

# Boot policy rejects W+X and overlapping loadable memory regions.
import struct
phoff = struct.unpack_from("<Q", segmented_elf, 32)[0]
wx_elf = bytearray(segmented_elf)
struct.pack_into("<I", wx_elf, phoff + 4, 7)  # PF_R | PF_W | PF_X
try:
    make_boot_image(bytes(wx_elf), "fpga")
except ValueError as exc:
    assert "writable-executable" in str(exc)
else:
    raise AssertionError("W+X PT_LOAD accepted")
overlap_elf = bytearray(segmented_elf)
second_ph = phoff + 56
struct.pack_into("<Q", overlap_elf, second_ph + 16, 0x10000)
struct.pack_into("<Q", overlap_elf, second_ph + 24, 0x10000)
try:
    make_boot_image(bytes(overlap_elf), "fpga")
except ValueError as exc:
    assert "overlap" in str(exc)
else:
    raise AssertionError("overlapping PT_LOAD segments accepted")

# Corrupt magic, payload bytes, and encoded payload length independently.
image = bytearray(make_boot_image(elf, "fpga"))
cases = [
    (0, b"BADMAGIC", "magic"),
    (128, bytes([image[128] ^ 1]), "SHA-256"),
    (36, (len(elf) + 1).to_bytes(8, "little"), "payload size"),
]
for offset, replacement, message in cases:
    broken = bytearray(image)
    broken[offset:offset + len(replacement)] = replacement
    try:
        parse_boot_image(bytes(broken))
    except ValueError as exc:
        assert message.lower() in str(exc).lower(), (message, str(exc))
    else:
        raise AssertionError(f"corrupted boot image accepted: {message}")

try:
    make_boot_image(elf, "unknown")
except ValueError as exc:
    assert "unsupported platform" in str(exc)
else:
    raise AssertionError("unknown platform accepted")

try:
    parse_boot_image(b"short")
except ValueError as exc:
    assert "truncated" in str(exc)
else:
    raise AssertionError("truncated image accepted")

print("PASS: MX64-H boot-image pack/parse, platform IDs, SHA-256, length and header corruption checks")
