#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from assembler import assemble
from encode import decode

src = """
start:
    ADDI x1, x0, 3
    ADDI x2, x0, 0
loop:
    ADD x2, x2, x1
    ADDI x1, x1, -1
    BNE x1, x0, loop
    JAL done
    HALT
done:
    SD x2, 0(x0)
    HALT
"""
data, syms = assemble(src)
assert len(data) == 9 * 4
assert syms == {"start":0, "loop":8, "done":28}
decoded = [decode(int.from_bytes(data[i:i+4],"little")) for i in range(0,len(data),4)]
assert decoded[4].endswith("-2"), decoded[4]
assert decoded[5] == "JAL 2", decoded[5]
assert decoded[7].startswith("SD x2, x0, 0"), decoded[7]

data2, syms2 = assemble("entry: .word 0x12345678\n.space 3\nHALT\n")
assert data2[:4] == bytes.fromhex("78563412")
assert data2[4:7] == bytes([0,0,0])
assert len(data2) == 11 and syms2["entry"] == 0

for bad in ("x: HALT\nx: NOP", "BEQ x1, x2, missing", "ADDI x32, x0, 1"):
    try:
        assemble(bad)
    except ValueError:
        pass
    else:
        raise AssertionError(f"invalid input accepted: {bad}")
print("PASS: two-pass assembler labels, branches, JAL, memory syntax, directives and diagnostics")
