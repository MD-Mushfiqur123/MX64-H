#!/usr/bin/env python3
"""Validate MX64-H FPGA/ASIC platform profile structure and memory ranges."""
import argparse
import json
from pathlib import Path


def validate_profile(profile: dict, require_complete: bool = False) -> list[str]:
    errors = []
    platform = profile.get("platform")
    if platform not in ("fpga", "asic"):
        errors.append("platform must be 'fpga' or 'asic'")
    if profile.get("profile_version") != 1:
        errors.append("profile_version must be 1")
    cpu = profile.get("cpu")
    if not isinstance(cpu, dict):
        errors.append("cpu object is required")
        cpu = {}
    paddr_bits = cpu.get("paddr_bits")
    if paddr_bits is not None and (not isinstance(paddr_bits, int) or isinstance(paddr_bits, bool) or not 1 <= paddr_bits <= 64):
        errors.append("cpu.paddr_bits must be an integer in [1, 64] or null")
    reset_vector = cpu.get("reset_vector")
    if reset_vector is not None and (not isinstance(reset_vector, int) or isinstance(reset_vector, bool) or reset_vector < 0):
        errors.append("cpu.reset_vector must be a non-negative integer or null")
    if require_complete and paddr_bits is None:
        errors.append("cpu.paddr_bits is unresolved")
    if require_complete and reset_vector is None:
        errors.append("cpu.reset_vector is unresolved")

    platform_details = profile.get("board" if platform == "fpga" else "soc")
    required_detail_fields = ("vendor", "part", "clock_hz", "toolchain") if platform == "fpga" else ("name", "process_node", "pdk_revision", "clock_hz")
    if not isinstance(platform_details, dict):
        errors.append(("board" if platform == "fpga" else "soc") + " object is required")
        platform_details = {}
    if require_complete:
        detail_name = "board" if platform == "fpga" else "soc"
        for field in required_detail_fields:
            value = platform_details.get(field)
            if value is None or value == "":
                errors.append(f"{detail_name}.{field} is unresolved")
        if not isinstance(platform_details.get("clock_hz"), int) or isinstance(platform_details.get("clock_hz"), bool) or platform_details.get("clock_hz", 0) <= 0:
            errors.append(f"{detail_name}.clock_hz must be a positive integer")

    regions = profile.get("memory_map")
    if not isinstance(regions, list) or not regions:
        errors.append("memory_map must be a non-empty array")
        regions = []
    ranges = []
    range_regions = []
    names = set()
    for index, region in enumerate(regions):
        if not isinstance(region, dict):
            errors.append(f"memory_map[{index}] must be an object")
            continue
        name, base, size = region.get("name"), region.get("base"), region.get("size")
        display_name = name if isinstance(name, str) and name else str(index)
        if not isinstance(name, str) or not name:
            errors.append(f"memory_map[{index}].name is required")
        elif name in names:
            errors.append(f"duplicate memory region name: {name}")
        else:
            names.add(name)

        permissions = region.get("permissions")
        permissions_valid = (isinstance(permissions, str) and bool(permissions)
                             and all(ch in "rwx" for ch in permissions)
                             and len(set(permissions)) == len(permissions))
        if not permissions_valid:
            errors.append(f"{display_name}: permissions must be a unique combination of r, w and x")
        kind = region.get("kind")
        kind_valid = kind in ("rom", "ram", "mmio")
        if not kind_valid:
            errors.append(f"{display_name}: kind must be rom, ram or mmio")
        if kind == "rom" and permissions_valid and "w" in permissions:
            errors.append(f"{display_name}: ROM cannot be writable")
        if kind == "mmio" and permissions_valid and "x" in permissions:
            errors.append(f"{display_name}: MMIO cannot be executable")

        if (base is None) != (size is None):
            errors.append(f"{display_name}: base and size must both be set or both be null")
            continue
        if base is None:
            if require_complete:
                errors.append(f"{display_name}: base/size is unresolved")
            continue
        if (not isinstance(base, int) or isinstance(base, bool)
                or not isinstance(size, int) or isinstance(size, bool)
                or base < 0 or size <= 0):
            errors.append(f"{display_name}: base must be >= 0 and size must be > 0")
            continue
        end = base + size
        if isinstance(paddr_bits, int) and not isinstance(paddr_bits, bool) and end > (1 << paddr_bits):
            errors.append(f"{display_name}: range exceeds {paddr_bits}-bit physical address space")
        ranges.append((base, end, display_name))
        range_regions.append((base, end, display_name, permissions if permissions_valid else ""))
    ranges.sort()
    for previous, current in zip(ranges, ranges[1:]):
        if current[0] < previous[1]:
            errors.append(f"memory regions overlap: {previous[2]} and {current[2]}")
    if reset_vector is not None and isinstance(reset_vector, int) and not isinstance(reset_vector, bool):
        if reset_vector % 4:
            errors.append("cpu.reset_vector must be 4-byte aligned")
        elif ranges and not any(start <= reset_vector < end and "x" in permissions
                                for start, end, _name, permissions in range_regions):
            errors.append("cpu.reset_vector is not inside an executable memory region")

    boot = profile.get("boot")
    expected_id = {"fpga": 1, "asic": 2}.get(platform)
    if not isinstance(boot, dict):
        errors.append("boot object is required")
    elif boot.get("image_platform_id") != expected_id:
        errors.append("boot.image_platform_id does not match platform")
    elif require_complete and not boot.get("boot_source"):
        errors.append("boot.boot_source is unresolved")
    if require_complete and platform == "asic" and (not isinstance(boot, dict) or not isinstance(boot.get("rom_size_bytes"), int) or isinstance(boot.get("rom_size_bytes"), bool) or boot.get("rom_size_bytes", 0) <= 0):
        errors.append("boot.rom_size_bytes must be a positive integer")
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("profile")
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()
    try:
        profile = json.loads(Path(args.profile).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise SystemExit(f"FAIL: cannot read profile: {exc}")
    errors = validate_profile(profile, args.require_complete)
    if errors:
        print("FAIL: platform profile validation")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)
    print("PASS: platform profile structure and configured memory ranges")
    if profile.get("status") == "template_incomplete" or any(r.get("base") is None for r in profile.get("memory_map", [])):
        print("NOTE: template is structurally valid but not hardware-ready")


if __name__ == "__main__":
    main()
