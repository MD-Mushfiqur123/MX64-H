#!/usr/bin/env python3
"""One-command MX64-H assembly -> ELF object -> linked ELF executable prototype."""
import argparse, tempfile
from pathlib import Path
from assembler import assemble_multisection_source
from elf64 import make_relocatable_sections, parse_elf, ET_EXEC, align
from mxld import link, BASE

def build_sources(sources, output, entry=None, map_path=None):
    objects=[]
    with tempfile.TemporaryDirectory(prefix="mx64h-build-") as td:
        for i,src in enumerate(sources):
            sections,defs,undefined,relocs=assemble_multisection_source(Path(src).read_text(encoding="utf-8"))
            obj=make_relocatable_sections(sections,defs,undefined,relocs)
            # Validate each emitted object before handing it to the linker.
            if parse_elf(obj)["type"] != 1: raise ValueError(f"{src}: assembler did not emit ET_REL")
            op=Path(td)/f"unit_{i}.o"; op.write_bytes(obj); objects.append(op)
        image=link(objects,entry)
        parsed=parse_elf(image)
        if parsed["type"] != ET_EXEC: raise ValueError("linker did not emit ET_EXEC")
        Path(output).write_bytes(image)
        if map_path:
            rows=[f"text_base = 0x{BASE:016x}"]
            cursors={".text":0,".data":0,".bss":0}
            section_align={".text":4,".data":8,".bss":8}
            placements=[]; parsed_sources=[]
            for src in sources:
                sections,defs,_,_=assemble_multisection_source(Path(src).read_text(encoding="utf-8"))
                placement={}
                for sec in cursors:
                    item=sections[sec]
                    section_align[sec]=max(section_align[sec],item["align"])
                    cursors[sec]=align(cursors[sec],item["align"])
                    placement[sec]=cursors[sec]
                    cursors[sec]+=item["size"]
                placements.append(placement); parsed_sources.append((src,defs))
            data_base=align(BASE+cursors[".text"],4096)
            bases={".text":BASE,".data":data_base,
                   ".bss":align(data_base+cursors[".data"],section_align[".bss"])}
            for (src,defs),placement in zip(parsed_sources,placements):
                for name,definition in sorted(defs.items()):
                    section=definition["section"]
                    address=bases[section]+placement[section]+definition["value"]
                    rows.append(f"{address:016x} {name} [{section}] ({src})")
            rows.append(f"entry = {parsed['entry']:#018x}")
            Path(map_path).write_text("\n".join(rows)+"\n",encoding="utf-8")
    return parsed

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("sources",nargs="+")
    p.add_argument("-o","--output",required=True)
    p.add_argument("--entry",default="_start")
    p.add_argument("--map",dest="map_path")
    a=p.parse_args()
    build_sources(a.sources,a.output,a.entry,a.map_path)
if __name__=="__main__": main()
