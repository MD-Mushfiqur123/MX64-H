#!/usr/bin/env python3
"""MXISA-64 proposal encoder/disassembler.

Implements the documented candidate formats. This is software collateral only;
the ISA remains a proposal until architecture freeze.
"""
from __future__ import annotations
import argparse
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TABLE = ROOT / "docs/isa/MXISA64_OPCODE_TABLE.csv"

def load_ops():
    result = {}
    with TABLE.open(encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            major = int(row["major"], 0)
            minor = int(row["minor"], 0)
            key = row["operation"].upper()
            if key in result:
                raise ValueError(f"duplicate operation {key}")
            result[key] = (major, row["format"].upper(), minor)
    return result

OPS = load_ops()

def reg(n):
    if isinstance(n, str):
        n = n.lower().removeprefix("x")
        n = int(n, 0)
    if not 0 <= n < 32:
        raise ValueError("register must be x0..x31")
    return n

def number(value):
    return int(value, 0) if isinstance(value, str) else int(value)

def signed(value, bits, name="immediate"):
    lo, hi = -(1 << (bits-1)), (1 << (bits-1))-1
    if not lo <= value <= hi:
        raise ValueError(f"{name} outside [{lo}, {hi}]")
    return value & ((1 << bits)-1)

def fields(word):
    return {
        "major": (word >> 26) & 0x3f,
        "rd": (word >> 21) & 0x1f,
        "rs1": (word >> 16) & 0x1f,
        "rs2": (word >> 11) & 0x1f,
        "minor4": (word >> 12) & 0xf,
        "minor6": word & 0x3f,
        "imm12": word & 0xfff,
        "imm17": word & 0x1ffff,
        "disp26": word & 0x3ffffff,
    }

def encode(name, *args):
    name = name.upper()
    if name not in OPS:
        raise ValueError(f"unknown instruction {name}")
    major, fmt, minor = OPS[name]
    if fmt == "R":
        if name in ("NOP", "HALT", "ECALL", "EBREAK", "MRET", "FENCE", "FENCE.I"):
            if args:
                raise ValueError(f"{name} takes no operands in this profile")
            return (major << 26) | minor
        if len(args) != 3:
            raise ValueError(f"{name} expects rd, rs1, rs2")
        rd, rs1, rs2 = map(reg, args)
        return (major << 26) | (rd << 21) | (rs1 << 16) | (rs2 << 11) | minor
    if fmt == "I":
        if name == "JALR":
            if len(args) != 3:
                raise ValueError("JALR expects rd, rs1, imm12")
            rd, rs1, imm = reg(args[0]), reg(args[1]), signed(number(args[2]), 12)
        elif name in ("LB","LBU","LH","LHU","LW","LWU","LD"):
            if len(args) != 3:
                raise ValueError(f"{name} expects rd, rs1, imm12")
            rd, rs1, imm = reg(args[0]), reg(args[1]), signed(number(args[2]), 12)
        elif name in ("ADDI","ANDI","ORI","XORI","SLTI","SLTIU","SLLI","SRLI","SRAI"):
            if len(args) != 3:
                raise ValueError(f"{name} expects rd, rs1, immediate")
            rd, rs1, imm = reg(args[0]), reg(args[1]), signed(number(args[2]), 12)
        else:
            raise ValueError(f"{name}: I-format form not implemented in assembler")
        return (major << 26) | (rd << 21) | (rs1 << 16) | (minor << 12) | imm
    if fmt == "S":
        if len(args) != 3:
            raise ValueError(f"{name} expects rs2, rs1, imm12")
        rs2, rs1, imm = reg(args[0]), reg(args[1]), signed(number(args[2]), 12)
        return (major << 26) | (rs2 << 21) | (rs1 << 16) | (minor << 12) | imm
    if fmt == "B":
        if len(args) != 3:
            raise ValueError(f"{name} expects rs1, rs2, displacement-in-words")
        rs1, rs2 = reg(args[0]), reg(args[1])
        disp = number(args[2])
        return (major << 26) | (rs2 << 21) | (rs1 << 16) | (minor << 12) | signed(disp, 12, "branch displacement")
    if fmt == "J":
        if len(args) != 1:
            raise ValueError("JAL expects displacement-in-words (link register x1 is implicit)")
        return (major << 26) | signed(number(args[0]), 26, "jump displacement")
    if fmt == "U":
        if len(args) != 2:
            raise ValueError(f"{name} expects rd, upper-immediate")
        rd = reg(args[0])
        imm = signed(number(args[1]), 17, "upper immediate")
        return (major << 26) | (rd << 21) | (minor << 17) | imm
    raise ValueError(f"unsupported format {fmt}")

def decode(word):
    if not 0 <= word <= 0xffffffff:
        raise ValueError("instruction word must be 32-bit")
    f = fields(word)
    major = f["major"]
    # R format lookup uses the six-bit minor selector.
    for name, (m, fmt, sub) in OPS.items():
        if m != major or fmt != "R":
            continue
        if f["minor6"] == sub:
            if name in ("NOP","HALT","ECALL","EBREAK","MRET","FENCE","FENCE.I"):
                return name
            return f"{name} x{f['rd']}, x{f['rs1']}, x{f['rs2']}"
    # I/S/B/U use the format-specific selector.
    for name, (m, fmt, sub) in OPS.items():
        if m != major or fmt not in ("I","S","B","U"):
            continue
        selector = f["minor4"] if fmt in ("I","S","B") else ((word >> 17) & 0xf)
        if selector != sub:
            continue
        imm = f["imm12"]
        if imm & 0x800:
            imm -= 0x1000
        if fmt == "I":
            return f"{name} x{f['rd']}, x{f['rs1']}, {imm}"
        if fmt == "S":
            return f"{name} x{f['rd']}, x{f['rs1']}, {imm}"
        if fmt == "B":
            return f"{name} x{f['rs1']}, x{f['rd']}, {imm}"
        if fmt == "U":
            u = f["imm17"]
            if u & (1 << 16): u -= (1 << 17)
            return f"{name} x{f['rd']}, {u}"
    # JAL major is fixed format.
    if major == 0x09:
        disp = f["disp26"]
        if disp & (1 << 25): disp -= (1 << 26)
        return f"JAL {disp}"
    return f".word 0x{word:08x}"

def assemble_line(line):
    line = line.split("#", 1)[0].strip()
    if not line:
        return None
    line = line.replace(",", " ")
    parts = line.split()
    return encode(parts[0], *parts[1:])

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input", nargs="?", help="assembly source; stdin if omitted")
    ap.add_argument("-o", "--output", help="binary output path")
    ap.add_argument("--disassemble", action="store_true", help="decode 32-bit little-endian words")
    ns = ap.parse_args()
    text = Path(ns.input).read_text(encoding="utf-8") if ns.input else __import__("sys").stdin.read()
    if ns.disassemble:
        data = bytes.fromhex(" ".join(text.split())) if ns.input is None else Path(ns.input).read_bytes()
        if len(data) % 4: raise SystemExit("input size must be a multiple of 4 bytes")
        lines = [decode(int.from_bytes(data[i:i+4], "little")) for i in range(0, len(data), 4)]
        output = "\n".join(lines) + "\n"
    else:
        words = [w for line in text.splitlines() if (w := assemble_line(line)) is not None]
        data = b"".join(w.to_bytes(4, "little") for w in words)
        output = data.hex(" ") + "\n"
        if ns.output:
            Path(ns.output).write_bytes(data)
            return
    print(output, end="")

if __name__ == "__main__":
    main()
