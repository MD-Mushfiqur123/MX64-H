#!/usr/bin/env python3
"""Assemble MXISA-64 source into a relocatable ELF64 object."""
import argparse
from pathlib import Path
from assembler import assemble_multisection_source
from elf64 import make_relocatable_sections, parse_elf, ET_REL

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("input"); p.add_argument("-o","--output",required=True)
    a=p.parse_args()
    sections,defs,undefined,relocs=assemble_multisection_source(Path(a.input).read_text(encoding="utf-8"))
    data=make_relocatable_sections(sections,defs,undefined,relocs)
    assert parse_elf(data)["type"]==ET_REL
    Path(a.output).write_bytes(data)
if __name__=="__main__": main()
