#!/usr/bin/env python3
"""Small software-only reference-model smoke checks."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from encode import encode
from isa_model import MXISAReference

# Program: x1=9; x2=4; x3=x1+x2; store x3 at [x0+64]; load x4; halt.
program = [
    encode("ADDI",1,0,9),
    encode("ADDI",2,0,4),
    encode("ADD",3,1,2),
    encode("SD",3,0,64),
    encode("LD",4,0,64),
    encode("HALT"),
]
cpu = MXISAReference()
for i, word in enumerate(program):
    for j, byte in enumerate(word.to_bytes(4,"little")):
        cpu.memory[i*4+j] = byte
state = cpu.run()
assert state.halted and state.regs[3] == 13 and state.regs[4] == 13
assert state.regs[0] == 0
print("PASS: reference interpreter smoke program (ADD/ADDI/SD/LD/HALT)")
