#!/usr/bin/env python3
"""Software-only architectural tests for the MXISA-64 reference model."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from encode import encode
from isa_model import MXISAReference, MASK64

def run(words, initial=None, max_steps=100):
    cpu = MXISAReference()
    if initial:
        for reg, value in initial.items():
            cpu.state.regs[reg] = value & MASK64
    for i, word in enumerate(words):
        for j, byte in enumerate(word.to_bytes(4, "little")):
            cpu.memory[i*4+j] = byte
    cpu.run(max_steps=max_steps)
    return cpu

# Basic arithmetic, hardwired zero, bitwise, signed/unsigned comparisons.
cpu = run([
    encode("ADDI",1,0,21), encode("ADDI",2,0,7),
    encode("ADD",3,1,2), encode("SUB",4,1,2),
    encode("AND",5,1,2), encode("OR",6,1,2), encode("XOR",7,1,2),
    encode("NOR",8,1,2), encode("SLT",9,2,1), encode("SLTU",10,1,2),
    encode("HALT")
])
assert cpu.state.regs[3:11] == [28,14,5,23,18,(~(21|7))&MASK64,1,0]
assert cpu.state.regs[0] == 0

# Shift and multiply high-half behavior.
cpu = run([
    encode("ADDI",1,0,3), encode("ADDI",2,0,4),
    encode("SLL",3,1,2), encode("SRL",4,3,2),
    encode("SRA",5,3,2), encode("MUL",6,1,2),
    encode("MULH",7,1,2), encode("MULHU",8,1,2), encode("HALT")
])
assert cpu.state.regs[3:9] == [48,3,3,12,0,0]

# Immediate arithmetic, shifts and signed extension.
cpu = run([
    encode("ADDI",1,0,-9), encode("ANDI",2,1,7),
    encode("ORI",3,0,16), encode("XORI",4,3,3),
    encode("SLTI",5,1,-8), encode("SLTIU",6,1,1),
    encode("SLLI",7,3,2), encode("SRLI",8,7,1),
    encode("SRAI",9,1,1), encode("HALT")
])
assert cpu.state.regs[1] == MASK64-8
assert cpu.state.regs[2] == 7
assert cpu.state.regs[3] == 16 and cpu.state.regs[4] == 19
assert cpu.state.regs[5] == 1 and cpu.state.regs[6] == 0
assert cpu.state.regs[7] == 64 and cpu.state.regs[8] == 32
assert cpu.state.regs[9] == MASK64-4

# Loads/stores widths, little-endian behavior and sign extension.
cpu = run([
    encode("ADDI",1,0,0x7f), encode("SB",1,0,128),
    encode("ADDI",2,0,0x80), encode("SB",2,0,129),
    encode("LB",3,0,128), encode("LBU",4,0,129),
    encode("HALT")
])
assert cpu.state.regs[3] == 127
assert cpu.state.regs[4] == 128

# Branch taken/not-taken and JAL link semantics.
cpu = run([
    encode("ADDI",1,0,5), encode("ADDI",2,0,5),
    encode("BEQ",1,2,2), encode("ADDI",3,0,99),
    encode("ADDI",3,0,42), encode("BNE",1,2,2),
    encode("ADDI",4,0,77), encode("JAL",2),
    encode("ADDI",4,0,88), encode("HALT")
])
assert cpu.state.regs[3] == 42
assert cpu.state.regs[4] == 77
assert cpu.state.regs[1] == 32

# Exact signed division: avoids float rounding at 64-bit extremes.
cpu = MXISAReference()
cpu.state.regs[1] = (1 << 63) - 1
cpu.state.regs[2] = 3
cpu.step(encode("DIV",3,1,2))
assert cpu.state.regs[3] == ((1 << 63) - 1) // 3

# Divide-by-zero and signed overflow rules.
cpu = MXISAReference()
cpu.state.regs[1] = 123
cpu.state.regs[2] = 0
cpu.step(encode("DIV",3,1,2))
cpu.step(encode("REM",4,1,2))
assert cpu.state.regs[3] == MASK64 and cpu.state.regs[4] == 123

cpu = MXISAReference()
cpu.state.regs[1] = 1 << 63
cpu.state.regs[2] = MASK64
cpu.step(encode("DIV",3,1,2))
cpu.step(encode("REM",4,1,2))
assert cpu.state.regs[3] == 1 << 63 and cpu.state.regs[4] == 0

print("PASS: arithmetic, shifts, multiply, immediate, memory, branches, JAL and division edge cases")
