#!/usr/bin/env python3
"""MXISA-64 architectural reference interpreter for the H-series proposal.

Supported subset is explicit below. Unsupported assigned instructions raise
NotImplementedError; reserved encodings raise ValueError. Not an RTL simulator.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from encode import decode, fields, OPS

MASK64 = (1 << 64) - 1

@dataclass
class State:
    pc: int = 0
    regs: list[int] = field(default_factory=lambda: [0] * 32)
    halted: bool = False
    steps: int = 0

class MXISAReference:
    def __init__(self, memory=None, pc=0):
        self.state = State(pc=pc)
        self.memory = {} if memory is None else dict(memory)

    @staticmethod
    def sext(value, bits):
        sign = 1 << (bits - 1)
        return (value ^ sign) - sign

    def read(self, addr, size):
        if addr % size:
            raise ValueError(f"misaligned {size * 8}-bit load at 0x{addr:x}")
        return sum((self.memory.get(addr+i, 0) & 0xff) << (8*i) for i in range(size))

    def write(self, addr, size, value):
        if addr % size:
            raise ValueError(f"misaligned {size * 8}-bit store at 0x{addr:x}")
        for i in range(size):
            self.memory[addr+i] = (value >> (8*i)) & 0xff

    def load_program(self, data, address=0):
        for i, b in enumerate(data):
            self.memory[address+i] = b

    def fetch(self):
        pc = self.state.pc
        return self.read(pc, 4)

    def step(self, word=None):
        s = self.state
        if s.halted:
            return
        if word is None:
            word = self.fetch()
        f = fields(word)
        text = decode(word)
        if text.startswith(".word"):
            raise ValueError(f"illegal instruction 0x{word:08x} at PC 0x{s.pc:x}")
        name = text.split()[0]
        major = f["major"]
        rd, rs1, rs2 = f["rd"], f["rs1"], f["rs2"]
        a, b = s.regs[rs1], s.regs[rs2]
        next_pc = (s.pc + 4) & MASK64
        result = None

        if name == "NOP" or name in ("FENCE", "FENCE.I"):
            pass
        elif name == "HALT":
            s.halted = True
        elif name in ("ADD","SUB","AND","OR","XOR","NOR","SLT","SLTU",
                      "SLL","SRL","SRA","MUL","MULH","MULHU","DIV","DIVU","REM","REMU"):
            sh = b & 63
            if name == "ADD": result = a + b
            elif name == "SUB": result = a - b
            elif name == "AND": result = a & b
            elif name == "OR": result = a | b
            elif name == "XOR": result = a ^ b
            elif name == "NOR": result = ~(a | b)
            elif name == "SLT": result = int(self.sext(a,64) < self.sext(b,64))
            elif name == "SLTU": result = int(a < b)
            elif name == "SLL": result = a << sh
            elif name == "SRL": result = a >> sh
            elif name == "SRA": result = self.sext(a,64) >> sh
            elif name == "MUL": result = a * b
            elif name == "MULH": result = (self.sext(a,64) * self.sext(b,64)) >> 64
            elif name == "MULHU": result = (a * b) >> 64
            elif name == "DIV":
                sa, sb = self.sext(a,64), self.sext(b,64)
                if sb == 0: result = MASK64
                elif sa == -(1<<63) and sb == -1: result = 1<<63
                else:
                    q = abs(sa) // abs(sb)
                    result = -q if (sa < 0) != (sb < 0) else q
            elif name == "DIVU": result = MASK64 if b == 0 else a // b
            elif name == "REM":
                sa, sb = self.sext(a,64), self.sext(b,64)
                if sb == 0: result = a
                elif sa == -(1<<63) and sb == -1: result = 0
                else:
                    q = abs(sa) // abs(sb)
                    q = -q if (sa < 0) != (sb < 0) else q
                    result = sa - q * sb
            elif name == "REMU": result = a if b == 0 else a % b
        elif name in ("ADDI","ANDI","ORI","XORI","SLTI","SLTIU","SLLI","SRLI","SRAI",
                      "LB","LBU","LH","LHU","LW","LWU","LD","JALR"):
            imm = self.sext(f["imm12"],12)
            if name == "ADDI": result = a + imm
            elif name == "ANDI": result = a & (imm & MASK64)
            elif name == "ORI": result = a | (imm & MASK64)
            elif name == "XORI": result = a ^ (imm & MASK64)
            elif name == "SLTI": result = int(self.sext(a,64) < imm)
            elif name == "SLTIU": result = int(a < (imm & MASK64))
            elif name == "SLLI": result = a << (f["imm12"] & 63)
            elif name == "SRLI": result = a >> (f["imm12"] & 63)
            elif name == "SRAI": result = self.sext(a,64) >> (f["imm12"] & 63)
            elif name == "JALR":
                result = next_pc
                next_pc = (a + imm) & MASK64 & ~3
            else:
                size = {"LB":1,"LBU":1,"LH":2,"LHU":2,"LW":4,"LWU":4,"LD":8}[name]
                value = self.read((a+imm)&MASK64, size)
                bits = size*8
                if name in ("LB","LH","LW"): value = self.sext(value,bits)
                result = value
        elif name in ("SB","SH","SW","SD"):
            b = s.regs[rd]
            imm = self.sext(f["imm12"],12)
            size = {"SB":1,"SH":2,"SW":4,"SD":8}[name]
            self.write((a+imm)&MASK64, size, b)
        elif name in ("BEQ","BNE","BLT","BGE","BLTU","BGEU"):
            b = s.regs[rd]
            disp = self.sext(f["imm12"],12)
            take = {
                "BEQ": a == b, "BNE": a != b,
                "BLT": self.sext(a,64) < self.sext(b,64),
                "BGE": self.sext(a,64) >= self.sext(b,64),
                "BLTU": a < b, "BGEU": a >= b
            }[name]
            if take: next_pc = (s.pc + disp*4) & MASK64
        elif name == "JAL":
            disp = self.sext(f["disp26"],26)
            result = next_pc
            rd = 1
            next_pc = (s.pc + disp*4) & MASK64
        elif name == "LUI":
            result = self.sext(f["imm17"],17) << 47
        elif name == "AUIPC":
            result = s.pc + (self.sext(f["imm17"],17) << 47)
        elif name in ("ECALL","EBREAK","MRET"):
            raise NotImplementedError(f"{name} requires privileged/trap model")
        else:
            raise NotImplementedError(f"{name} not yet implemented in reference model")

        if result is not None and rd != 0:
            s.regs[rd] = result & MASK64
        s.regs[0] = 0
        if not s.halted:
            s.pc = next_pc
        s.steps += 1

    def run(self, max_steps=100000):
        while not self.state.halted and self.state.steps < max_steps:
            self.step()
        if not self.state.halted:
            raise TimeoutError("reference model reached max_steps without HALT")
        return self.state
