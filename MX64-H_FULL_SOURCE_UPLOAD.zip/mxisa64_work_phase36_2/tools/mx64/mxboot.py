#!/usr/bin/env python3
"""Pack or inspect an MX64-H boot-image envelope."""
import argparse
import json
from pathlib import Path
from boot_image import make_boot_image, parse_boot_image, PLATFORMS


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    pack = sub.add_parser("pack", help="wrap a linked ELF64 ET_EXEC")
    pack.add_argument("elf")
    pack.add_argument("-o", "--output", required=True)
    pack.add_argument("--platform", choices=sorted(PLATFORMS), default="generic")
    inspect = sub.add_parser("inspect", help="validate and display a boot image")
    inspect.add_argument("image")
    args = parser.parse_args()
    if args.command == "pack":
        result = make_boot_image(Path(args.elf).read_bytes(), args.platform)
        Path(args.output).write_bytes(result)
        meta = parse_boot_image(result)
        print(f"created {args.output}: platform={meta['platform']} entry=0x{meta['entry']:016x} payload={meta['payload_size']} bytes")
    else:
        meta = parse_boot_image(Path(args.image).read_bytes())
        summary = {k: meta[k] for k in ("version", "platform", "platform_id", "payload_type", "payload_offset", "payload_size", "entry", "sha256")}
        summary["load_segments"] = [
            {"vaddr": f"0x{p['vaddr']:016x}", "paddr": f"0x{p['paddr']:016x}",
             "filesz": p["filesz"], "memsz": p["memsz"], "flags": p["flags"], "align": p["align"]}
            for p in meta["elf"]["program_headers"] if p["type"] == 1
        ]
        print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
