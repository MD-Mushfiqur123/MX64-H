# Example writable data and zero-initialized memory for the MX64-H linker.
.data
.global demo_counter
demo_counter:
    .quad 0

.bss
.align 64
.global demo_buffer
demo_buffer:
    .space 128
