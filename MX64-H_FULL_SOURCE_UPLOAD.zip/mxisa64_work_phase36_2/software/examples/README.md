# MX64-H software build example

The Makefile's `example` and `boot-image` targets assemble and link three source files:

- `main.s`: exports `_start` and calls `worker`.
- `worker.s`: exports a separately linked function.
- `memory.s`: demonstrates `.data`, `.bss`, `.quad`, `.space`, and 64-byte BSS alignment.

The assembler supports a deliberately small multi-section subset: `.text`, `.data`, `.bss`, `.section`, `.global`, `.extern`, `.align`, `.byte`, `.word`, `.quad`, `.space`, and `.zero`. `.align` is a byte alignment and must be a power of two no greater than 4096. Instructions are accepted only in `.text`.

The linker emits separate RX and RW `PT_LOAD` segments. Initialized `.data` bytes contribute to `p_filesz`; `.bss` contributes to `p_memsz` and must be zeroed by a future platform loader. Relocations currently include MX64-H branch/jump fields, ABS32 and ABS64. This is a prototype format and not a registered ABI.
