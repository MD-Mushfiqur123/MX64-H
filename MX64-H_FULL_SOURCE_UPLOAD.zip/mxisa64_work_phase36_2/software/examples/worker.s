.global worker
worker:
    ADDI x10, x10, 5
    JALR x0, x1, 0
