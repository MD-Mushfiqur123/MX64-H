.global _start
.extern worker
_start:
    ADDI x10, x0, 7
    JAL worker
    HALT
