# MX64-H Software Toolchain Roadmap

## Goal

Deliver a complete software-facing development path without claiming that a production compiler or operating system exists before the ISA, ABI, and platform contracts are frozen.

## Components and dependency order

| Stage | Component | Deliverable | Depends on |
|---|---|---|---|
| T0 | ISA source of truth | Opcode CSV + machine-readable spec | H1 ISA decisions |
| T1 | Assembler/disassembler | Python CLI, diagnostics, round-trip tests | T0 |
| T2 | Reference interpreter | Deterministic architectural model | T0 |
| T3 | Test generator | Directed, boundary, random instruction streams | T0–T2 |
| T4 | Object format | ELF64 machine ID, relocations, sections | ABI freeze |
| T5 | Linker | Static link, map file, relocation checks | T4 |
| T6 | LLVM backend | Codegen, MC, assembler, disassembler | T0, T4, stable ABI |
| T7 | Debugger | GDB target description + remote stub | Debug architecture |
| T8 | Runtime | crt0, compiler builtins, minimal libc | Syscall/platform ABI |
| T9 | OS enablement | Boot protocol, interrupt controller, MMU, drivers | Platform + privileged ISA |

## Engineering rules

- Generate opcode tables and decoder constants from a single machine-readable source; do not hand-maintain duplicate maps.
- Reject reserved encodings and report the exact instruction word and PC.
- Every instruction needs semantics, encoding, exception behavior, and at least one directed test before being marked supported.
- Reference model behavior must be independent enough from RTL to detect common implementation errors.
- Toolchain compatibility is versioned; incompatible ISA changes increment the ISA major version.
- Do not implement LLVM backend against an unstable opcode table; build a Python prototype first.


## Current software prototype status

- `tools/mx64/encode.py`: CSV-backed candidate encoder/disassembler for canonical instruction forms.
- `tools/mx64/isa_model.py`: executable interpreter for a documented subset; unsupported privileged instructions fail explicitly.
- `tools/mx64/audit_isa.py`: static table/format/round-trip audit.
- `tools/mx64/smoke_test.py`: software-only interpreter smoke program.
- These scripts do not prove RTL correctness and do not close H1. The opcode CSV still contains extension entries that are inventory-only and are not all executable.

- `tools/mx64/architecture_tests.py`: broader architectural regression tests for arithmetic, shifts, memory, control flow, and division edge cases.

## Phase 4 implementation status (software prototype)

- Two-pass source assembler: implemented for the current candidate instruction subset.
- Local labels and signed PC-relative branch/JAL label resolution: implemented.
- `offset(xN)` memory operand syntax: implemented for load/store/JALR forms.
- `.word` and `.space` directives: implemented.
- Flat little-endian binary output, symbol map, and disassembly listing: implemented.
- Limitations: no macros, includes, sections, ABI pseudo-instructions, external symbols, ELF object emission, relocation records, or linker yet. ISA encodings remain proposal status.

## Phase 5 implementation status (ELF prototype)

- ELF64 little-endian header and section-table writer/parser: implemented.
- Private experimental e_machine identifier `0xFE64`: assigned for prototype artifacts; not an upstream ABI registration.
- ET_REL writer with `.text`, `.symtab`, `.strtab`, `.shstrtab`: implemented.
- ET_EXEC image writer and `.text`-only static linker: implemented.
- Global symbol table collection and entry-symbol selection: implemented.
- Limitations: no relocation sections or relocation application yet; no section merging beyond `.text`; no GOT/PLT, dynamic linking, program headers, ABI-complete executable loader, or external tool compatibility guarantee. This is an internal prototype, not a production linker.

## Phase 6 implementation status (relocation prototype)

- ELF64 `.rela.text` emission with explicit addends: implemented.
- External/global symbol declarations in assembler: `.extern` and `.global` supported.
- Relocation types: `R_MX64H_BRANCH12`, `R_MX64H_JUMP26`, `R_MX64H_ABS32`.
- Cross-object global symbol resolution and relocation overflow/undefined-symbol checks: implemented.
- Linker remains `.text`-only; no section groups, weak symbols, local symbol scoping, archives, COMDAT, GOT/PLT, TLS, dynamic linking, or full System V ABI compatibility.
- Relocation definitions are provisional and must be frozen with ISA/ABI before external binary compatibility.

## Phase 7 implementation status (ABI and platform groundwork)

- ABI draft revision 0.2: explicit integer register roles, call sequence, stack alignment, preserved registers and FPGA/ASIC platform split.
- Static ABI/toolchain consistency checker: implemented.
- Bare-metal startup source skeleton and limitations documented; not runnable until reset vector, stack symbol and absolute-address relocation are implemented.
- ELF section cross-reference corrected for `.rela.text` and `.symtab`.
- Not implemented: complete C ABI, libc, syscall ABI, trap frame, TLS, FPU/vector ABI, linker scripts, boot ROM and platform memory map.

## Phase 8 implementation status (reproducible software build)

- `mxbuild.py`: one-command multi-file assembly, ET_REL emission and static link.
- Cross-translation-unit symbol resolution exercised by `software/examples`.
- Makefile targets: `check`, `test`, `example`, `clean`.
- GitHub Actions workflow for Python toolchain checks.
- Map file output for prototype global symbols.
- Limitation: CI does not run HDL lint/simulation/formal/synthesis. ET_EXEC still lacks program headers and a hardware boot/loader contract.

## Phase 9 implementation status (loadable ELF executable prototype)

- ET_EXEC now contains an ELF64 program-header table with one page-aligned RX `PT_LOAD` segment.
- The loader-visible segment carries file size, memory size, virtual/physical address and alignment; section metadata remains available for tooling.
- ELF parser validates program-header bounds, segment file/memory sizes, power-of-two alignment, address/offset congruence, section-name table bounds and section-name offsets.
- Linker output entry point is checked to lie inside the executable text segment when nonzero.
- Regression covers PT_LOAD fields and rejects a deliberately corrupted out-of-bounds segment.
- Limitations: single flat RX segment only; no writable data/BSS, multiple load segments, relocatable address layout, boot ROM contract, privilege transition, platform-specific memory map, or hardware loader. `EM_MX64H=0xFE64` remains private and experimental; this is not a registered system ABI.


## Phase 10 implementation status (platform contract and boot-image envelope)

- Version-1 MX64-H boot-image container: fixed 128-byte header, platform selector (`generic`, `fpga`, `asic`), ELF64 ET_EXEC payload metadata, entry point and SHA-256 payload integrity field.
- Pack/inspect CLI and tests for platform IDs, truncation, payload-length mismatch, bad magic and payload corruption.
- FPGA and ASIC platform templates now identify unresolved board/SoC, PADDR width, reset-vector, boot-source and memory-map values without inventing addresses.
- Static platform validator checks template shape, configured ranges, overlap, address-width limits and completeness when requested.
- `make boot-image` composes the existing example build with the envelope packer.
- Not implemented: hardware boot ROM, loader firmware, segment relocation/copy/zero routine, privilege transition, authenticated signature, anti-rollback, encryption, compression, flash layout, board constraints or a tested FPGA/ASIC boot. A real loader must enforce the platform memory map before writing any PT_LOAD segment.

## Phase 11 implementation status (multi-section ELF and BSS)

- Assembler supports `.text`, `.data`, `.bss`, `.section`, `.global`, `.extern`, `.align`, `.byte`, `.word`, `.quad`, `.space`, and `.zero` in a constrained prototype subset. Instructions are accepted only in `.text`; `.align` is a byte alignment (power of two up to 4096).
- ET_REL writer emits `SHT_NOBITS` for `.bss`, local/global symbol bindings, and per-section RELA sections.
- Linker merges input `.text`, `.data`, and `.bss`, respects input section alignment, resolves local/global/undefined symbols, and applies branch/jump, ABS32 and ABS64 relocations.
- ET_EXEC now contains separate RX and RW `PT_LOAD` segments. Initialized data contributes to `p_filesz`; BSS contributes to the RW segment's `p_memsz` and is emitted as `SHT_NOBITS` without file bytes. Section file offsets point into their containing load segments.
- Boot-image validation rejects writable-executable PT_LOAD segments, overlapping PT_LOAD memory ranges, and 64-bit address-range overflow.
- `multisection_tests.py` covers cross-object branches, absolute 64-bit data relocation, section alignment, RX/RW segment flags, BSS size/zero-fill contract and parser rejection cases.
- The example build includes `memory.s` to exercise initialized data and 64-byte-aligned BSS.
- `load_image.py` provides a software reference model for platform-ID matching, PADDR limits, RAM/ROM/MMIO policy, permissions, segment preflight and BSS zero-fill. It does not perform device writes and is not hardware loader firmware.
- Limitations: no section garbage collection, weak/common symbols, archives, COMDAT, relocations other than the current four private types, GOT/PLT, TLS, dynamic loader, linker script language, stack/heap ABI, platform loader firmware, or external ELF ABI registration. BSS zeroing is a loader obligation, not performed by the container utility.


## Phase 11.1 implementation status (ELF and loader hardening)

- Multi-section ELF path now exercised by a three-source example with RX code, RW initialized data and aligned BSS.
- `make boot-image` packs and inspects the resulting two-segment image; the loader reference tests BSS zero-fill.
- Static RTL audit is now part of `make check`; it catches duplicate module declarations and verifies the shared ROB-tag/epoch-width contract.
- The ROB uses a 14-bit tag in the current 48-entry profile (6-bit slot index + 8-bit epoch). Epoch wrap and cancellation of pre-flush memory requests remain verification obligations.
- HDL compile/simulation/formal/synthesis remain deferred by project policy.
