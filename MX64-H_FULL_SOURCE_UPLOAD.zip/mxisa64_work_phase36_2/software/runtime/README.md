# MX64-H runtime bootstrap

`crt0_mx64h.s` is a bring-up skeleton only. It is intentionally not described as a complete startup runtime: the current ISA/toolchain lacks a frozen absolute-address relocation, platform reset contract, stack initialization sequence, trap ABI and syscall ABI. The `ADDI sp, zero, 0` line is a placeholder that must be replaced by platform-specific startup before hardware execution. No libc is claimed.
