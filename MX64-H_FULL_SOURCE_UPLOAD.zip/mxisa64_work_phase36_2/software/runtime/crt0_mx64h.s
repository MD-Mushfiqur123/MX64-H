# MX64-H bare-metal runtime entry prototype.
# Platform integration must supply __stack_top and _mx64_main.
.global _start
.extern _mx64_main
.extern __stack_top

_start:
    # Initialize stack pointer. Linker relocation for absolute address is pending
    # in this startup source; use a platform-generated constant for current tools.
    ADDI x2, x0, 0
    JAL _mx64_main
halt_forever:
    HALT
    JAL halt_forever
