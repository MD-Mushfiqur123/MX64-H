# MX64-H Software ABI Draft

**Revision:** 0.2 — provisional internal ABI; not stable for external binary distribution.

## Execution and data model
- XLEN = 64; byte = 8 bits; little-endian.
- Pointers and `size_t` are 64-bit.
- Instructions are fixed-width 32-bit and instruction addresses are 4-byte aligned.
- Stack grows downward. `sp` (x2) is 16-byte aligned at every public call boundary.
- No red zone is reserved below `sp`.
- Caller must assume temporaries are clobbered by calls.
- Aggregate layout, bitfield layout, `long double`, variadic register-save areas, TLS and C++ ABI remain unspecified.

## Register convention (provisional)
| Register | ABI name | Role | Preservation |
|---|---|---|---|
| x0 | zero | hardwired zero | immutable |
| x1 | ra | return address | caller-saved |
| x2 | sp | stack pointer | callee-saved |
| x3 | gp | global pointer | reserved |
| x4 | tp | thread pointer | reserved |
| x5–x7 | t0–t2 | temporaries | caller-saved |
| x8–x9 | s0–s1 | saved | callee-saved |
| x10–x17 | a0–a7 | arguments / return values | caller-saved |
| x18–x27 | s2–s11 | saved | callee-saved |
| x28–x30 | t3–t5 | temporaries | caller-saved |
| x31 | t6 | platform scratch | caller-saved unless platform reserves |

## Call sequence
1. Caller places the first eight integer/pointer arguments in x10–x17.
2. Additional arguments are placed on the stack in ascending argument order; exact aggregate classification is not yet frozen.
3. Caller ensures `sp % 16 == 0` immediately before `JAL/JALR`.
4. Callee may use x5–x7 and x28–x31 without saving.
5. Callee must preserve x2, x8–x9 and x18–x27.
6. Scalar integer/pointer return value is in x10; second word, if required, is in x11.
7. Return uses `JALR x0, x1, 0`.

## Stack frame convention
- `sp` points to the lowest-addressed byte of the active frame.
- Frame size is a multiple of 16.
- Saved registers and local slots are addressed at non-negative offsets from the new `sp`.
- A frame pointer is optional; if used, x8 is the frame pointer and must be restored.
- No mandatory home slots for register arguments are defined yet.

## Object and relocation ABI
- Internal ELF64 little-endian prototype uses private experimental `e_machine=0xFE64`; this is not registered and must not be distributed as a stable machine ABI.
- `R_MX64H_BRANCH12`: signed 12-bit instruction-word displacement, relative to address of relocation place.
- `R_MX64H_JUMP26`: signed 26-bit instruction-word displacement, relative to address of relocation place.
- `R_MX64H_ABS32`: absolute 32-bit value.
- Relocation types and field layouts remain tied to the current candidate ISA and may change before ISA freeze.
- No GOT/PLT, TLS, dynamic loader, unwind or exception ABI exists yet.

## Platform profiles
- **FPGA bring-up:** bare-metal, one hart, machine mode only; reset vector and memory map are platform configuration, not ISA constants.
- **ASIC bring-up:** same architectural ABI; clock/reset, memory controller, debug transport, interrupt controller and boot ROM are SoC integration contracts.
- The FPGA and ASIC platforms must share the same instruction/ELF ABI. Platform-specific device addresses belong in a platform header/linker script, not compiler assumptions.

## Explicitly unresolved
- Full C ABI classification, variadic calls, aggregate passing/return, stack argument alignment.
- Syscall ABI, interrupt/trap frame, context switch and TLS.
- Floating-point/vector calling convention.
- C++ name mangling, exceptions, RTTI and unwind format.
- Stable ELF machine registration and compatibility policy.
