# Build Phase Policy

## Current phase: architecture and software collateral

Allowed now:
- Architecture/requirements authoring and review.
- ISA/ABI specification and consistency analysis.
- Python reference tooling and static checks.
- RTL authoring, module-contract review, source audits.
- Testbench/assertion/formal collateral authoring.
- Build, lint, simulation, formal, synthesis, and physical-design scripts authoring.
- Documentation, traceability, and reproducible packaging.

Deferred until final verification gate:
- Running HDL simulation.
- Running formal proofs.
- Running synthesis.
- Running place-and-route or timing closure.

The deferral is a project sequencing decision, not a statement that these activities are unnecessary. They remain mandatory before implementation claims.

## Status vocabulary
- `DRAFT`: content exists but requires architecture review.
- `OPEN`: not implemented or not evidenced.
- `STATIC-CHECKED`: syntax/structure/consistency check only.
- `VERIFIED`: evidence from the declared verification activity exists.
- `FROZEN`: approved interface/architecture; changes require versioned decision.
