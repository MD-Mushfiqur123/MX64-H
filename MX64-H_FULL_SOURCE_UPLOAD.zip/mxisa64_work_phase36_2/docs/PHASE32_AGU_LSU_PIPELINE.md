# MX64-H Phase 32 — AGU and LSU Pipeline Integration Slice

## Scope

Phase 32 adds a 64-bit byte-address AGU and a single-request LSU front-end composition. It composes the existing Phase 30 physical-tag lifetime manager with the Phase 31 conservative store-ordering/byte-forwarding primitive. It is an integration slice, not a complete LSU or core-level memory pipeline.

## Address generation

`mx64_address_generation_unit` computes `effective_addr = base_value + immediate`. `size_log2` encodes 1, 2, 4, or 8 bytes. The unit emits a low-contiguous byte mask and flags invalid sizes or natural-alignment violations. Address values are byte addresses; lane zero corresponds to the effective address.

## Pipeline behavior

`mx64_lsu_pipeline` accepts one load or store request at a time:

- Loads require a free load-lifecycle slot and `memory_ordering_unit.load_can_issue`. A younger load is held while any older store address is unresolved or an overlapping older store has unresolved data.
- Stores require both a free LSU lifecycle slot and a free memory-ordering store slot. Address and data are considered resolved at allocation in this integration slice.
- Store allocation captures sequence, effective byte address, byte mask, and store data in the ordering queue.
- The load path exposes per-byte forwarding mask/data and a full-forwarding indication. If only some bytes forward, the external memory path must merge forwarded bytes with returned memory bytes.
- Load/store base and store-data physical tags are acquired/released by the Phase 30 lifecycle manager. The wrapper exposes those events for the shared physical-register reference tracker.
- The accepted LSU lifecycle slot and store-ordering slot are exported separately; they are distinct slot namespaces and must not be interchanged.
- `req_fault_valid` reports invalid size or natural misalignment. Faulting requests are not accepted; the surrounding precise-exception controller must consume the fault and flush/redirect as appropriate.

## Queue protocol

The producer must hold request fields stable while `req_valid` is asserted and `req_ready` is low. Completion/replay inputs refer to the lifecycle slot returned at acceptance. Store retirement refers to the separate ordering slot returned at store acceptance. The producer must not retire an inactive ordering slot. Sequence numbers must remain monotonic without wrapping while older stores are live, as specified by Phase 31.

## Correctness fix found during integration

The Phase 30 lifecycle manager and Phase 31 ordering queue previously initialized allocation-ready high when not flushing, which could incorrectly advertise capacity even when every slot was occupied. Phase 32 corrects both allocators to default `ready=0` and assert readiness only when an actual free slot is found.

## Boundaries and unverified work

- The LSU pipeline is not yet instantiated in `mx64_frontend_dispatch` or `mx64_top`; its request, completion, retirement, and fault interfaces remain external.
- There is no cache/TLB/MMU/bus path, load-response assembly, store commit-to-memory engine, replay scheduler, speculative load-violation detector, fence/atomic path, MMIO ordering, or cache-coherence protocol.
- The request interface is single-wide and assumes a 64-bit datapath.
- Static source-contract checks and software tests do not establish SystemVerilog correctness. No HDL compiler, elaboration, simulation, formal verification, or synthesis was run.
