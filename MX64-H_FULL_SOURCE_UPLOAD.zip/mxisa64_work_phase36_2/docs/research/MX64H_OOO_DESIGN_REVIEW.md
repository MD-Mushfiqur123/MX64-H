# MX64-H OoO Design Review — literature-derived engineering notes

## Sources reviewed
- Celio et al., *The Berkeley Out-of-Order Machine (BOOM): An Industry-Competitive, Synthesizable, Parameterized RISC-V Processor*, UC Berkeley EECS-2015-167.
- Celio et al., *BOOM v2: an open-source out-of-order RISC-V core*, UC Berkeley EECS-2017-157.
- BOOM online documentation, especially ROB/dispatch and issue-unit descriptions.
- OpenHW CVA6 documentation, used as an FPGA/ASIC integration and production-flow reference (CVA6 is in-order; it is not an OoO design analogue).

## Design implications for MX64-H
1. The ROB must be the architectural commit-order authority. Execution completion marks entries ready; only the head may commit. Exceptions become visible only at the head, and younger speculative state must be discarded.
2. Issue windows should be partitioned by execution class (integer, FP, memory) or provide rigorously specified functional-unit eligibility and port arbitration. A generic integer queue must not accept loads/stores/branches.
3. Physical register renaming requires a committed map, speculative map, free-list checkpoint/recovery, and old physical destination reclamation only after commit.
4. Wakeup/select must handle same-cycle broadcasts, multiple matching wakeup ports, and deterministic age selection. Execution-port backpressure must be represented in ready/valid contracts.
5. Load/store ordering needs separate load/store tracking, store address/data readiness, forwarding, replay and precise exception behavior. A cache hierarchy alone is not an LSU.
6. FPGA-first and ASIC-later should share the same synthesizable RTL and architectural tests; platform wrappers, memory macros, clocks, reset, debug and constraints should be separate.
7. Open-source reference implementations are design evidence, not permission to copy incompatible ISA/ABI details. MXISA-64 remains custom and all behavior must be defined in its own spec.

## Current source audit findings to close before calling the core integrated
- Top-level `mx64_top.sv` is still a shell; there is no complete fetch/decode/rename/dispatch/execute/commit datapath.
- Integer execution cluster only implements ALU operations. It explicitly excludes memory and branch execution.
- CSR module is an initial machine-mode subset, not a complete privileged architecture or trap/interrupt controller.
- No complete LSU, MMU/TLB/page walker, cache-coherence fabric, debug module or platform SoC exists.
- Existing module drafts require lint/compile, reset review, handshake review, parameter-boundary tests and formal assertions before integration claims.

## FPGA/ASIC project policy
- First FPGA milestone: single-hart bare-metal integer subset, on-chip memory, UART or simple host interface, deterministic reset and a traceable test image.
- ASIC preparation milestone: technology-independent RTL, inferred RAM abstraction, explicit clock/reset domains, synthesis constraints, scan/DFT hooks and physical-design handoff collateral.
- Do not claim a target frequency, IPC, area, power or silicon readiness until measured in the corresponding flow.
