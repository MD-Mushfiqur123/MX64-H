# AMD Zen Public Reference Study — MX64-H

## Source boundary
Primary public source: AMD GPUOpen, *AMD Ryzen Processor Software Optimization*, GDC 2024:
https://gpuopen.com/download/GDC2024_AMD_Ryzen_Processor_Software_Optimization.pdf

The public Zen 4 slide (page 15 in the presentation) shows a simplified block diagram and selected throughput/capacity facts. It is not an internal RTL or complete microarchitecture specification.

## Publicly stated Zen 4 facts on the slide
- 32 KiB, 8-way instruction cache.
- Decode: 4 instructions/cycle.
- Op cache: 9 macro-ops/cycle.
- Dispatch: 6 macro-ops/cycle.
- Separate integer and floating-point rename domains.
- Multiple scheduler blocks.
- Load/store diagram labels 3 loads/cycle and 2 stores/cycle.
- 32 KiB, 8-way D-cache.
- 1 MiB, 8-way unified L2.
- Slide text says Op Cache increased to 6.75K ops and L2 increased from 512 KiB to 1024 KiB.

## What this source does not establish
It does not establish the exact ROB size, exact physical-register count, all queue depths, predictor algorithm, every execution latency, cache MSHR count, full pipeline stage timing, or complete arbitration behavior. MX64 documentation must not attribute guessed values to AMD.

## MX64 use
The public diagram is a reference for system balance: front-end delivery, rename, dispatch, scheduling, execution, load/store, and cache bandwidth must be designed together. MX64 targets in its own documents are independent engineering proposals and require later PPA/benchmark evidence.
