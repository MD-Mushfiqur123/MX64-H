# MX64-H research and specification update — 2026-11-25

## Scope and evidence rules

MX64-H is a private, experimental ISA and microarchitecture. RISC-V papers and specifications below are used as comparative engineering references, not evidence of ISA compatibility, measured MX64 performance, or endorsement. The project distinguishes normative standards, published research, implementation documentation, and local engineering hypotheses.

## Current public specification baseline

The official RISC-V International Ratified Specifications Library currently lists the Unprivileged ISA and Privileged ISA as version **v20260120 (January 2026)**. The same library lists the Server Platform specification v1.0 (May 2026), IOMMU v20260222, and Efficient Trace (E-Trace) v2.1 (October 2026). These are useful system-integration reference points, but MX64-H is not RISC-V compatible and must define its own ISA, privilege model, platform ABI, interrupt model, DMA/IOMMU contract, and trace format before claiming equivalent support.

A third-party-hosted 20261002 intermediate ISA release was also found. It is not presented as a ratified release by the official RISC-V library and is therefore not used as the normative baseline.

## Out-of-order microarchitecture references

### XiangShan Kunminghu V2R2 design documentation

The current public XiangShan design document page identifies its contents as the Kunminghu V2R2 microarchitecture. Its documented block inventory includes a multi-level frontend predictor structure (micro/advance/main BTBs, TAGE-family prediction, statistical correction, indirect-target prediction and RAS), fetch-target queue, rename/dispatch/ROB, scheduling/issue queues, bypass and writeback paths, separate integer/FP/vector/memory function units, load/store queues, replay and exception structures, TLB/page-table walkers, PMP/PMA, and a hierarchical cache subsystem.

**MX64-H implication:** the present MX64-H direct-mapped BTB with a 2-bit direction counter is only a bring-up placeholder. Do not infer high-performance prediction from it. First implement correct redirect/flush/checkpoint recovery and precise retirement; then measure target accuracy, branch MPKI, redirect latency, refetch latency, wrong-path work, lost issue slots, and workload IPC before choosing TAGE-like or other structures. Treat LSQ load replay, store commit buffering, uncacheable accesses, misalignment, and load/store exceptions as independent design requirements, not extensions to a single queue.

### Branch misprediction cost in a superscalar OoO model (2026)

Fu et al., *Predictor-Dependent Amplification of Branch Mispredictions in Out-of-Order Superscalar Processors: A RISC-V gem5 O3 Study*, Applied Sciences 16(16), 8112 (14 August 2026), evaluates RV64GC workloads using gem5 DerivO3CPU. It separates prediction error frequency from effective recovery penalty and unrealized issue capacity. Its reported numeric deltas are conditional on that model and workload set; they are not universal constants and must not be copied as MX64-H performance claims.

**MX64-H implication:** predictor accuracy alone is an insufficient acceptance metric. The future performance suite must collect at least IPC, branch MPKI, branch-mispredict count, cycles to redirect/restart, wrong-path uops squashed, average/maximum ROB occupancy during recovery, and issue-slot utilization around recovery. Compare the same RTL/workload with predictor variants while holding other configuration parameters constant.


### Newer XiangShan Kunminghu V2R2A block-level design pages (13 October 2026)

The newer V2R2A pages provide finer-grained, versioned evidence than the older Kunminghu V2R2 overview. The IssueQueue page is dated 2026-10-13 and describes separate issue-queue classes, two enqueue/dequeue ports, oldest-ready selection, speculative wakeup, and early detection of execution-unit and register-file writeback conflicts. It also documents age tracking and wakeup timing structures. The Rename page describes speculative and committed rename state, free-list updates, redirect recovery, and snapshots. These are design-document facts for XiangShan, not a normative template that MX64-H must copy.

**MX64-H implication:** the current small issue queue's two-bus combinational wakeup and oldest-ready CAM scan are a functional prototype only. They do not yet model FU reservation conflicts, writeback-port conflicts, multiple issue classes, or a timing-closed wakeup network. Before increasing issue width, define (a) execution-port reservation, (b) multi-completion wakeup arbitration, (c) age ordering across queue classes, (d) flush/replay cancellation, and (e) structural backpressure. Likewise, rename needs both speculative and committed maps plus checkpoint/snapshot recovery and commit-time old-physical-register release; the current draft does not yet close that loop.

The XiangShan user guide's published Kunminghu V2 configuration lists a 6-wide decode/rename, 8-wide commit, 160-entry ROB, 224 integer physical registers, 72-entry load queue, and 56-entry store queue. It is a useful reality check that backend structures scale together; these values are not proposed as direct MX64-H parameters and are not transferable performance guarantees.

### Formal verification research (2026)

The June 2026 paper *χRVFormal: Formal verification of RISC-V processor Chisel designs* presents an end-to-end formal verification approach at the Chisel level. Its source is not a SystemVerilog toolchain and the publisher page was not accessible for full-text inspection in this review, so it is recorded as a research lead rather than a directly reusable verification recipe. The key project-level conclusion remains: MX64-H's handwritten SystemVerilog needs its own elaboration, simulation, assertion and formal plan; a Chisel-based paper cannot stand in for those results.

## FPGA/ASIC implementation and verification references

OpenHW's current CVA6 documentation describes a parameterized SystemVerilog core family targeting FPGA and ASIC, with shared 32/64-bit source and options such as MMU, PMP, FPU, cache configurations, and performance counters. CVA6 is useful as a platform integration, module-contract, and verification-process reference. Its in-order organization is not an OoO backend template for MX64-H.

The 2025 open-access survey *Survey of Verification of RISC-V Processors* reviews simulation-based, formal, self-checking, coverage-oriented and security verification approaches. IEEE Std 1800-2023 remains the active SystemVerilog language standard. These sources reinforce that source inspection is not equivalent to compilation or verification: MX64-H needs lint/elaboration, directed and constrained-random simulation, architectural differential testing, assertions, formal proof of bounded control properties, and synthesis/STA before implementation claims are made.

## ELF executable and boot image correctness

The System V gABI program-loading specification defines `PT_LOAD` program headers and the distinction between `p_filesz` and `p_memsz`. Loadable segment `p_vaddr` and `p_offset` must be congruent modulo `p_align`; `p_align` is zero/one or a power of two. Bytes in the memory image beyond the file image are zero-filled by the loader. MX64-H's software ELF prototype now emits separate RX and RW load segments, with `.bss` represented as `SHT_NOBITS` and included in the RW segment's `p_memsz` without consuming file bytes. This remains a private experimental machine format: no upstream `e_machine` registration, platform loader, privilege handoff, or external-toolchain ABI compatibility is claimed.

## Decisions and open risks

1. Keep the ISA private and freeze instruction semantics/encodings before LLVM or C compiler integration.
2. Keep board/SoC facts unresolved until an actual FPGA board or ASIC process is selected; do not invent PADDR width, reset vector, memory addresses, SRAM behavior, or clock targets.
3. Introduce a concrete platform loader only after a board/SoC map and boot source are known. It must validate all segment destinations before any write, enforce RAM permissions/ranges, copy file bytes, zero BSS, initialize stack and architectural state, and only then branch to entry.
4. SHA-256 in the current boot-image envelope detects corruption; it is not authentication. Secure boot requires an explicit threat model, signature verification, key lifecycle and anti-rollback policy.
5. Hardware claims remain blocked until the final RTL is compiled, simulated, formally checked where practical, synthesized, timed, and measured on the selected implementation flow.

## Sources (checked 2026-11-25)

- RISC-V International, Ratified Specifications Library: https://docs.riscv.org/reference/home/
- RISC-V ISA manuals, official v20260120: https://docs.riscv.org/reference/isa/v20260120/index.html
- RISC-V Server Platform v1.0, listed by the official library: https://docs.riscv.org/reference/home/
- XiangShan Team, Kunminghu V2R2A IssueQueue page (dated 2026-10-13): https://docs.xiangshan.cc/projects/design/en/kunminghu-v2r2a/backend/Schedule_And_Issue/IssueQueue/
- XiangShan Team, Kunminghu V2R2A Rename page: https://docs.xiangshan.cc/projects/design/en/kunminghu-v2r2a/backend/CtrlBlock/Rename/
- XiangShan Team, Kunminghu V2R2A architecture overview: https://docs.xiangshan.cc/projects/design/en/kunminghu-v2r2a/overview/
- XiangShan User Guide, Kunminghu V2 typical configuration: https://docs.xiangshan.cc/projects/user-guide/en/kunminghu-v2/typical-configuration/
- Fu et al. (2026), branch misprediction amplification study: https://doi.org/10.3390/app16168112
- OpenHW Foundation, CVA6 user documentation: https://docs.openhwfoundation.org/projects/cva6-user-manual/01_cva6_user/Introduction.html
- Tain, Patil and Al-Asaad (2025), *Survey of Verification of RISC-V Processors*: https://doi.org/10.1007/s10836-025-06169-3
- *χRVFormal: Formal verification of RISC-V processor Chisel designs* (Journal of Systems Architecture 175, June 2026): https://doi.org/10.1016/j.sysarc.2026.103761
- IEEE Std 1800-2023, SystemVerilog: https://standards.ieee.org/ieee/1800/7743/
- System V gABI, Program Loading: https://gabi.xinuos.com/elf/08-pheader.html
- BOOM technical reports: https://www2.eecs.berkeley.edu/Pubs/TechRpts/2015/EECS-2015-167.html and https://www2.eecs.berkeley.edu/Pubs/TechRpts/2017/EECS-2017-157.html


## Phase 12 research-driven RTL contract review (25 November 2026)

The latest official RISC-V library page checked on 2026-11-25 lists ratified Unprivileged and Privileged ISA v20260120, plus a Server Platform v1.0 (May 2026), IOMMU v20260222, E-Trace v2.1 (October 2026), and Boot and Runtime Services v1.0 (August 2025). These are useful comparison points for platform completeness. They do not define MX64-H behavior; MX64-H must specify its own corresponding contracts or explicitly omit them. A third-party 20261002 intermediate release is not treated as normative because it is not the official ratified library entry.

The XiangShan Kunminghu V2R2A IssueQueue design page (dated 2026-10-13) explicitly documents two enqueue/dequeue ports, oldest-ready issue, age tracking, speculative wakeup, and early FU/register-file writeback conflict detection. Its design separates issue-queue classes and includes wakeup timing structures. The current MX64-H issue queue is a single small integer queue with same-cycle combinational wakeup and age scan; it has no FU reservation table, cross-queue age arbitration, or writeback-port conflict model. It is therefore a functional draft, not a timing-closed high-performance scheduler. The current module also has a dual-wide implementation contract, now made explicit in its source assertions.

Phase 12 hardening widens the ROB per-slot epoch from 8 to 16 bits, making the current 48-entry profile's tag 22 bits (6-bit slot + 16-bit epoch). This reduces the chance of stale completion aliasing but does not eliminate epoch wrap. The backend must still cancel or drain all pre-flush long-latency operations before an epoch can wrap onto a still-live stale result. The ROB occupancy update now derives from the number of accepted allocations and retirements rather than hand-written two-lane arithmetic. Rename recovery forces x0 to physical zero, and free-list recovery masks the architectural physical-register range so checkpoint corruption cannot mark those registers free. These changes are source-level hardening; no HDL compiler, simulator, formal engine, or synthesis tool was run.

### Updated sources checked 2026-11-25

- RISC-V International Ratified Specifications Library (official current listing): https://docs.riscv.org/reference/home/
- RISC-V Unprivileged ISA v20260120 official entry: https://docs.riscv.org/reference/isa/v20260120/index.html
- XiangShan Kunminghu V2R2A IssueQueue (version V2R2A, date 2026-10-13): https://docs.xiangshan.cc/projects/design/en/kunminghu-v2r2a/backend/Schedule_And_Issue/IssueQueue/
- XiangShan Kunminghu V2R2A architecture overview: https://docs.xiangshan.cc/projects/design/en/kunminghu-v2r2a/overview/
- XiangShan V2R2A source/version notice (verified 2026-10-16): https://docs.xiangshan.cc/projects/design/en/kunminghu-v2r2a/
