# Open-Core Research Notes

## Berkeley BOOM
Documentation: https://docs.boom-core.org/en/latest/
Useful subjects:
- Pipeline and speculative execution.
- Branch prediction and predictor recovery.
- Rename maps, free lists, busy tables and branch snapshots.
- Issue queues and wakeup/select.
- ROB allocation, precise exceptions, in-order commit and stale destination reclamation.

MX64 application: treat rename recovery, ROB age identity and commit-time physical-register reclamation as architectural correctness contracts. Avoid naïve free-list bitmap restoration that can double-allocate or leak registers.

## OpenHW CVA6
Documentation: https://docs.openhwfoundation.org/projects/cva6-user-manual/
Useful subjects:
- Application-class core scope: caches, optional MMU/PMP/FPU, CSR, counters and AXI interface.
- LSU composition: load/store path, DTLB, page-table walker, MMU and nonblocking cache.
- Stores are held until commit authorization; loads can issue earlier subject to memory attributes and ordering.
- Multiplier/divider implementation choices and latency tradeoffs.
- Configurable TLB, BTB, BHT, return stack and commit parameters.

MX64 application: write requirements and parameter contracts before implementation. Keep device/MMIO operations conservative and ensure speculative stores cannot become externally visible before commit.

## Formal verification
SymbiYosys documentation: https://symbiyosys.readthedocs.io/en/stable/
Supports bounded/unbounded safety properties, cover generation and liveness tasks. Formal collateral is planned for local invariants and selected cross-module properties; tool execution is deferred to the final verification phase.

## Simulation and lint
Verilator documentation: https://verilator.org/guide/latest/
Verilator translates/lints SystemVerilog and can build executable models. Cocotb can provide Python-driven verification environments. Both are part of the final software verification stack; they are not run during the current implementation phase.
