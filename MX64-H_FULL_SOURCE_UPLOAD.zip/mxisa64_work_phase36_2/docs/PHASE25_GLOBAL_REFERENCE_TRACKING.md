# MX64-H Phase 25 — Global Physical Register Reference Tracking Primitive

## Delivered

Added `rtl/rename/physical_register_reference_tracker.sv`, a parameterized
reference-count bank for physical-register tags.

- Multiple acquire and release events can be presented in one cycle.
- Events are accumulated per physical tag; simultaneous acquire/release events
  net against each other.
- A live-reference bitmap is derived from nonzero counters.
- Underflow and overflow are guarded by simulation-time assertions.
- Out-of-range acquire/release tags are asserted.
- `clear_all` supports a coordinated reset/rebuild sequence.

## Integration status — important

This is a reusable RTL primitive, **not yet wired into the active MX64-H
dispatch/issue/ROB/branch paths**. The current core does not yet generate a
complete, authoritative set of acquire/release events for every consumer.
Connecting an incomplete event stream to the free list would be unsafe and
could leak physical registers or free live operands.

The next integration stage must account for at least:
1. speculative and committed RAT mappings;
2. all live branch checkpoint RAT snapshots;
3. source-tag references retained by integer and branch queues;
4. in-flight execution and completion pipeline tags;
5. ROB destination/old-destination metadata;
6. retirement, issue, squash, exception, and recovery event ordering.

Only after these event sources are connected and reconciled should the tracker
be permitted to block or authorize physical-register reclamation.

## Verification

Static source contracts and existing software suites are run for this phase.
No SystemVerilog compiler, elaboration, simulation, formal verification, or
synthesis is available in this environment; the new assertions remain
unexecuted.
