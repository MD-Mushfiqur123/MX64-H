# MX64-H Phase 31 — Memory Ordering and Store-to-Load Forwarding

## Scope

Phase 31 adds a standalone conservative memory-ordering primitive. It is deliberately separate from the existing LSU reference-lifecycle manager: the latter owns physical-register tags, while this unit owns store ordering metadata and byte-level forwarding decisions.

## Implemented

- Parameterized store queue with slot allocation, sequence number, byte address, byte mask, and store data.
- Address and data may be unresolved at allocation and supplied later through explicit resolve handshakes.
- A load query is blocked while any older store has an unresolved address. This is conservative: an older unknown address may alias any load.
- A load query is also blocked when an older matching store has unresolved data.
- Per-byte store-to-load forwarding selects the youngest older matching store for each requested load byte.
- `forward_mask` and `forward_data` describe bytes supplied by the store queue; `forward_complete` means every requested byte is forwarded.
- If forwarding is partial or absent but no older store is unresolved, `load_can_issue` permits the load to access the memory hierarchy for remaining bytes.
- Store retirement removes the entry; precise flush clears all entries.
- Invalid retire/resolve slot references and empty store masks have simulation assertions.

## Ordering contract

`store_alloc_seq` and `load_query_seq` must be monotonically increasing sequence numbers. The producer must prevent sequence-number wrap while any older entry remains live. The unit compares sequence numbers with unsigned `<` and `>`; it does not implement modular age comparison.

A store's `store_alloc_addr` is the byte address corresponding to byte lane zero of its data word. `store_alloc_mask[b]` enables byte `store_alloc_addr + b`, and `store_alloc_data[8*b +: 8]` supplies that byte. Load query address/mask use the same convention. The supported datapath is `DATA_W` bits, with `DATA_W` divisible by eight.

An unresolved older store address stalls every younger load query. Once the address resolves, only overlapping bytes with unavailable store data stall the load. For each overlapping byte with data available, the youngest older store wins. The memory subsystem must merge forwarded bytes with bytes returned by memory according to `forward_mask`.

## Boundaries

- This is a standalone ordering/forwarding primitive; it is not yet instantiated in `mx64_frontend_dispatch` or connected to an address-generation unit, load queue, cache, or memory bus.
- It does not implement speculative load violation detection after a load has issued, replay scheduling, fences, atomics, MMIO ordering, misalignment splitting, cache coherence, or memory consistency beyond conservative older-store ordering.
- It assumes store allocation is performed once per store and the producer retains the returned slot until retirement or flush.
- It does not itself own physical-register references. Phase 30's LSU lifecycle manager remains responsible for source-tag ownership.
- Static source checks and software tests do not establish SystemVerilog correctness. No HDL compiler, elaboration, simulation, formal verification, or synthesis was run.
