# MX64 architecture and verification references

This repository uses the following public technical references as design guidance. MX64 is an independent architecture; these sources are not claims of compatibility or endorsement.

## Out-of-order pipeline organization

1. **Berkeley Out-of-Order Machine (BOOM) documentation — Pipeline overview**  
   https://docs.boom-core.org/en/latest/sections/intro-overview/boom-pipeline.html  
   Used for the conceptual separation of rename, dispatch, issue, execute, writeback, memory, and in-order commit. BOOM describes dispatch into issue queues, readiness-based issue, and ROB-controlled commit.

2. **BOOM documentation — Rename stage**  
   https://docs.boom-core.org/en/latest/sections/rename-stage.html  
   Used as a reference for architectural-to-physical register mapping, free-list allocation, busy tracking, branch checkpoints, and stale physical destination reclamation.

3. **BOOM documentation — Issue units**  
   https://docs.boom-core.org/en/latest/sections/issue-units.html  
   Used as a reference for issue-queue scheduling, wakeup/select, age ordering, and functional-unit availability.

4. **BOOM documentation — ROB and dispatch**  
   https://github.com/riscv-boom/riscv-boom/blob/master/docs/sections/reorder-buffer.rst  
   Used as a reference for tracking in-flight instructions and preserving precise architectural state through in-order retirement.

## Academic correctness reference

5. **A Rigorous Correctness Proof of a Tomasulo Scheduler Supporting Precise Interrupts**  
   https://www-wjp.cs.uni-saarland.de/forschung/projekte/Computer_Architecture/papers/sci99.pdf  
   The paper discusses extending Tomasulo-style dynamic scheduling with a reorder buffer so that out-of-order execution can coexist with precise interrupts. It motivates explicit correctness properties around completion tags, ROB ordering, and architectural state visibility.

## Toolchain reference

6. **Icarus Verilog — Installation Guide**  
   https://steveicarus.github.io/iverilog/usage/installation.html  
   Used for simulator installation guidance. The Windows CMD helper in this repository accepts the actual extraction path rather than assuming one fixed OSS CAD Suite directory.

## How these references are applied

- **Established design principle:** execute ready operations out of order, but make architectural state visible in program order at retirement.
- **Established design principle:** register renaming removes false WAR/WAW dependencies while preserving true RAW dependencies.
- **MX64 design choice:** two-wide dispatch/retirement target, 32 architectural integer registers, 80 physical registers, 48-entry ROB, and a 16-entry integer issue queue.
- **Not yet proven:** MX64's current RTL correctly implements all of these principles. The RTL remains an evolving implementation draft and must pass simulation, assertions, formal checks, and synthesis review.

- UC Berkeley BOOM technical report EECS-2015-167: https://www2.eecs.berkeley.edu/Pubs/TechRpts/2015/EECS-2015-167.html
- UC Berkeley BOOM v2 technical report EECS-2017-157: https://www2.eecs.berkeley.edu/Pubs/TechRpts/2017/EECS-2017-157.html
- BOOM documentation: https://docs.boom-core.org/
- OpenHW CVA6 documentation: https://docs.openhwgroup.org/

## Research and specification refresh (checked 2026-11-25)

- RISC-V International official ratified specification library (Unprivileged/Privileged ISA v20260120; Server Platform v1.0 May 2026; IOMMU v20260222; E-Trace v2.1 October 2026): https://docs.riscv.org/reference/home/
- XiangShan Kunminghu V2R2 microarchitecture design documentation: https://docs.xiangshan.cc/projects/design/en/kunminghu-v3/
- Fu et al., “Predictor-Dependent Amplification of Branch Mispredictions in Out-of-Order Superscalar Processors: A RISC-V gem5 O3 Study,” Applied Sciences 16(16), 8112 (2026): https://doi.org/10.3390/app16168112
- OpenHW CVA6 documentation, including parameterized FPGA/ASIC scope and integration boundaries: https://docs.openhwfoundation.org/projects/cva6-user-manual/01_cva6_user/Introduction.html
- Tain, Patil and Al-Asaad, “Survey of Verification of RISC-V Processors,” Journal of Electronic Testing 41, 111–138 (2025): https://doi.org/10.1007/s10836-025-06169-3
- IEEE Std 1800-2023 SystemVerilog: https://standards.ieee.org/ieee/1800/7743/
- System V gABI program loading: https://gabi.xinuos.com/elf/08-pheader.html

The research update records what is directly applicable, what is only comparative, and which performance conclusions are workload/model-specific: `docs/research/MX64H_RESEARCH_UPDATE_2026-11.md`.

## Phase 11 research refresh (checked 2026-11-25)

- XiangShan Kunminghu V2R2A IssueQueue (dated 2026-10-13): https://docs.xiangshan.cc/projects/design/en/kunminghu-v2r2a/backend/Schedule_And_Issue/IssueQueue/
- XiangShan Kunminghu V2R2A Rename design: https://docs.xiangshan.cc/projects/design/en/kunminghu-v2r2a/backend/CtrlBlock/Rename/
- XiangShan Kunminghu V2R2A architecture overview: https://docs.xiangshan.cc/projects/design/en/kunminghu-v2r2a/overview/
- XiangShan Kunminghu V2 typical configurations: https://docs.xiangshan.cc/projects/user-guide/en/kunminghu-v2/typical-configuration/
- *χRVFormal: Formal verification of RISC-V processor Chisel designs* (Journal of Systems Architecture 175, June 2026): https://doi.org/10.1016/j.sysarc.2026.103761 (Chisel-focused research lead, not a directly reusable SystemVerilog verification result).
