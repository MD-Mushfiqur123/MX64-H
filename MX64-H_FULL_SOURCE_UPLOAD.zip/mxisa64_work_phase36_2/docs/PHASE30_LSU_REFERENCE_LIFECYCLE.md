# MX64-H Phase 30 — LSU Reference Lifecycle Integration

## Scope

Phase 30 adds a load/store queue reference-lifecycle manager and connects its events to the existing shared physical-register reference tracker through `mx64_frontend_dispatch`.

## Implemented

- `rtl/memory/lsu_reference_lifecycle.sv` maintains independent load and store queue slot tables (default depth 16 each).
- A load allocation retains its address-base physical tag.
- A store allocation retains its address-base and store-data physical tags.
- Each accepted allocation returns a queue slot to the LSU producer.
- Completion and replay-discard release the retained references exactly once.
- A precise trap flush releases every outstanding load/store reference.
- Invalid completion/replay slot references trigger simulation assertions.
- The frontend wrapper merges LSU acquire/release events with external consumer and branch lifecycle events before forwarding them to the shared reference tracker.
- Queue occupancy is exposed through `lsu_outstanding_count`.

## Interface contract

The LSU producer must assert `*_alloc_valid` only for a new accepted queue entry and must retain the returned slot identifier. It must send exactly one matching `*_done_valid` or `*_replay_valid` event for each allocated slot, unless `trap_valid` flushes the queue. A replay event means the old queue entry is discarded; a later retry must allocate a new slot and reacquire its source tags. Stores retain both base and store-data tags. Loads retain the base tag; load data destination ownership remains represented by the ROB destination reference, not this queue.

## Boundaries and limitations

- This is LSU reference-lifetime infrastructure, not a complete LSU datapath.
- Address generation, translation, TLB, cache access, forwarding, ordering, atomic operations, misalignment handling, and memory exception generation are not implemented by this module.
- Store data is retained as a physical tag; the module does not capture the actual store-data value.
- The producer must obey the slot handshake and one-terminal-event contract. There is no automatic transaction-ID association with an external memory bus yet.
- External FP/SIMD consumer lifecycle remains an explicit boundary.
- Static source checks and software tests do not establish SystemVerilog correctness. No HDL compiler, elaboration, simulation, formal verification, or synthesis was run.

## Verification

Run `python scripts/check_repo.py`, `python scripts/check_rtl_sources.py`, ABI/ISA checks, and the software test suites. The source checker is lexical/static, not a SystemVerilog parser.
