# MX64-H Phase 23 — Recovery-Safe Completion Stage

## Delivered

The integer execution cluster has a one-cycle registered completion stage.
Previously, a branch recovery could arrive while a younger result was already
resident in that stage. The issue queue removed younger queued uops, but the
registered result could still be broadcast to the ROB and physical register
file during the recovery cycle.

Phase 23 closes that stale-result path:

- Capture each issued uop's global dispatch sequence number alongside its
  registered completion metadata.
- During selective recovery, compare each pending completion sequence against
  the recovery sequence using the same signed modular ordering convention as
  the issue queue.
- Suppress younger completion-valid and destination-writeback signals
  combinationally in the recovery cycle. Both the ROB completion path and PRF
  write path therefore see the filtered valid signals.
- Consume surviving older completions in that cycle, then clear the completion
  stage at the recovery edge so an older completion is not replayed next cycle.
- The branch link result remains a separate external writeback/wakeup source;
  it is not classified as a younger integer completion by this filter.

## Ordering assumption

The 32-bit sequence comparison is unambiguous while fewer than 2^31 sequence
numbers separate live entries, matching the issue queue's existing age-order
assumption. Dispatch must remain blocked during recovery, as already required
by the issue queue recovery contract.

## Verification status

Repository, RTL source-contract, ABI, ISA audit and software tests are static
checks only. No SystemVerilog compiler, elaboration, simulation, formal proof,
or synthesis was run. The new RTL must be HDL-compiled and directed-tested
before it is treated as verified hardware behavior.

## Remaining work

This closes the pending integer completion replay/stale-writeback path for the
current one-cycle ALU pipeline. It does not yet implement multi-cycle execution
reservation, memory/FP completion arbitration, physical-tag generation tags,
or a complete top-level CPU.
