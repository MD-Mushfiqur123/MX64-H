# MX64-H Phase 35 — LSU/L1D Cache Subsystem Integration

## Scope

Phase 35 adds `rtl/memory/mx64_lsu_cache_subsystem.sv`. It composes the Phase
32 LSU request/ordering/reference slice with the Phase 34 LSU-to-L1D bridge.
The wrapper provides a single outstanding cache transaction and explicit
in-order store-commit ingress.

## Request flow

- A load is admitted only while the cache bridge can accept a request and no
  committing store has priority. The LSU pipeline's load ordering checks still
  gate acceptance. An accepted load issues one L1D read in the same cycle.
- A store is allocated into the LSU's store-order and reference-lifecycle
  structures speculatively. It does not issue a cache write at allocation.
- A committed store is supplied through `store_commit_*`. It has priority over
  a new load and is accepted only when the cache bridge is ready. The matching
  store-order slot is retired on that accepted commit handshake.
- The response carries the transaction class and lifecycle slot captured at
  request acceptance. Response backpressure is passed to the bridge.
- The LSU's byte forwarding mask/data remain visible to the downstream load
  result path so it can merge forwarded bytes with cache-returned bytes.

## Explicit integration boundaries

This is a single-outstanding blocking-cache integration slice, not a complete
retirement-connected LSU. The surrounding core must supply translated physical
addresses and committed-store payload/slot metadata. It must consume response
identity and drive `load_done_*`, `store_done_*`, replay and flush lifecycle
signals. The downstream load-result path must merge `load_forward_mask/data`
with cache data; full-forward bypass is not yet implemented in this wrapper.

There is no DTLB/page walker, permission check, multiple outstanding misses,
non-blocking MSHRs, atomic path, MMIO ordering policy, cache coherence, L1I/L2,
or complete memory consistency implementation. Flush does not cancel an
already accepted cache transaction; the integration owner must drain or mark
its response killed before returning it to the architectural pipeline.

## Verification status

The source-contract checker and software/ISA/ABI suites are static/software
checks only. The new testbench is a scenario scaffold and has not been run.
No SystemVerilog compilation, elaboration, simulation, formal verification,
synthesis, timing analysis, or FPGA test is claimed.
