# Windows CMD: MX64 simulator setup

This guide is designed for ordinary Windows Command Prompt (`cmd.exe`), not PowerShell.

## 1. Install a simulator toolchain

Recommended: download the Windows x64 OSS CAD Suite ZIP from the official releases:

https://github.com/YosysHQ/oss-cad-suite-build/releases

Extract the ZIP. The extraction folder can have **any name and any location**. The important file is:

`<your-extraction-folder>\\environment.bat`

For example, if you extracted to:

`C:\\Users\\mushfiqur\\Downloads\\oss-cad-suite-win64`

then the file should be:

`C:\\Users\\mushfiqur\\Downloads\\oss-cad-suite-win64\\environment.bat`

Do not assume it is located at `C:\\tools\\oss-cad-suite`; that was only an example path.

The official Icarus Verilog installation guide also notes that pre-packaged binaries are generally the easiest installation route on platforms where they are available:
https://steveicarus.github.io/iverilog/usage/installation.html

## 2. Extract the MX64 project

Extract the project ZIP. Open CMD in the project root, the folder containing `README.md`, `rtl`, `scripts`, and `verification`.

Example:

```cmd
cd /d "C:\\Users\\mushfiqur\\Downloads\\mxisa64_mxagent_repository_m2_3_windows_test_ready\\mxisa64_repository"
```

Your folder name may differ if you renamed the ZIP or extraction folder.

## 3. Run the guided setup

Run:

```cmd
scripts\\setup_and_run_windows.bat
```

The script:
- uses Icarus Verilog if `iverilog` and `vvp` are already on PATH;
- checks common OSS CAD Suite extraction locations;
- if it cannot find the suite, asks you to enter the exact folder containing `environment.bat`;
- compiles and runs the directed integer ALU testbench.

You may also set the suite path manually before running the script:

```cmd
set OSS_CAD_SUITE=C:\\Users\\mushfiqur\\Downloads\\oss-cad-suite-win64
scripts\\setup_and_run_windows.bat
```

## 4. Expected successful output

The testbench should print:

```text
PASS: integer_alu directed tests
```

The batch script then prints:

```text
PASS: MX64 ALU smoke test completed.
```

## Verification boundary

This test compiles and simulates **only**:
- `rtl/common/mx64_pkg.sv`
- `rtl/execution/integer_alu.sv`
- `verification/unit/tb_integer_alu.sv`

It does **not** compile or verify the full processor, rename logic, issue queue, ROB, atomic dispatch, LSU, MMU, caches, or physical-design flow. Those remain separate verification milestones. A passing ALU test must not be described as full-CPU verification.
