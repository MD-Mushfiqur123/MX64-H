# MX64-H Phase 34 — LSU to L1D Cache Bridge

## Scope

Phase 34 adds `mx64_lsu_cache_bridge`, a physical-address request/response
adapter between an upstream LSU and the Phase 33 blocking L1D controller. It
instantiates `cache_hierarchy`, forwards the cache-line memory interface, and
formats the returned aligned 64-bit word into byte/halfword/word/doubleword
load results with signed or unsigned extension.

## Request contract

- The upstream LSU presents a translated physical address.
- The upstream LSU must already have completed AGU checks, memory-ordering
  checks, store-to-load forwarding decisions, and replay decisions.
- `req_byte_enable` is low-contiguous and relative to the naturally aligned
  access; `req_wdata` is right-justified.
- Requests are accepted on `req_valid && req_ready`.
- Request address offset, size, signedness and operation are latched at
  acceptance. The upstream may change its request fields after the handshake.

## Response contract

- Cache response valid/ready is passed through without an extra buffering stage.
- Load data is shifted by the latched byte offset, then sign- or zero-extended
  according to the latched access size.
- Store response data is zero; cache errors propagate unchanged.
- Response payload remains stable while `rsp_valid && !rsp_ready` because the
  cache holds its response and the bridge uses latched request metadata.

## Memory interface

The bridge forwards the Phase 33 full-line memory interface. The backing memory
must return exactly one response for every accepted line request. The bridge
uses the cache controller's default 64-bit data path and 64-byte line geometry.

## Important limitations

- This is an LSU-to-cache adapter, not yet an end-to-end instantiation of
  `mx64_lsu_pipeline` with `cache_hierarchy`.
- The Phase 32 LSU currently lacks a complete cache request/response contract
  and a committed-store payload export. Store retirement-to-cache sequencing
  therefore remains an integration task.
- Physical address translation, TLB/page faults, load replay scheduling,
  store commit arbitration, fences, atomics, MMIO ordering, cache maintenance
  and coherent multi-core behavior are not implemented here.
- The L1D remains blocking, direct-mapped, and flop-array based.
- `tb_lsu_cache_bridge.sv` is a test scaffold only and has not been executed.

## Verification status

Repository/software checks and static RTL source-contract checks can validate
file presence and authored interface contracts only. No SystemVerilog compiler,
elaborator, simulator, formal engine or synthesis tool is available in the
current environment; no HDL verification claim is made.
