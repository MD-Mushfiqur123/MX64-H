# Phase 37.3 — LSU Selective Recovery Contract

## Scope

Phase 37.3 adds a sequence-based selective recovery path from the LSU/ROB adapter into the LSU pipeline, memory-ordering queue, and physical-reference lifecycle. It is intended for branch-mispredict recovery, where `recover_seq` is the sequence number of the resolving branch and only operations strictly younger than that branch are squashed.

## Recovery semantics

- `flush_all` remains the precise-trap/reset-style destructive flush.
- `recover_valid && entry_seq > recover_seq` removes speculative store-order entries and releases their retained base/data physical-register references.
- Entries at or older than `recover_seq` remain live.
- Loads are deliberately not removed from the lifecycle manager by branch recovery. The cache interface is single-outstanding and has no cancellation handshake. The adapter marks younger in-flight loads killed, retains their slot/ROB identity until the cache response is consumed, and suppresses both ROB completion and PRF writeback.
- A response arriving in the same cycle as recovery is still consumed; its load/store metadata and counters are retired normally.
- A committed store is irrevocable. The adapter retains committed-store metadata across global flush and branch recovery. In-order retirement implies a store younger than an unresolved branch cannot already have been committed.
- Store-order queue and lifecycle queue pruning use the same `SEQ_W` sequence comparison.

## Ordering assumptions

Sequence numbers are monotonically increasing and must not wrap while any relevant LSU entry remains live. Recovery is strictly younger-than (`>`), not younger-or-equal. The branch itself remains architecturally valid.

## Integration

`mx64_lsu_rob_adapter` now accepts `recover_valid` and `recover_seq`; the signal is forwarded through `mx64_lsu_cache_subsystem` and `mx64_lsu_pipeline` to `memory_ordering_unit` and `lsu_reference_lifecycle`. Existing standalone frontend lifecycle instantiation ties recovery off because that older reference-only path does not own the new branch-recovery interface.

## Explicit limitations

- No HDL compiler, simulator, formal tool, or synthesis tool was available in this environment. The change has static source-contract validation only.
- The functional CPU top is still not integrated; the adapter's new recovery pins must be driven by the real branch recovery controller when the top is built.
- The single-outstanding cache contract remains. There is no cache cancellation, TLB/page-walker, permission check, or page-fault path.
- The adapter uses draft MXISA-64 load/store opcode size and signedness mappings; these must be frozen in the ISA specification.
- The existing store-error path remains a post-retirement error, not a precise ROB exception.
