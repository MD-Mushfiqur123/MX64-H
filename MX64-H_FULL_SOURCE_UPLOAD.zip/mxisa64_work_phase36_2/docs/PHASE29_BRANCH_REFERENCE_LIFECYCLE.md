# MX64-H Phase 29 — Branch Execution Reference Lifecycle

## Delivered

Added `rtl/execution/branch_reference_lifecycle.sv` and connected it in `mx64_frontend_dispatch`. The lifecycle table tracks accepted branch and jump uops by ROB tag and dispatch sequence. It acquires both source physical tags only on the branch-unit valid/ready handshake.

- A matching branch resolution releases both retained source tags.
- A misprediction releases the resolving branch and every younger retained branch/jump operand, using the dispatch sequence ordering already carried in `issue_uop_t`.
- A precise trap flush releases all outstanding branch/jump source references.
- Event buses are widened internally by `2*ROB_DEPTH` release lanes so recovery can release every retained branch entry in one cycle; the user-facing external event interface remains unchanged.
- Branch events are merged with the existing external, IQ, ROB, and rename-map events before reaching the shared reference tracker.

## Important boundaries

This integrates the lifecycle of the branch execution boundary, not the branch execution datapath itself. The branch unit remains external and must obey the existing valid/ready and resolution-tag contract. Both source tags are conservatively retained for each accepted branch/jump until resolution, even if a particular operation does not consume both operands. The external LSU and FP/SIMD domains remain responsible for driving their own event lanes.

The table has `ROB_DEPTH` entries and relies on at most one outstanding record per allocated control-transfer ROB entry. A resolve event must correspond to a retained branch/jump entry. The assertion catches unmatched resolutions. Sequence comparison uses signed modular 32-bit ordering, consistent with existing recovery sequence handling; wraparound corner cases still require formal verification.

## Verification status

Static repository and RTL source-contract checks plus software-only tests are run. No HDL compiler is available in this environment, and no HDL simulation, formal proof, or synthesis was run. Simulation remains deferred until the final verification stage as requested.
