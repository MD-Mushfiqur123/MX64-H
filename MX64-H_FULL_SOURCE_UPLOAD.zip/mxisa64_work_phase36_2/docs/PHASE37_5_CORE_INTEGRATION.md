# Phase 37.5 — Core Integration Boundary

## Scope

Phase 37.5 replaces the empty `mx64_top` shell with a real integration wrapper that instantiates:

- `mx64_frontend_dispatch` (fetch/decode, rename, PRF, dispatch, ROB, integer issue/execution, branch tracking and recovery control);
- `mx64_lsu_rob_adapter` (memory issue dequeue, LSU/cache request/response, load ROB completion/PRF writeback, store retirement gate);
- the Phase 35 LSU/cache subsystem below the adapter.

The top exports explicit instruction-memory and data-memory ready/valid interfaces, an explicit branch execution-unit interface, platform privilege/trap-vector inputs, retirement events, and debug counters.

## Important integration details

1. Memory UOPs leave the dedicated memory issue queue and enter `mx64_lsu_rob_adapter`.
2. Adapter load/store allocation and completion events are mirrored into the frontend's LSU physical-register lifecycle tracker. This keeps source physical tags live until the LSU releases them.
3. The adapter's `retire_store_ready` feeds the control subsystem retirement gate. A store cannot retire until its matching ROB tag has been accepted by the LSU store-commit path.
4. Branch misprediction plus accepted branch resolution forwards the recovery sequence to the adapter; the frontend's rename/ROB/issue recovery remains the source of the recovery boundary.
5. Trap flush and branch selective recovery remain distinct controls.
6. Load response completion returns to the ROB, and successful load results use the separate PRF writeback port. Faulting loads do not write the PRF.

## Explicitly unsupported / not complete

- No MMU, TLB, page walker, privilege checks, or virtual-to-physical translation. Phase 37.5 uses an explicitly documented identity mapping and asserts that the address fits `PADDR_W`.
- Branch execution is an external unit interface. This top does not yet instantiate a branch ALU/condition evaluator.
- CSR file, interrupts, debug, L1I, L2, coherence, atomics, fences, MMIO policy, SoC bus protocol adaptation, and FP/SIMD are not integrated.
- Existing RTL has not been parsed, elaborated, simulated, formally verified, synthesized, or timed in this environment because no HDL tools are installed. Static checks are not substitutes for those steps.
- This is the first core integration slice, not a claim of a bootable or verified processor.

## Required next work

1. Install/use an approved SystemVerilog toolchain in the user's environment and fix all compile/elaboration issues.
2. Add an executable testbench for reset/fetch, integer dependency + wakeup, branch mispredict recovery, load completion, store retirement gating, precise load fault, and trap flush.
3. Integrate an actual address translation and platform/CSR boundary before claiming general software execution.
4. Close the remaining audit defects (issue-queue wakeup collision, reference-tracker `clear_all`, cache victim-writeback error attribution, committed-store error policy, invalidate-during-busy contract).
