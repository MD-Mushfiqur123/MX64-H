# MX64-H Phase 27 — Reference-Aware Physical Register Reclamation

## Delivered

- The global reference tracker now emits a one-cycle `reclaim_bitmap` pulse when a nonzero physical-register reference count will become zero after all same-cycle acquire and release events are netted. p0 is never marked reclaimable.
- The integer backend exports this bitmap to the rename/dispatch layer.
- The free list no longer returns a displaced mapping directly to the allocator at commit. It waits for the tracker’s final-reference pulse. Reclamation is applied after the current cycle’s allocation scan, so a tag released on an edge cannot be reallocated on that same edge.
- Branch checkpoint snapshots merge delayed reclaim pulses, preventing an older live checkpoint from restoring a tag that has already become free. A reclaim pulse coincident with a recovery/flush is also ORed into the restored free bitmap, so the one-cycle pulse is not lost.
- Existing reference-count and live-bitmap debug outputs remain available; the reclaim bitmap is also exposed through the integration wrappers.

## Important correctness boundary

This is reference-aware reclamation for the domains currently represented in the Phase 26 tracker: integer issue-queue unresolved operands, ROB destination metadata, and speculative/committed rename-map ownership. The branch execution unit remains an external boundary, and LSU/load-store queues, FP/SIMD, and other future consumers do not yet report reference events. Therefore this phase does **not** claim complete core-wide physical-register lifetime safety. Before enabling a complete OoO core, every consumer that can retain a physical tag must acquire/release through the tracker (or an equivalent lifetime protocol), and recovery/flush semantics must be verified.

## Verification status

Static source checks and software tests are run for this phase. No SystemVerilog compile, elaboration, simulation, formal proof, or synthesis is claimed; HDL toolchains are unavailable in the current environment, and simulation remains deferred until the user’s requested final verification stage.
