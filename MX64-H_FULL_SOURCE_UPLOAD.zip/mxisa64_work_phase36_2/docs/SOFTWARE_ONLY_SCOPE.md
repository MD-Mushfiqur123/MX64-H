# MX64 Software-Only Scope and Delivery Contract

The user will not be expected to perform manual design work. The project is to be advanced as far as software tools and source artifacts allow. Physical silicon fabrication, proprietary PDK access, board wiring, and real silicon characterization are outside the software-only scope.

## What can be completed in software
- ISA and privileged architecture specification.
- Microarchitecture and interface contracts.
- SystemVerilog RTL for core, frontend, rename, backend, execution, LSU, caches, MMU, CSR, debug and platform.
- Assembler, disassembler, linker scripts, ELF/image tooling and reference emulator.
- Self-checking testbench source, constrained-random generators, assertions and formal properties.
- Build automation, lint, simulation, formal, synthesis and PPA scripts.
- FPGA project files and constraints for a selected board (actual board bring-up needs hardware).
- OpenROAD floorplan/place/CTS/route flow setup (actual results depend on a real technology platform/PDK).
- Reproducible reports and CI configuration.

## What cannot honestly be completed without external hardware or proprietary inputs
- Fabricated chip, measured frequency/IPC/power/thermal behavior.
- Foundry signoff without a licensed PDK, SRAM/standard-cell libraries and signoff decks.
- FPGA board validation without the actual board.
- Claims of AMD Ryzen equivalence without comparable benchmark workloads, toolchain, power and measured hardware.

## Execution policy
The user asked to defer simulation until the end. Therefore, during architecture and implementation phases:
1. author and review specifications;
2. author RTL and software tooling;
3. perform source-level consistency checks and structural packaging checks;
4. do not execute HDL simulation, formal engines, synthesis, or PPA yet;
5. preserve a final verification checklist and run it only after source integration review is complete.

Static file/JSON/schema checks are not HDL simulation. Any check performed must be labelled accurately.

## Completion definition
“Software-complete MX64 project” means the source tree, ISA toolchain, reference model, RTL, verification collateral, build scripts, platform descriptions, and implementation-flow scripts are present and documented. It does not mean verified silicon or performance parity.
