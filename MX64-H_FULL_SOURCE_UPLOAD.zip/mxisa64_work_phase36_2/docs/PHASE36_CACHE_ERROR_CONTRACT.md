# MX64-H Phase 36 — Cache and Committed-Store Error Contract

**Status:** architectural/interface decision for implementation and verification; not simulation evidence.

## 1. Cache miss with dirty-victim writeback failure

A demand request that requires eviction of a dirty victim cannot complete if the victim writeback fails. The cache therefore returns `rsp_error=1` for the outstanding demand request and does not issue the refill. This is a *request-failure indication caused by a prerequisite writeback failure*, not a claim that the requested line itself was written to memory.

Required behavior:
- Keep the dirty victim valid and dirty after failed writeback; do not overwrite it with refill data.
- Do not issue `S_REFILL_REQ` after a failed `S_WB_WAIT` response.
- Hold the error response stable until `rsp_ready`.
- Upstream must treat the operation as failed and must not assume the requested load data or store update reached the cache.
- A future interface revision should add an error-cause field if software needs to distinguish victim writeback failure from refill failure.

The current cache has only a single boolean `rsp_error`, so it cannot report a distinct writeback-error class. This contract makes the current conservative behavior explicit rather than silently describing the source of the error incorrectly.

## 2. Committed-store lifecycle ownership

`store_commit_ready` means the cache accepted responsibility for the committed store request. It does **not** mean the store has completed successfully in backing memory. The subsystem latches `cache_rsp_is_store` and `cache_rsp_lifecycle_slot` at request acceptance and returns that identity with the eventual cache response.

Required upstream contract:
- The lifecycle slot and its generation/identity must remain reserved until the matching `cache_rsp_valid && cache_rsp_ready` handshake.
- A store-order queue entry may retire at cache acceptance, but its lifecycle identity must not be recycled at that point.
- If `cache_rsp_error` is asserted for a store, the independent `store_error_valid/store_error_ready` channel reports the failure and carries `store_error_lifecycle_slot`. The platform error sink must acknowledge it before the cache response can be consumed.
- The subsystem gates the cache response handshake on BOTH `cache_rsp_ready` and (for a committed-store error) `store_error_ready`. This prevents silent error loss and prevents the associated lifecycle identity from being released before error acknowledgement.
- It must not attempt to replay the already committed store as an ordinary speculative instruction.
- The current interface does not include a generation field. Therefore slot reuse before response consumption/error acknowledgement is forbidden; a future buffered/multi-outstanding design must add a generation or transaction ID.
- Flush/recovery must not discard an accepted committed-store response identity.

## 3. Verification obligations

1. Dirty victim writeback error: response error asserted; no refill request; victim line remains valid+dirty; response stable under backpressure.
2. Refill error: response error asserted; no valid line installed.
3. Store accepted: response class and lifecycle slot remain stable until response handshake.
4. Store error: error response carries the original store lifecycle identity; upstream error sink acknowledges it before that identity can be reused.
5. Invalidate pulse while busy: pulse is retained; new requests remain blocked until invalidation is serviced after response drain.

## 4. Known limitations

This phase adds a store-error handshake at the LSU/cache subsystem boundary, but does not yet connect it to a platform-level fatal machine-check controller because `mx64_top` is still a non-functional shell. Error-cause encoding and transaction generation remain future interface work.
