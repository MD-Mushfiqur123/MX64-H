# MX64-H Phase 20 — Frontend-to-Control Integration

## Delivered

Added `rtl/core/mx64_frontend_dispatch.sv`. It structurally connects:

`instruction memory -> fetch -> branch predictor -> decoder -> dispatch/rename -> ROB and issue queues`

It also connects the branch execution handshake, resolved branch training inputs,
and trap/branch redirect selection. Trap redirects have priority. A branch
redirect is accepted only when the dispatch controller confirms the branch
resolution handshake.

## Width contract

The existing frontend emits one decoded instruction per cycle. The current
control subsystem is two-wide, so this wrapper drives lane 0 and holds lane 1
inactive. It does not claim dual-wide fetch/decode.

## Explicit external boundaries

- Instruction memory request/response bus.
- Operand readiness and values from a future physical-register-file /
  dependency-readiness subsystem.
- Branch execution unit, including resolved branch PC, actual direction,
  actual next PC, and link result.
- Privilege state and trap vector from the future CSR subsystem.

The physical register file is not yet instantiated in this wrapper. The
current backend's execution writeback buses are internal to its module and
must be exported before a fully closed PRF read/write/wakeup path can be
connected. Therefore operand values are explicit inputs rather than guessed
from architectural register numbers.

## Known integration limits

- `mx64_top` remains a shell; this wrapper is a reusable integration slice.
- No LSU, MMU/TLB, caches, CSR state-update path, or SoC bus is integrated.
- Branch execution remains external.
- Frontend is single-wide and has one outstanding instruction fetch request.
- The decoder/backend operation coverage is not yet complete for every opcode.
- Fetch protocol has no transaction ID/cancel interface; redirects drain and
  discard an outstanding response.

## Verification status

Static source checks and the software ISA/toolchain suite are run. No HDL
compile, elaboration, simulation, formal proof, or synthesis was run. Those
remain deferred per project instruction.
