# MX64-H Phase 36 — Stabilization & Verification Readiness

**Baseline:** Phase 35 LSU/L1D subsystem snapshot  
**Workspace:** `mxisa64_work_phase35/`  
**Scope:** targeted stabilization, source-level regression guards, and verification readiness.  
**Non-goal:** claiming a functional CPU, HDL compile, simulation, formal proof, or synthesis.

## Phase-36 change set

1. **Issue Queue same-cycle enqueue/wakeup capture**
   - Introduces `effective_enq_uop` and applies current wakeup broadcasts to accepted enqueues.
   - Stores the effective uop and acquires references only for operands still unresolved after wakeup bypass.
   - Intended to prevent a completion coincident with enqueue from being discarded and leaking a source reference.
   - Needs a directed HDL test with one and two wakeup ports, both source operands, duplicate tags, and simultaneous two-lane enqueue.

2. **Physical-register tracker `clear_all` semantics**
   - Restores one ownership reference for each architectural identity-mapped register `[0, INIT_ARCH_REGS)` on `clear_all`.
   - Suppresses `reclaim_bitmap` during `clear_all` to avoid a spurious reclaim pulse based on pre-clear counts.
   - Contract: caller may assert `clear_all` only while RAT is reset to the architectural identity map. This assumption still needs an integration assertion/test.

3. **L1D pending invalidation**
   - Latches `invalidate_all` pulses received while the controller is busy.
   - Blocks new requests while invalidation is pending and services invalidation when the controller returns to idle.
   - Existing policy still discards dirty lines; platform/software must clean dirty lines before invalidation. This is not a writeback/flush operation.

4. **Cache/store error contract**
   - Defines dirty-victim writeback failure as failure of the blocked demand request; the dirty victim must remain valid+dirty and no refill may follow.
   - Defines `store_commit_ready` as cache acceptance, not successful backing-memory completion. The lifecycle identity must remain reserved until the matching cache response is consumed; store errors route to a platform fatal/asynchronous-store-error sink.
   - Current RTL interface has no error-cause code, generation ID, or fatal-error sink; those remain top-level/platform integration work.

5. **Directed HDL testbench additions**
   - Adds stimulus/assertion testbenches for same-cycle issue-queue wakeup, reference-tracker clear/reclaim behavior, and dirty-victim writeback failure.
   - These testbenches are not compiled or simulated in this environment. See `verification/PHASE36_DIRECTED_TESTS.md`.

6. **Static checker maintenance**
   - Updates the Phase-35 RTL contract checker to accept the pending-invalidation implementation rather than requiring the old idle-only condition.
   - Adds `scripts/check_phase36_stabilization.py` as a small static regression guard.

## Re-audit of Phase-35 findings

| Finding | Phase-36 status | Evidence / remaining work |
|---|---|---|
| MX64H-001 empty `mx64_top` | OPEN / BLOCKER | Top remains a shell; define ports and integrate subsystems before claiming a CPU. |
| MX64H-002 same-cycle IQ wakeup | PATCH PRESENT; HDL UNVERIFIED | Enqueue bypass path now present. Directed simulation required. |
| MX64H-003 `mx64_rob_placeholder` | OPEN / LOW | Retained as explicitly named compatibility placeholder; remove only after confirming no external source-list dependency. |
| MX64H-004 writeback error attribution | CONTRACT DEFINED; HDL UNVERIFIED | Dirty-victim writeback failure is specified as failure of the blocked demand operation; no refill follows and the victim remains dirty. RTL behavior still needs directed simulation. |
| MX64H-005 tracker `clear_all` | PATCH PRESENT; HDL UNVERIFIED | Architectural references restored and reclaim suppressed during clear. Test reset/clear/acquire/release interactions. |
| MX64H-006 committed-store error lifecycle | OPEN / MEDIUM | Store ordering slot retires on cache request acceptance, before later cache/memory response. Define architectural error policy and response ownership. |
| MX64H-007 invalidate while busy | PATCH PRESENT; HDL UNVERIFIED | Pending pulse latch and request backpressure added. Dirty-line discard policy remains explicit. |
| MX64H-008 generated files in manifest | OPEN / LOW | Existing Phase-35 manifest is immutable baseline; create a clean Phase-36 manifest excluding generated caches/build outputs. |

## Verification status

- Python repository and RTL source-contract checks: run separately and record exit status.
- Phase-36 static regression guards: run separately and record exit status.
- HDL tools: availability must be checked on the target host. If unavailable, HDL stages remain **NOT AVAILABLE**, never PASS.
- First-pass directed testbenches now exist for same-cycle IQ wakeup, reference-tracker clear/reclaim, and cache dirty-victim writeback error. They still require simulator compilation/execution and broader corner-case coverage; `tb_lsu_cache_subsystem` still needs an end-to-end committed-store lifecycle test.

## Exit criteria for Phase 36

- All source-level checks pass on the Phase-36 tree.
- The Phase-36 manifest verifies completely and contains no generated build/cache artifacts.
- Directed HDL tests compile and pass for the three new scenarios, plus an end-to-end committed-store lifecycle test.
- A supported simulator successfully parses/elaborates the intended RTL file list before any simulation result is claimed.
- `mx64_top` remains a separate blocker; Phase 36 does not declare a complete CPU.
