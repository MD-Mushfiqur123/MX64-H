# MX64-H System Requirements Specification

**Document ID:** MX64H-SRS-001  
**Revision:** 0.1 proposal  
**Status:** Baseline requirements draft; not a claim of implementation completion  
**Applies to:** MX64-H single-core, 64-bit, out-of-order processor

## 1. Purpose and verification language

This document defines externally observable requirements and implementation targets for MX64-H. “Shall” denotes a required architectural property. “Target” denotes a microarchitectural objective that must be evaluated by performance and physical-design evidence. “TBD” denotes a decision that cannot safely be frozen without a documented architecture decision.

The architecture is a new ISA and microarchitecture. It is not binary-compatible with AMD64/x86-64, AArch64, or RISC-V. AMD public material is used only as a public design reference for high-level width/cache organization, not as a source of proprietary implementation details.

## 2. Product definition and boundaries

- Initial product: one coherent 64-bit application-class CPU core with a platform interface.
- Initial implementation: single hardware thread; SMT and coherent multicore are explicitly out of scope for the first silicon target.
- Execution model: speculative out-of-order execution with in-order retirement and precise architectural state.
- Software deliverables: ISA specification, assembler/disassembler, linker/image format definition, reference interpreter, test generator, ABI, compiler-backend plan, debugger protocol plan, and reproducible build scripts.
- Hardware deliverables: synthesizable RTL, integration wrappers, assertions, directed/random testbenches, formal properties, synthesis constraints, and physical-design collateral.
- No performance, power, frequency, area, or silicon-yield claim is valid until measured on a declared implementation and process.

## 3. Functional requirements

| ID | Requirement | Class | Acceptance evidence |
|---|---|---|---|
| SYS-F-001 | Core shall implement 64-bit integer architectural state and 64-bit PC. | Mandatory | ISA tests + architectural model |
| SYS-F-002 | Integer register x0 shall always read as zero; writes shall have no effect. | Mandatory | Directed test + assertion |
| SYS-F-003 | Core shall support precise in-order retirement of speculative instructions. | Mandatory | ROB properties + exception tests |
| SYS-F-004 | A mispredicted branch shall restore the correct speculative state and redirect fetch. | Mandatory | Recovery tests + formal invariants |
| SYS-F-005 | A faulting instruction shall not expose partial architectural side effects. | Mandatory | Trap/retirement tests |
| SYS-F-006 | Loads and stores shall obey the defined single-core memory ordering contract. | Mandatory | LSU ordering tests |
| SYS-F-007 | Stores shall not become globally visible before retirement authorization. | Mandatory | LSU/ROB assertions |
| SYS-F-008 | Instruction fetch shall support fixed-width 32-bit base instructions. | Mandatory | Fetch/decode tests |
| SYS-F-009 | Illegal and reserved encodings shall produce a precise illegal-instruction trap. | Mandatory | Decode negative tests |
| SYS-F-010 | CSR and privileged state shall have architecturally specified reset, access, and trap behavior before release. | Mandatory | Privileged ISA tests |
| SYS-F-011 | Virtual-memory translation shall be disabled or precisely specified at reset; enabled mode shall define page-table format and fault behavior. | Mandatory | MMU tests |
| SYS-F-012 | Debug halt/breakpoint behavior shall preserve a recoverable architectural state. | Mandatory | Debug tests |
| SYS-F-013 | Performance counters shall be readable under defined privilege rules. | Mandatory | CSR tests |
| SYS-F-014 | Endianness shall be little-endian for the initial ABI. | Mandatory | Memory tests |
| SYS-F-015 | Unaligned accesses shall trap in the base profile unless a later extension explicitly enables them. | Mandatory | LSU exception tests |

## 4. Microarchitectural performance targets

These are initial design targets, not guaranteed throughput or measured performance.

| ID | Target | Initial value | Notes |
|---|---|---:|---|
| SYS-P-001 | Decode width | 4 instructions/cycle | Base decoder target |
| SYS-P-002 | Op-cache delivery | 8 uops/cycle | Target; requires separate validation |
| SYS-P-003 | Dispatch width | 6 uops/cycle | Target |
| SYS-P-004 | Retirement width | 6 uops/cycle | Target |
| SYS-P-005 | ROB capacity | 256 entries | Configurable proposal |
| SYS-P-006 | Integer physical registers | 192 | Configurable proposal |
| SYS-P-007 | FP physical registers | 192 | Configurable proposal |
| SYS-P-008 | Integer issue entries | 64 | Aggregate target |
| SYS-P-009 | Branch issue entries | 24 | Target |
| SYS-P-010 | Load queue entries | 48 | Target |
| SYS-P-011 | Store queue entries | 32 | Target |
| SYS-P-012 | L1I / L1D | 32 KiB each, 8-way | Proposed geometry |
| SYS-P-013 | L2 | 1 MiB, 8-way | Proposed geometry |
| SYS-P-014 | Cache line | 64 bytes | Proposed |
| SYS-P-015 | LSU interface throughput | up to 3 loads + 2 stores/cycle | Not a guarantee of sustained DRAM bandwidth |

A design review must explain every deviation from these targets. Physical feasibility, timing closure, SRAM availability, and power must take precedence over copying any public reference diagram.

## 5. Quality, safety, and implementation requirements

- RTL shall use explicit widths, signedness, reset semantics, and valid/ready contracts.
- All multi-entry queues shall define full/empty, simultaneous enqueue/dequeue, flush, and wrap behavior.
- All speculative identifiers shall be protected against stale completion/aliasing; generation or epoch handling is required where wraparound can occur.
- Reset and flush behavior shall be specified for every stateful block.
- Clock-domain crossings shall be explicit; initial core assumes a single synchronous core clock.
- Memory interfaces shall define request stability, response association, ordering, cancellation, and error reporting.
- ECC/parity, scan/DFT, and debug hooks shall be architected before implementation freeze even if physical insertion is later.
- Synthesis and physical design shall be reproducible from versioned scripts and constraints.
- All verification claims shall name the tool, version, configuration, test scope, and result.

## 6. Acceptance gates

**Gate H0 — Requirements baseline**
- Requirements, scope, glossary, traceability, and open decisions reviewed.
- No unresolved contradiction between architecture overview, config, and ISA draft.

**Gate H1 — ISA/ABI baseline**
- Instruction formats, opcode allocation, trap semantics, memory model, CSR map, privilege profile, reset vector, and ABI are internally consistent.
- Reference model and encoder/decoder agree on all assigned encodings.
- Reserved encodings are rejected deterministically.

**Gate H2 — Microarchitecture specification**
- Module contracts, queue protocols, recovery, exception flow, LSU ordering, MMU, and cache interfaces are specified.

**Gate H3 — RTL completion and integration**
- All mandatory blocks integrated; no placeholder top-level path for required functionality.
- Static source audit complete.

**Gate H4 — Final verification**
- Only after H0–H3 and source review: lint, simulation, formal, differential testing, coverage closure, synthesis, and physical-design estimation.
- This project plan intentionally defers execution of simulation/formal/synthesis until the final verification phase.

## 7. Requirement traceability

Detailed traceability is maintained in `MX64H_REQUIREMENTS_TRACEABILITY.csv`. A requirement is not “passed” merely because a document mentions it; status remains `OPEN` until evidence exists.
