# MX64-H Phase 37.1 — Research Basis and Implementation Decisions

## Sources reviewed

1. James C. Hoe, **“Superscalar Out-of-Order Demystified in Four Instructions,”**
   2003. The paper advocates an RTL-level, cycle-accurate model with explicit
   rename, issue, execute, completion and retirement; it also lists true-dependence
   release, consecutive-cycle dependent issue, fast branch rewind and precise
   exception behavior as key correctness/performance requirements.
2. Marco A. Ramírez et al., **“Direct Instruction Wakeup for Out-of-Order
   Processors,”** IWIA 2004. It describes wakeup/select as a critical issue-queue
   function and compares CAM, dependency-matrix and successor-pointer approaches.
   The paper's proposed pointer/MWT mechanism is an optimization direction, not
   necessary for the current 16-entry MX64-H queues.
3. Il Park, Chong Liang Ooi, and T. N. Vijaykumar, **“Reducing Design
   Complexity of the Load/Store Queue,”** 2003. The paper describes in-flight
   memory operations maintained in program order and LSQ searches for forwarding,
   store-load violations, and (where required) load-load ordering.
4. Berkeley **BOOM documentation**, pipeline, rename, issue unit, ROB and LSU
   sections. It separates integer, FP and memory issue queues; uses age-aware or
   unordered issue policies; distinguishes fast ALU wakeup from writeback wakeup;
   and only permits stores to reach memory after commit.

## Research-derived rules applied

- Memory uops must not enter an integer-ALU-only issue queue.
- Memory operations receive a dedicated issue queue and a stable ready/valid
  transfer boundary to the LSU side.
- This initial memory queue is conservative and in-order: the oldest memory uop
  blocks younger memory uops until its operands are ready and the LSU accepts it.
  This avoids allowing a younger load to reach the memory-ordering unit before an
  older store has even been allocated there.
- Wakeup is applied to resident entries and same-cycle enqueues. Unresolved source
  references are acquired on enqueue and released exactly once on wakeup or kill.
- External memory-result writeback is connected to the PRF and to memory-queue
  wakeup so future memory uops may wake on load results.
- Memory completion now has its own ROB completion lane (beyond integer and branch
  completions). Store completion can mark the ROB done without a PRF write; load
  completion can both mark the ROB done and write its destination; a fault returns
  exception metadata and must not write a PRF destination.
- Existing ROB allocation remains atomic with dispatch acceptance; only the target
  queue that owns the uop may accept it.

## Deliberate non-adoptions

- Do not copy BOOM's implementation or assume RISC-V ISA semantics. MXISA-64 is
  custom and its encoding remains draft.
- Do not adopt direct successor-pointer wakeup yet. At 16 entries, the current
  tag-broadcast queue is simpler; the paper's lower-power structure is a future
  PPA experiment after functional verification.
- Do not implement speculative load issue, multiple outstanding memory requests,
  virtual memory, atomics or coherence in this increment.

## Known gaps discovered during integration

- The old dispatch classifier sent loads/stores to `integer_execution_cluster`,
  whose guard rejects non-integer uops. Phase 37.1 routes them to a separate
  memory issue queue instead.
- The memory issue output is not yet connected to an LSU request/response adapter.
  The existing LSU/cache subsystem reports an LSU lifecycle slot but does not itself
  carry the ROB tag and destination physical tag through the memory response path.
  The external consumer must retain `rob_tag` and `dst_tag` and return the new ROB
  completion channel; this adapter remains required before the core can retire loads.
- Branch execution is still an external boundary; no complete branch execution
  unit is integrated into `mx64_top`.
- `mx64_top` remains a non-functional shell. This phase does not claim a CPU top.
- ISA memory-operation minor-field mapping and load signedness/size remain draft
  because `docs/ISA_SPEC.md` explicitly says exact encodings are not frozen.

## Interface protocol

`memory_issue_valid` and `memory_issue_uop` remain stable while
`memory_issue_ready` is low, except during a documented flush/recovery event.
The memory queue issues the oldest resident memory operation only. The downstream
consumer must preserve its `rob_tag`, `dst_tag`, `writes_dst`, `seq_num`, operand
values, and raw instruction until a matching completion/fault is returned.


## Bibliographic notes and interpretation

- Park, Ooi & Vijaykumar (2003), “Reducing Design Complexity of the Load/Store Queue,” explains that an LSQ tracks in-flight memory operations in program order and must support forwarding plus violation checks. MX64-H's phase-37.1 memory issue queue is not a replacement for that LSQ; it guarantees ordered delivery into the existing LSU so the LSU has not missed an older operation.
- Kim & Lipasti (MICRO-36, 2003), “Macro-op Scheduling: Relaxing Scheduling Loop Constraints,” motivates the wakeup/select timing problem. MX64-H retains conventional tag wakeup for this small queue; it does not adopt the paper's macro-op pipeline.
- BOOM documentation is used as an implementation reference, not as an ISA or memory-model authority for MXISA-64. In particular, the new queue is more conservative than BOOM's speculative load issue policy.

## References

1. J. C. Hoe, “Superscalar Out-of-Order Demystified in Four Instructions,” 2003.
2. M. A. Ramírez et al., “Direct Instruction Wakeup for Out-of-Order Processors,” IWIA 2004.
3. I. Park, C. L. Ooi, and T. N. Vijaykumar, “Reducing Design Complexity of the Load/Store Queue,” 2003. <https://engineering.purdue.edu/~vijay/papers/2003/lsq.pdf>
4. I. Kim and M. H. Lipasti, “Macro-op Scheduling: Relaxing Scheduling Loop Constraints,” MICRO-36, 2003. <https://pharm.ece.wisc.edu/papers/micro2003ikim.pdf>
5. Berkeley Architecture Research, “The Issue Unit,” <https://docs.boom-core.org/en/latest/sections/issue-units.html>.
6. Berkeley Architecture Research, “The Load/Store Unit,” <https://docs.boom-core.org/en/latest/sections/load-store-unit.html>.
7. Berkeley Architecture Research, “The BOOM Pipeline,” <https://docs.boom-core.org/en/latest/sections/intro-overview/boom-pipeline.html>.

The above references are design inputs, not verification evidence for MX64-H. No paper establishes that this implementation is correct; local RTL validation remains necessary.


## Wakeup collision priority

The memory issue queue scans wakeup lanes in ascending order and only updates an
operand while it is not ready. Therefore, when duplicate valid lanes broadcast
the same physical tag with conflicting values, lane 0 wins. This matches the
physical register file's documented port-0 priority. A directed test now checks
that the memory queue and PRF do not disagree about the value associated with
a same-cycle duplicate-tag collision. The producer should still avoid such
collisions; the priority is deterministic defensive behavior, not permission to
broadcast inconsistent values.
