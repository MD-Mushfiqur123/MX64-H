# MX64-H Platform and Boot Contract (Draft 0.1)

## Scope

This document defines the software-facing boundary between the shared MX64-H executable format and a concrete FPGA or ASIC/SoC integration. It does **not** define a board-specific address map and does not claim that a boot ROM or loader has been implemented.

## Shared executable input

The linker emits an ELF64 little-endian `ET_EXEC` for private experimental `e_machine=0xFE64`. The Phase 11 prototype emits a page-aligned RX `.text` segment and, when initialized data or BSS exists, a separate page-aligned RW segment. `.bss` is represented as `SHT_NOBITS`; its bytes are absent from the file but included in the RW segment's `p_memsz`. The entry point must fall inside an executable load segment. The machine identifier is not registered and this remains an internal prototype ABI.

## MX64-H boot-image envelope v1

All integer fields are little-endian. The fixed header is 128 bytes, followed immediately by the complete ELF payload; no implicit padding or trailing bytes are accepted.

| Offset | Size | Field | Definition |
|---:|---:|---|---|
| 0 | 8 | magic | ASCII bytes `MX64HBI1` |
| 8 | 2 | version | `1` |
| 10 | 2 | header_size | `128` |
| 12 | 4 | flags | Must be zero in v1 |
| 16 | 4 | platform_id | `0` generic, `1` FPGA, `2` ASIC |
| 20 | 4 | payload_kind | `1` means ELF64 ET_EXEC |
| 24 | 4 | reserved0 | Must be zero |
| 28 | 8 | payload_offset | Must be `128` |
| 36 | 8 | payload_size | Exact ELF payload byte count |
| 44 | 8 | entry | Must match ELF `e_entry` |
| 52 | 32 | sha256 | SHA-256 of the exact ELF payload bytes |
| 84 | 44 | reserved | Must be all zero |

The parser validates the envelope, digest, ELF machine/type, existence of a `PT_LOAD` segment, and that the ELF entry lies inside an executable load segment. It also rejects W+X load segments, overlapping loadable memory ranges and 64-bit address-range overflow. SHA-256 here detects accidental corruption; it does **not** authenticate the producer or provide signature/security guarantees.

## Loader obligations (reference model implemented; hardware loader not implemented)

`tools/mx64/load_image.py` is a software reference model. It preflights the complete image against a complete platform profile, validates platform ID, physical-address width, region kind and permissions, rejects MMIO destinations and overlapping ranges, and creates memory images with the `p_memsz - p_filesz` tail zero-filled. It performs no device writes and is not firmware.

A real platform loader must, before modifying memory:

1. Validate the complete container and ELF structure.
2. Match the image platform ID to the running platform (or accept `generic` under an explicit policy).
3. Check every `PT_LOAD` destination range against the platform's RAM map; reject overflow, wraparound, MMIO destinations and forbidden permissions.
4. Copy `p_filesz` bytes from the file image to the selected load address, then zero `p_memsz - p_filesz` bytes.
5. Enforce executable/write permissions and any platform-specific cache maintenance requirements. Memory-map regions identify `kind` as `rom`, `ram` or `mmio`; `mmio` is never a PT_LOAD destination.
6. Initialize stack, privilege/CSR state, interrupt policy and other platform state according to a separately frozen ABI.
7. Transfer control to the validated entry only after all checks and initialization succeed.

The software linker now emits separate RX and RW load segments. A future loader must zero the RW segment's `p_memsz - p_filesz` tail, which includes `.bss` and any alignment gap. No platform loader firmware or hardware boot ROM is implemented.

## FPGA profile requirements

A selected FPGA target must specify the exact vendor/part, toolchain, clock/reset plan, physical address width, reset vector, boot source, ROM/RAM ranges and memory initialization mechanism. The `platforms/fpga/template.json` file deliberately leaves unknown board facts as `null`.

## ASIC profile requirements

A selected ASIC/SoC target must specify the SoC identity, process and PDK revision, physical address width, reset vector, boot ROM capacity, boot source, SRAM/DRAM map, clock/reset, debug and memory-controller integration. The `platforms/asic/template.json` file deliberately leaves unknown implementation facts as `null`.

## Address-map policy

No universal reset vector, ROM base, RAM base, MMIO base, PADDR width or boot source is assigned by this draft. These values are integration inputs and must be approved for the selected board/SoC. The profile checker rejects overlapping configured regions and ranges that exceed a configured physical address width.

## Security and release limitations

The v1 envelope has no signature, key management, anti-rollback counter, encryption, compression, recovery image, flash partition table or secure-boot chain. Do not use it as a production firmware update format. Those functions require a threat model and platform root-of-trust design.
