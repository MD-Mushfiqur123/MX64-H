# MX64-H Phase 37.2 — LSU-to-ROB Transaction Adapter

## Scope

This phase adds `rtl/memory/mx64_lsu_rob_adapter.sv`, a standalone boundary
between the single-wide memory issue UOP stream and the existing
`mx64_lsu_cache_subsystem`. It retains full ROB tags and physical destination
metadata across the cache transaction, returns load completion/writeback, and
retains stores until the ROB retirement stream authorizes their commit.

The adapter is not instantiated into `mx64_top`; the project still has no
functional top-level CPU. It is intended to connect to the exposed
`memory_issue_valid/uop/ready` and `memory_complete_*` ports of
`mx64_frontend_dispatch`.

## Research and architecture basis

The design follows the classic LSQ separation described by Park, Ooi and
Vijaykumar (2003): speculative store allocation is distinct from the point at
which a store becomes globally visible. BOOM's LSU documentation is used as an
implementation reference for commit-authorized stores, not as an MXISA-64
semantic authority.

Sources:
- Park, Ooi & Vijaykumar, “Reducing Design Complexity of the Load/Store Queue”
  (2003), https://engineering.purdue.edu/~vijay/papers/2003/lsq.pdf
- Berkeley BOOM, “The Load/Store Unit”,
  https://docs.boom-core.org/en/latest/sections/load-store-unit.html
- MXISA-64 draft opcode map: `docs/isa/MXISA64_OPCODE_TABLE.csv`

## Transaction contract

### Issue and decode

- Accepts one memory UOP at a time.
- Load major opcode is `0x06`; minor values 0..6 map to LB, LBU, LH, LHU, LW,
  LWU, LD.
- Store major opcode is `0x07`; minor values 0..3 map to SB, SH, SW, SD.
- Size and signedness are derived from the draft opcode table. This mapping
  remains provisional until the ISA specification is frozen.
- Effective virtual address is `src1_value + immediate`.
- Alignment is checked independently of cache readiness. Misaligned accesses
  complete with `EXC_LOAD_MISALIGNED` or `EXC_STORE_MISALIGNED`.
- Physical address is an external translation input for the currently presented
  UOP. This phase does not implement a TLB or page-table walker.

### Loads

- On LSU acceptance, lifecycle slot -> full ROB tag, destination physical tag,
  destination-write flag, and virtual address are retained.
- Cache response uses the lifecycle slot to recover the original full ROB tag.
- Successful response emits ROB completion and (when `writes_dst`) PRF writeback
  in the same cycle.
- Cache error emits `EXC_LOAD_FAULT` and suppresses PRF writeback.
- A precise flush marks an already accepted load killed but retains its
  transaction identity until the non-cancelable cache response is drained.
  The stale response is consumed without ROB completion or PRF writeback.

### Stores

- Speculative store acceptance captures full ROB tag, physical address, data,
  byte mask, access size, lifecycle slot and store-order slot.
- A store becomes ROB-complete when accepted into the speculative LSU store
  queue. It is not externally visible yet.
- The retirement candidate is matched by the complete ROB tag, including
  generation. The adapter presents the matching store-commit request and
  asserts `retire_store_ready[0]` only when the subsystem accepts that request.
- The current LSU exposes one store-commit port; a lane-1 store is held until
  it becomes lane 0.
- Already committed stores are irrevocable. Their identity is retained across
  a younger precise flush until the cache response/error is consumed.
- A committed-store write error is reported through a post-retirement error
  output; it cannot be converted into a precise ROB exception after retirement.

## Retirement gate extension

`mx64_control_subsystem` now accepts `retire_gate_ready`; the trap controller
uses it as normal retirement readiness. `mx64_frontend_dispatch` exposes and
forwards this input. A future top-level wrapper must connect the adapter's
`retire_store_ready` to this gate. Non-store retirements may pass with ready=1.

## Important limitations / integration blockers

1. The adapter is standalone and not yet instantiated in `mx64_top`.
2. `issue_paddr` must be the translated physical effective address for the
   currently presented memory UOP. Translation, permission checks and page
   faults remain external.
3. Branch-mispredict recovery is not yet propagated into the LSU/cache
   subsystem. A younger memory UOP already accepted by the LSU before a branch
   misprediction may remain in the memory-ordering structures. This must be
   solved before claiming precise speculative memory recovery.
4. The cache is single-outstanding. The adapter conservatively stalls new memory
   issue while a committed store is in flight and while a cache response is
   being consumed.
5. ISA size/signedness mapping is based on the draft opcode CSV and is not frozen.
6. No HDL compiler/simulator is installed in this environment. This phase does
   not claim SystemVerilog parse, elaboration, simulation, formal or synthesis
   success.

## Required top-level wiring

- `frontend_dispatch.memory_issue_valid/uop` -> adapter `issue_valid/uop`
- adapter `issue_ready` -> `frontend_dispatch.memory_issue_ready`
- adapter `memory_complete_*` -> `frontend_dispatch.memory_complete_*`
- adapter `memory_wb_*` -> `frontend_dispatch.memory_wb_*`
- frontend `retire_valid/tag/kind` -> adapter retirement candidate inputs
- adapter `retire_store_ready` -> frontend `retire_gate_ready`
- adapter external memory bus -> platform memory interface
- platform translation -> adapter `issue_paddr`
- frontend trap/flush -> adapter `flush_all`

The top-level integration must also ensure the adapter's full ROB tags remain
valid across branch recovery, and must add LSU selective-recovery semantics.
