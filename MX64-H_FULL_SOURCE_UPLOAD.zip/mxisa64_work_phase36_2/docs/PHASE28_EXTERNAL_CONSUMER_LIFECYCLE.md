# MX64-H Phase 28 — External Consumer Reference Lifecycle Interface

## Delivered

The reference tracker now has an explicit external-consumer event interface, carried end-to-end through `mx64_frontend_dispatch` → `mx64_control_subsystem` → `mx64_dispatch_controller` → `mx64_integer_backend`. The default interface width is eight simultaneous acquire events and eight simultaneous release events per cycle. The backend nets these events with the existing IQ, ROB, and rename-map events before updating the shared reference-count bank.

New top-level signals:

- `external_ref_acquire_valid[tag]` / `external_ref_acquire_tag[tag]`
- `external_ref_release_valid[tag]` / `external_ref_release_tag[tag]`

## Consumer protocol (mandatory)

1. Assert acquire in the same cycle that the consumer accepts and begins retaining a physical tag. Do not acquire merely because a candidate was presented and then backpressured.
2. Keep the reference while any queue entry, pipeline stage, replay record, reservation, or delayed operation can still use the tag.
3. Assert exactly one release when that consumer's final retained use ends: completion, cancellation, flush, selective recovery, or dequeue as appropriate.
4. If a consumer drops two tags in one cycle, use two release lanes. Duplicate release is a correctness bug and will cause the tracker underflow assertion.
5. Same-cycle acquire/release events are netted by tag before final-reference reclamation is generated.
6. Never drive unknown or out-of-range tags. Invalid tag events are asserted in simulation/formal configurations.

## Suggested event ownership

- Branch unit: acquire source tags on accepted branch-uop enqueue/dispatch; release each retained source when the branch operation no longer needs it, including mispredict/flush paths. A branch link destination is already represented by ROB/RAT ownership; do not double-acquire it unless the branch unit independently retains it.
- LSU/load queue/store queue: acquire address/data/base tags when accepted into a structure; release when address/data consumption and all replay/forwarding references are complete.
- FP/SIMD pipelines: acquire operands retained beyond dispatch; release at final completion or kill.
- Any future replay, atomic, coprocessor, or debug structure: use the same protocol.

## Correctness boundary

This phase adds the event plumbing and contract; it does not invent lifecycle events for external modules that are not implemented/connected yet. The current branch execution unit remains an external boundary, and there is no integrated LSU or FP/SIMD consumer in this repository slice. Until each real consumer drives these ports correctly, `physical_reclaim_bitmap` is only safe for the event domains that actually report references. The interface width is configurable; if more than eight same-cycle events are needed, raise `EXTERNAL_REF_WIDTH` consistently at the top-level wrapper.

## Verification status

Repository and RTL source-contract checks plus the software-only suites are run. These are static/source and software checks, not HDL compile/elaboration. No SystemVerilog simulation, formal proof, or synthesis was run; per project instruction, simulation remains deferred until the final verification stage.
