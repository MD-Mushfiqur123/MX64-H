# MX64-H Phase 33 — Blocking L1D Cache Controller

## Scope

Phase 33 replaces the empty `cache_hierarchy` placeholder with a functional,
blocking, direct-mapped L1 data-cache controller. It is a cache-controller RTL
model, not a complete hierarchy integration. L1I, L2, coherence, MMU/TLB,
SRAM macro wrappers and the final LSU-to-cache request/response bridge remain
separate work.

## Organization

- 64-bit data path and 64-byte cache lines by default.
- 16 direct-mapped sets by default (1 KiB capacity in this baseline).
- Tag, valid and dirty state per set.
- Write-back, write-allocate policy.
- One CPU request outstanding; response is held stable under backpressure.
- One memory transaction outstanding at a time.

The arrays are behavioral flop arrays. They are not an SRAM macro inference
claim and should be replaced through a technology wrapper after the target
memory compiler contract is selected.

## CPU-side contract

A request is accepted only when `req_valid && req_ready`. `req_byte_enable`
is a low-contiguous byte mask relative to the request's naturally aligned
access; `req_wdata` is right-justified. The cache shifts enabled bytes into the
correct byte lanes of the containing 64-bit word using the byte address.

A load response returns the containing aligned 64-bit word; byte/halfword/
word extraction and sign/zero extension remain in the LSU/load-result path.
A store response acknowledges completion in the cache; dirty data may remain
resident and is written to backing memory on eviction.

## Memory-side contract

The memory interface transfers complete cache lines. A write request carries
a full line and all byte strobes asserted. A read request returns one full
line. Request fields remain stable until `mem_req_ready`; response is accepted
when `mem_rsp_valid && mem_rsp_ready`. `mem_rsp_error` is propagated to the
CPU response. The backing memory must return exactly one response for each
accepted memory request.

## State machine

`IDLE -> (HIT -> RESP) | (optional WRITEBACK -> REFILL -> RESP)`.

- Dirty conflict: write victim line to its reconstructed physical line address.
- Refill: fetch the requested line and install its tag/data.
- Store miss: merge request bytes into the refill line and mark it dirty.
- Load miss: return the selected aligned 64-bit word from the refill line.
- Response backpressure: response payload remains stable until accepted.

## Explicit limitations / open work

- Blocking, single-outstanding controller; no MSHRs or hit-under-miss.
- Direct-mapped only; no associativity or replacement policy.
- No L1I, L2, coherence protocol, ECC, parity, prefetcher or cache banking.
- No fence/flush clean-and-invalidate sequence; `invalidate_all` discards dirty
  lines and must only be used after platform/software has cleaned them.
- No TLB/page-fault integration or physical-address translation in this module.
- No end-to-end connection from `mx64_lsu_pipeline` yet. Phase 32's LSU
  interface and this cache controller are separately specified components.
- Arrays are not yet mapped to SRAM macros.

## Verification status

Repository/software checks and source-contract checks can validate file
presence and documented interface contracts, but they do not prove SystemVerilog
correctness. A directed SystemVerilog testbench is supplied for future use;
HDL compile, elaboration, simulation, formal verification and synthesis were not
run in this environment.
