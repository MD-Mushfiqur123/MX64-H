# MX64-H Phase 22 — Branch Writeback and Unified Wakeup

## Delivered

Phase 22 extends the Phase 21 integer PRF path to include branch link-register
writeback and issue-queue wakeup.

- The wrapper exposes a branch-link writeback valid and physical destination
  tag from the branch execution boundary.
- The integer PRF now has three write ports: two integer ALU completion lanes
  and one branch link writeback lane.
- The integer backend accepts the branch writeback as an external wakeup.
- The integer execution cluster merges its two integer completion broadcasts
  with the branch writeback broadcast.
- The issue queue has a separately parameterized wakeup width, so the number
  of wakeup sources need not equal issue width.

## Timing/priority contract

The issue queue sees all three wakeup sources combinationally in the cycle
they are presented. The PRF's sequential write priority is port 0, then port 1,
then port 2 (port 0 wins same-address collision). The branch source is port 2.
Correct operation expects distinct destination tags for simultaneous live
writebacks. The PRF now contains a simulation-time assertion that reports any
same-cycle multi-port destination collision; port 0 still defines deterministic
priority.

## External branch-unit contract

The branch execution unit must retain the physical destination tag from the
accepted `branch_unit_uop` and present it with `branch_link_wb_valid`.
The branch link writeback must accompany an accepted branch resolution
(`branch_resolve_valid && branch_resolve_ready`); a simulation-time assertion
checks this contract. The wrapper does not infer a destination tag from a ROB
tag.

## Remaining limits

- Branch result writeback is an explicit external interface; branch execution
  is not implemented in this wrapper.
- No general multi-class completion arbiter yet; this phase combines two
  integer ALU completions and one branch link completion.
- Loads, stores, FP, multiply/divide and other execution classes are not yet
  connected as writeback sources.
- The PRF is a behavioral flop array, not a physical SRAM macro.
- No HDL compile, simulation, formal verification or synthesis has been run.
