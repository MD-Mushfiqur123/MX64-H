# MX64-H Phase 26 — Reference Tracker Integration

## Delivered

The Phase 25 reference-count primitive is now connected to three live RTL
ownership domains in the integer backend.

### 1. Rename / architectural mapping ownership
- The tracker seeds p0–p31 with one initial architectural mapping reference.
- A successfully allocated destination with `writes_rd` set acquires one
  speculative/architectural mapping reference.
- When an older mapping is displaced at successful non-exception retirement,
  the commit/free event releases that mapping reference.

### 2. Integer issue-queue operand references
- An accepted IQ enqueue acquires a reference for each source operand that is
  not yet ready.
- A matching wakeup releases that source reference once its value is captured
  in the queue entry.
- Flush and branch-recovery kills release unresolved source references held by
  discarded entries.
- Ready operands do not retain physical-tag references because their values
  are already copied into the queue entry.

### 3. ROB destination ownership
- A successful ROB allocation for a real destination-producing instruction
  acquires a separate reference to its destination physical tag.
- Successful non-exception retirement releases that ROB metadata reference.
- The mapping reference remains after retirement until a later committed
  replacement displaces it.

## Visibility

The integrated backend exports `physical_ref_bitmap` and
`physical_ref_count` through the dispatch controller, control subsystem, and
frontend/dispatch wrapper as debug/observability signals.

## Important limits

This is a meaningful integration slice, not yet a complete global liveness
proof:
- Branch-unit source operands are not yet included in this tracker.
- Store queue, load queue, LSU, FP/SIMD, and other execution domains do not
  yet emit acquire/release events.
- The current issue queue stores operand values and releases unresolved
  source references on wakeup; this is intentionally tied to the existing
  integer-IQ contract.
- The free-list is not yet directly gated by `physical_ref_bitmap`. The bitmap
  is currently diagnostic; the next safety stage must reconcile its zero-count
  state with free-list return/allocate decisions and recovery snapshots.
- No SystemVerilog compile, elaboration, simulation, formal verification, or
  synthesis was run. Static source contracts do not prove event timing.

The reference counter must not be treated as a complete allocator authority
until all consumer domains are connected and the free-list integration is
verified.
