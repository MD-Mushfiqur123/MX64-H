# MX64-H Phase 37.1 — Dispatch Interface Map

```text
mx64_frontend / decoder
        |
        v
mx64_control_subsystem
        |
        v
mx64_dispatch_controller
        |---- integer ALU uops ----> mx64_integer_backend / integer_execution_cluster
        |---- branch / jump uops --> external branch execution interface
        |---- load / store uops ---> mx64_memory_issue_queue
        |                                  |
        |                                  v
        |                         memory_issue_valid/uop/ready
        |                                  |
        |                                  v
        |                         LSU integration adapter (NOT YET BUILT)
        |
        +---- ROB allocation / in-order retirement
```

## Memory issue queue input

Post-rename UOP contains `rob_tag`, sequence number, destination tag,
source physical tags/readiness/value, load/store classification and raw
instruction. Dispatch is accepted only when the ROB can allocate and the
memory queue has capacity.

## Memory issue queue output

One oldest-ready memory UOP is offered using ready/valid. It may not be
replaced while stalled. `flush` and branch `recover` may cancel wrong-path
entries; the consumer must receive the same recovery/flush event.

## Physical-register references

The queue acquires references for unresolved `src1`/`src2` operands. It releases
on matching writeback wakeup or when the entry is flushed/recovery-killed. These
events are merged into the existing physical-register reference tracker path.


## Memory completion back to ROB (Phase 37.1 extension)

The frontend-dispatch boundary now accepts a separate `memory_complete_valid` channel carrying the full `memory_complete_rob_tag`, completion value, and exception metadata. This passes through control/dispatch into an additional ROB completion lane (`WIDTH+1`), while `memory_wb_valid/tag/data` independently writes a successful load result to the PRF. A store can complete the ROB without a PRF write. A memory fault completes the ROB with exception metadata and must not write the PRF. The LSU adapter that maps cache/LSQ lifecycle slots back to ROB tags is still not implemented; it must retain `rob_tag` and `dst_tag` from `memory_issue_uop` until completion.


### Completion transfer contract

`memory_complete_valid` is a one-cycle completion event, not a ready/valid channel. The current memory subsystem is single-outstanding, so at most one memory completion is presented per cycle. The producer must hold the original full ROB tag until it emits the pulse, suppress killed completions after flush/recovery, and never emit a completion for a slot-reused/stale generation. A future multi-outstanding LSU or a design with multiple memory responses per cycle must add completion arbitration/ready backpressure and enough ROB completion lanes.
