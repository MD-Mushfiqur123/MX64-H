# MX64-H Phase 36.2 — Committed-Store Error Handshake

## Interface
`mx64_lsu_cache_subsystem` exposes `store_error_valid`, `store_error_ready`,
and `store_error_lifecycle_slot`. The slot is the identity latched when the
committed store request was accepted.

## Consumption rule
For an ordinary response, the bridge response is consumed when
`cache_rsp_ready` is high. For a committed-store error, it is consumed only
when both `cache_rsp_ready` and `store_error_ready` are high. The lifecycle
identity remains stable under either form of backpressure.

The platform must connect this channel to a non-speculative machine-check or
asynchronous-store-error handler. The committed store must not be replayed as
an ordinary speculative instruction.

## Scope boundary
This closes the local LSU/cache response-loss gap. It does not implement the
platform handler or connect it through `mx64_top`, which remains non-functional.
