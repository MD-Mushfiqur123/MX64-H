# MX64-H Phase 24 — Physical Register Lifetime and Free-List Safety

## Delivered

This phase hardens physical-register reclamation in `rtl/rename/free_list.sv`.

- A free is accepted only when the physical tag is in range, is not p0, and
  was allocated before the current cycle (`free_q[tag] == 0`).
- Duplicate or stale frees are ignored by the state-update path rather than
  making an already-free entry appear newly free.
- A simulation-time assertion reports duplicate/stale free attempts.
- A second assertion reports duplicate free tags presented in the same cycle.
- The architectural zero register remains permanently reserved when restoring
  a free bitmap after flush/recovery.
- Accepted frees are incorporated into the branch checkpoint free-bitmap
  snapshots for the cycle.

## Invariants

1. p0 is never allocated or freed.
2. A free-list bit of 1 means available for allocation.
3. A free request for a bit already equal to 1 is stale/duplicate.
4. A free request must refer to an in-range physical tag.
5. Duplicate free requests in the same cycle are an integration error.

## Scope and remaining work

This is a reclamation guard, not a complete proof of physical-register
liveness. A full lifetime proof still needs RTL-level checking that no
speculative RAT, committed RAT, checkpoint, in-flight uop, or pending
writeback references a tag when it is returned to the free list. The present
implementation does not yet add a global reference-count table or a complete
free/allocate transaction scoreboard.

No SystemVerilog compile, elaboration, simulation, formal verification, or
synthesis was run in this phase.
