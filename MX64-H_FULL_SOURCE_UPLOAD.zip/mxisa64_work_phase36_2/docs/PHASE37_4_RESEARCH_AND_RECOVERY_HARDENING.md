# Phase 37.4 — Research Review and Recovery Hardening

## Research reviewed

1. **MIPS R10000 Microprocessor User's Manual, Version 2.0 (1996).** The decode/rename unit maps logical registers to physical registers, tracks inflight work in an active list, and dispatches into separate integer, floating-point, and address queues. The execution queues issue independently while architectural graduation remains ordered.
   - https://sgifiles.irixnet.org/sgi/doc/R10000/User_Manual/t5.ver.2.0.book.pdf
   - Supporting architectural overview: https://www.eecg.toronto.edu/~moshovos/ACA07/lecturenotes/r10000%20(mpr).pdf

2. **Kessler, McLellan & Webb, “The Alpha 21264 Microprocessor Architecture” (1998).** The design combines register renaming, split issue structures, multiple integer execution pipelines, and aggressive branch prediction. This is a useful reference for keeping rename/issue/execution responsibilities decoupled.
   - https://redirect.cs.umbc.edu/portal/help/architecture/alpha21264a.pdf

3. **Berkeley BOOM documentation — Pipeline, Rename, Issue Unit, Execute Pipeline and ROB.** These documents describe explicit PRF renaming, per-branch rename/free-list snapshots, distinct issue queues by operation class, wakeup/select, branch masks, and ordered commit. They are implementation documentation rather than a peer-reviewed paper, but provide detailed, inspectable RTL design contracts.
   - https://docs.boom-core.org/en/latest/sections/intro-overview/boom-pipeline.html
   - https://docs.boom-core.org/en/latest/sections/rename-stage.html
   - https://docs.boom-core.org/en/latest/sections/issue-units.html
   - https://docs.boom-core.org/en/latest/sections/execution-stages.html
   - https://docs.boom-core.org/en/latest/sections/reorder-buffer.html

4. **Park, Ooi & Vijaykumar, “Reducing Design Complexity of the Load/Store Queue,” MICRO-36 (2003).** The LSQ preserves in-flight memory operations in program order, performs store-to-load forwarding and violation checks, and faces associative-search bandwidth/capacity pressure. The paper motivates conservative ordering first, followed by measured scaling optimizations rather than premature CAM complexity.
   - https://engineering.purdue.edu/~vijay/papers/2003/lsq.pdf
   - DOI: https://doi.org/10.1109/MICRO.2003.1253245

## Design decisions for MX64-H

- Preserve the project's explicit physical-register renaming and reference-counted lifetime model. A stale physical destination must not be reclaimed until the ROB and every consumer reference have released it.
- Keep integer and memory issue queues separate. Integer UOPs use the integer execution cluster; memory UOPs use the dedicated memory issue queue and LSU path.
- Treat wakeup as a same-cycle event for both resident entries and newly enqueued UOPs. The issue queue already has enqueue-side wakeup capture; retain this contract and add executable HDL tests when a simulator is available.
- Use the branch checkpoint's sequence as the single recovery boundary. Preserve the resolving branch and all older UOPs; discard only younger speculative UOPs and uncommitted stores.
- Keep cache transactions non-cancelable under the current interface. A younger in-flight load is marked killed, but its response identity remains allocated until the response is consumed; no ROB completion or PRF writeback may escape.
- Stores become externally visible only after ROB retirement authorization. A committed store is not removed by a younger branch recovery.
- Use wrap-safe signed sequence comparisons (`$signed(a-b)`) under the invariant that fewer than half the sequence-number space of live allocations can exist. Sequence numbers must not wrap ambiguously while entries remain live.

## RTL changes in this hardening pass

- Connected branch-mispredict recovery from `mx64_frontend_dispatch` into `lsu_reference_lifecycle`; previously this reference-retention path was tied off.
- Added `lsu_store_alloc_seq` to the wrapper contract so store reference ownership is associated with the actual UOP age instead of constant sequence zero.
- Replaced raw unsigned sequence comparisons in the memory ordering unit, LSU reference lifecycle, and LSU/ROB adapter with wrap-safe signed-difference comparisons.

## Not claimed

This pass does not make `mx64_top` a functional CPU. The current top is still an empty shell, and frontend/dispatch and LSU/ROB adapter remain separate integration boundaries. No HDL compiler, simulator, formal engine, or synthesis tool is assumed available. The changes require compilation, elaboration, directed recovery tests, and end-to-end execution before they can be called functionally verified.
