# M2.2 ROB + integer execution integration status

Added `rtl/core/mx64_integer_backend.sv`.

## Connected path
- Two-wide integer dispatch enters the integer execution cluster.
- Two ALU completion lanes carry the ROB tag and result.
- Completion lanes feed the existing reorder buffer.
- ROB exposes in-order, up-to-two-wide retirement metadata.
- ROB allocation remains an explicit interface so the upstream dispatch
  controller can coordinate rename, IQ enqueue and ROB capacity.

## Mandatory integration contract
For each lane, the upstream controller must:
1. Allocate a ROB entry and wait for `rob_alloc_ready`.
2. Put the returned `rob_alloc_tag` into `dispatch_uop[lane].rob_tag`.
3. Present matching ROB allocation and dispatch handshakes atomically.
4. Set `rob_alloc_rd` to the architectural destination register (not the
   physical destination tag in the issue uop).
5. Retire architectural register state / committed rename map only when
   `retire_valid && retire_ready`.

The current wrapper has an assertion against dispatch without same-lane ROB
allocation, but does not implement a full atomic dispatch controller.

## Review fixes
- Initialized ROB allocation-index combinational outputs to avoid inferred
  latches.
- Phase 11 uses an 8-bit per-slot epoch, a 14-bit full ROB tag for the 48-entry profile, and increments epochs on flush and slot allocation.

## Known limitations
- ROB generation is an 8-bit epoch per slot in the current 48-entry profile. It wraps after 256 allocations of the same slot; long-latency units must cancel pre-flush requests, and verification must cover wrap behavior. This is not a mathematically unbounded stale-completion guarantee.
- The wrapper currently handles integer ALU completions only. It does not
  connect multiply/divide, branch, load/store, exceptions, MMU or caches.
- Completion exception is tied low for this ALU-only path.
- Global flush clears the ROB and execution queue; precise branch-age recovery
  and checkpoint restore are not implemented.
- Dispatch atomicity is an upstream responsibility, not yet implemented here.
- RTL has not been compiled, simulated, formally checked or synthesized.

## Required verification
- Allocate one and two ROB entries, dispatch matching uops, complete them,
  and retire in program order.
- Stall retirement lane 0 and confirm lane 1 cannot retire.
- Complete younger ROB entries before older ones and confirm no out-of-order
  retirement.
- Send stale/mismatched ROB tags and confirm they do not mark entries done.
- Flush with outstanding entries and confirm no pre-flush retirement occurs.
- Exercise ring wrap, simultaneous two-wide allocate/retire and full/empty edges.
