# M2 issue queue status

Implemented a first age-ordered issue queue draft in `rtl/scheduler/issue_queue.sv`.

Current behavior:
- Up to two uops can be enqueued and up to two ready uops can be issued per cycle.
- Two completion buses wake matching source physical-register tags.
- Wakeup is visible to selection in the same cycle.
- Selection chooses the oldest ready entries using a wrapping sequence counter.
- Flush invalidates all queued speculative work.
- Enqueue uses only slots free at the beginning of the cycle; same-cycle issue does not permit immediate physical-slot reuse.

Important limitations:
- This is a generic shared queue draft, not yet split by execution class or port capability.
- The scheduler payload currently uses 7-bit physical and ROB tags, matching the current draft configuration only.
- There is no age-based starvation proof, issue-port compatibility matrix, replay protocol, or integration with the ROB/PRF.
- The sequence-age comparison assumes fewer than 2^(SEQ_W-1) allocations separate any two live entries.
- No HDL compiler or simulator pass is claimed. Directed tests and formal properties are still required.

Next verification targets:
1. Two-wide enqueue allocates distinct entries and distinct age values.
2. Same-cycle wakeup permits issue without a one-cycle bubble.
3. Two issue ports select distinct oldest-ready entries.
4. Grant-style issue does not assert valid while the target port is stalled; verify no transfer occurs under backpressure.
5. Flush suppresses all stale queue entries.
6. Full queue plus same-cycle issue does not over-accept enqueue.
7. Count, valid bitmap and selected-entry behavior remain consistent through wraparound.
