# Phase 36 directed HDL testbench additions

Three executable-intent testbenches were added. They contain stimulus and `$fatal` checks, but are **not yet compiled or simulated** because no HDL tool is present in the authoring environment.

| Testbench | DUT | Directed scenarios |
|---|---|---|
| `unit/tb_issue_queue_same_cycle_wakeup.sv` | `issue_queue` | Two independent wakeup buses coincide with enqueue; verifies bypassed operand values/readiness and zero ref-acquire for already-ready operands |
| `unit/tb_physical_register_reference_tracker.sv` | `physical_register_reference_tracker` | Reset identity-map refs; `clear_all` restores architectural refs; suppresses reclaim during clear; non-architectural nonzero-to-zero reclaim |
| `unit/tb_cache_hierarchy_error_contract.sv` | `cache_hierarchy` | Dirty line eviction; victim writeback error; pending demand gets error; dirty victim remains valid+dirty; response stable under backpressure |

## Compile order / source list

Run from the repository root with a SystemVerilog-2012 capable simulator. The commands below are examples and must be adapted to the selected simulator's supported SystemVerilog features.

```sh
iverilog -g2012 -s tb_issue_queue_same_cycle_wakeup -o /tmp/tb_iq.vvp \
  rtl/common/mx64_pkg.sv rtl/scheduler/issue_queue.sv \
  verification/unit/tb_issue_queue_same_cycle_wakeup.sv
vvp /tmp/tb_iq.vvp

iverilog -g2012 -s tb_physical_register_reference_tracker -o /tmp/tb_ref.vvp \
  rtl/rename/physical_register_reference_tracker.sv \
  verification/unit/tb_physical_register_reference_tracker.sv
vvp /tmp/tb_ref.vvp

iverilog -g2012 -s tb_cache_hierarchy_error_contract -o /tmp/tb_cache.vvp \
  rtl/memory/cache_hierarchy.sv \
  verification/unit/tb_cache_hierarchy_error_contract.sv
vvp /tmp/tb_cache.vvp
```

## Important caveat

The tests are first-pass directed stimuli and may require simulator-specific syntax fixes. They do not establish full coverage of duplicate wakeup tags, both enqueue lanes, simultaneous enqueue and issue, all cache refill/writeback permutations, invalidate pulses during each controller state, or store lifecycle slot reuse. No test is marked PASS until a simulator actually compiles and runs it.


## Phase 36.2 integration test obligation

A future `tb_lsu_store_error_handshake` must prove:
1. An accepted committed store latches its lifecycle slot.
2. A later cache error asserts `store_error_valid` with that slot.
3. `store_error_ready=0` blocks consumption even if `cache_rsp_ready=1`.
4. `cache_rsp_ready=0` blocks consumption even if the error sink is ready.
5. Consumption occurs only when both are ready.
6. The lifecycle slot remains stable throughout backpressure.
