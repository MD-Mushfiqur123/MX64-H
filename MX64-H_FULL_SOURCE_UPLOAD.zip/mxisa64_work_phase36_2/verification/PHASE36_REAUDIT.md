# Phase-36 Re-audit Notes

This note distinguishes the supplied independent Phase-35 report from the actual Phase-36 working-tree source.

## Important source delta

The Phase-36 workspace differs from the Phase-35 archive in exactly three RTL files before the Phase-36 checker/documentation additions:

- `rtl/scheduler/issue_queue.sv`: adds `effective_enq_uop`, same-cycle wakeup matching for accepted enqueue lanes, reference-acquire decisions based on post-wakeup readiness, and storage of the effective uop.
- `rtl/rename/physical_register_reference_tracker.sv`: restores initial architectural reference counts during `clear_all` and gates reclaim during clear.
- `rtl/memory/cache_hierarchy.sv`: adds `invalidate_pending_q`, request backpressure while pending, and deferred invalidation when idle.

These are present in the Phase-36 working tree, not in the Phase-35 baseline archive. They are not HDL-verified.

## Findings retained as open

- `mx64_top` remains an empty non-functional shell.
- Dirty victim writeback errors are still returned through the current request's response channel.
- Store-order lifecycle retires on cache request acceptance; later memory/cache errors have no clearly specified architectural recovery path.
- `mx64_rob_placeholder` remains as a legacy empty module.
- Generated build/cache files remain in the Phase-35 manifest; Phase-36 manifest must be regenerated cleanly.

## Evidence discipline

A passing Python string/contract check is a static source check only. It does not establish SystemVerilog syntax validity, elaboration correctness, cycle-level behavior, race freedom, or formal correctness. No simulator/compiler is assumed available in this environment.
