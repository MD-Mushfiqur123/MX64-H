# MX64-H RTL source audit — M2.5 / Phase 11

**Scope:** textual/static source inspection only. This review does not establish SystemVerilog elaboration, simulation correctness, formal correctness, or synthesis quality. Per project order, HDL compile/simulation/formal/synthesis remain deferred to the final verification stage.

## Changes made

1. Renamed the unused `rtl/core/reorder_buffer.sv` placeholder module to `mx64_rob_placeholder`. The active `reorder_buffer` implementation remains in `rtl/scheduler/reorder_buffer.sv`, eliminating duplicate module-name declarations in glob-based source sets.
2. Expanded the 48-entry ROB tag from 7 to 14 bits: 6 slot-index bits plus an 8-bit allocation epoch. The epoch increments for each slot allocation and on global flush. Completion matching compares the complete epoch field, not only one bit.
3. Updated dispatch, integer-backend, execution-cluster and issue-uop tag widths as a single contract. Static guards reject non-48-entry profiles until the package type and all interfaces are generalized together.
4. Added an RTL source audit script that rejects duplicate module declarations and checks the ROB tag-width/epoch contract.

## Remaining architectural gaps (not fixed by this phase)

- `mx64_top.sv` remains a shell; there is no complete fetch/decode/rename/execute/memory/commit instantiation.
- PRF read ports, busy table, bypass network and writeback integration are not connected to dispatch.
- Old physical destination tags are not carried through ROB retirement, so committed-map reclamation is incomplete.
- Branch checkpoints, branch masks, selective squash and precise recovery are not complete.
- Trap/interrupt sequencing and precise architectural exceptions are not integrated.
- Integer execution is ALU-only. MUL/DIV, branch execution, LSU, memory ordering, MMU/TLB, page walker and cache hierarchy are not integrated.
- The ROB implementation remains a draft. The 8-bit epoch wraps after 256 allocations of a particular slot; long-latency units must cancel old requests, and the tag-wrap/flush protocol needs directed verification.
- Duplicate completion lanes with the same tag, arbitrary parameter widths, and simultaneous edge conditions still require HDL-level tests.

## Verification status

| Gate | Status |
|---|---|
| Python ISA/toolchain regression | PASS |
| Multi-section ELF + RX/RW/BSS example | PASS |
| Boot image pack/inspect | PASS |
| Static RTL source audit | PASS |
| SystemVerilog compile/elaboration | NOT RUN |
| RTL simulation | NOT RUN |
| Formal verification | NOT RUN |
| FPGA synthesis/timing | NOT RUN |
| ASIC synthesis/STA/physical design | NOT RUN |

No performance, clock, area, power, or silicon claims are made.
