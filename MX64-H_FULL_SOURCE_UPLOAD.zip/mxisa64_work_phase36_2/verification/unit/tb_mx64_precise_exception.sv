`timescale 1ns/1ps
module tb_mx64_precise_exception;
  import mx64_pkg::*;
  localparam int DEPTH=8, WIDTH=2, TAGW=3, GENW=16, FULLW=19;

  logic clk=0, rst_n=0, flush;
  logic tag_query_valid=0, tag_query_found;
  logic [FULLW-1:0] tag_query_tag='0, recover_tag='0;
  logic recover_valid=0, recover_found;
  logic [WIDTH-1:0] alloc_valid='0, alloc_ready;
  logic [WIDTH-1:0][FULLW-1:0] alloc_tag;
  logic [FULLW-1:0] saved_tag0;
  logic [WIDTH-1:0][63:0] alloc_pc='0;
  logic [WIDTH-1:0][4:0] alloc_rd='0;
  logic [WIDTH-1:0][6:0] alloc_kind='0, alloc_prd='0, alloc_old_prd='0;
  logic [WIDTH-1:0] alloc_exception='0;
  logic [WIDTH-1:0][3:0] alloc_exception_code='0;
  logic [WIDTH-1:0][63:0] alloc_exception_value='0;
  logic [WIDTH-1:0] complete_valid='0, complete_exception='0;
  logic [WIDTH-1:0][FULLW-1:0] complete_tag='0;
  logic [WIDTH-1:0][63:0] complete_value='0;
  logic [WIDTH-1:0][3:0] complete_exception_code='0;
  logic [WIDTH-1:0][63:0] complete_exception_value='0;
  logic [WIDTH-1:0] retire_valid, retire_ready, retire_exception;
  logic [WIDTH-1:0][FULLW-1:0] retire_tag;
  logic [WIDTH-1:0][63:0] retire_pc, retire_value;
  logic [WIDTH-1:0][4:0] retire_rd;
  logic [WIDTH-1:0][6:0] retire_kind, retire_prd, retire_old_prd;
  logic [WIDTH-1:0][3:0] retire_exception_code;
  logic [WIDTH-1:0][63:0] retire_exception_value;
  logic full, empty;
  logic [$clog2(DEPTH+1)-1:0] occupancy;

  logic [WIDTH-1:0] normal_retire_ready='1;
  logic [1:0] current_privilege=2'b11, retired_count;
  logic [63:0] trap_vector_full, trap_pc, trap_cause, trap_value, redirect_pc;
  logic trap_valid, trap_is_interrupt, flush_speculative, redirect_valid;
  logic [WIDTH-1:0] rob_retire_ready;

  logic csr_read_en=0, csr_write_en=0;
  logic [11:0] csr_read_addr='0, csr_write_addr='0;
  logic [63:0] csr_read_data, csr_write_data='0;
  logic csr_read_legal, csr_write_legal;
  logic [1:0] privilege_mode;
  logic [47:0] csr_trap_vector, mret_pc;

  always #5 clk=~clk;
  assign flush = flush_speculative;
  assign trap_vector_full = {16'd0, csr_trap_vector};

  reorder_buffer #(.DEPTH(DEPTH), .WIDTH(WIDTH), .COMPLETE_WIDTH(WIDTH),
    .TAG_W(TAGW), .GEN_W(GENW), .FULL_TAG_W(FULLW)) rob (
    .clk, .rst_n, .flush, .tag_query_valid, .tag_query_tag, .tag_query_found,
    .recover_valid, .recover_tag, .recover_found,
    .alloc_valid, .alloc_ready, .alloc_tag, .alloc_pc, .alloc_rd, .alloc_kind,
    .alloc_prd, .alloc_old_prd, .alloc_exception, .alloc_exception_code,
    .alloc_exception_value, .complete_valid, .complete_tag, .complete_value,
    .complete_exception, .complete_exception_code, .complete_exception_value,
    .retire_valid, .retire_ready, .retire_tag, .retire_pc, .retire_rd,
    .retire_kind, .retire_prd, .retire_old_prd, .retire_value, .retire_exception,
    .retire_exception_code, .retire_exception_value, .full, .empty, .occupancy
  );

  mx64_trap_controller #(.WIDTH(WIDTH)) trap_ctrl (
    .clk, .rst_n, .retire_valid, .retire_exception, .retire_pc,
    .retire_exception_code, .retire_exception_value, .normal_retire_ready,
    .current_privilege, .trap_vector(trap_vector_full), .rob_retire_ready(retire_ready),
    .trap_valid, .trap_pc, .trap_cause, .trap_value, .trap_is_interrupt,
    .flush_speculative, .redirect_valid, .redirect_pc, .retired_count
  );

  mx64_csr_file csr (
    .clk, .rst_n, .csr_read_en, .csr_read_addr, .csr_read_data, .csr_read_legal,
    .csr_write_en, .csr_write_addr, .csr_write_data, .csr_write_legal,
    .current_privilege, .privilege_mode, .trap_valid, .trap_pc, .trap_cause,
    .trap_value, .trap_is_interrupt, .trap_vector(csr_trap_vector),
    .mret(1'b0), .mret_pc, .retired_count
  );

  initial begin
    repeat (2) @(negedge clk);
    rst_n=1;

    // Set direct-mode mtvec.
    csr_write_en=1; csr_write_addr=12'h305; csr_write_data=64'h8000;
    @(posedge clk); @(negedge clk); csr_write_en=0;

    // Allocate an older normal op followed by a decode-time illegal instruction.
    alloc_valid=2'b11;
    alloc_pc[0]=64'h1000; alloc_pc[1]=64'h1004;
    alloc_exception[1]=1;
    alloc_exception_code[1]=EXC_ILLEGAL;
    alloc_exception_value[1]=64'h0000_0000_0000_00ff;
    #1;
    if (alloc_ready !== 2'b11) $fatal(1,"ROB did not accept normal+exception pair");
    saved_tag0=alloc_tag[0];
    @(posedge clk); @(negedge clk);
    alloc_valid='0;
    alloc_exception='0;

    // Complete only the older instruction. The fault is already done at allocation.
    complete_valid[0]=1;
    complete_tag[0]=saved_tag0;
    @(posedge clk); @(negedge clk); complete_valid='0;
    #1;
    if (retire_valid !== 2'b11 || retire_exception !== 2'b10 ||
        retire_exception_code[1] != EXC_ILLEGAL || retire_exception_value[1] != 64'hff)
      $fatal(1,"ROB did not preserve allocation-time exception metadata");
    if (trap_valid || retire_ready !== 2'b01 || retired_count != 2'd1)
      $fatal(1,"younger fault must wait while older lane retires");

    // Once lane 0 retires, the fault is at the head and traps on this boundary.
    @(posedge clk); @(negedge clk);
    #1;
    if (!retire_valid[0] || !retire_exception[0] || !trap_valid ||
        trap_pc != 64'h1004 || trap_cause != 64'd2 || trap_value != 64'hff ||
        !flush_speculative || !redirect_valid || redirect_pc[47:0] != 48'h8000 ||
        retired_count != 2'd0)
      $fatal(1,"precise head trap/redirect outputs incorrect");
    @(posedge clk); @(negedge clk);

    // Trap CSR state must reflect the faulting instruction, with XLEN-wide mcause.
    csr_read_en=1; csr_read_addr=12'h341; #1;
    if (csr_read_data != 64'h1004) $fatal(1,"mepc mismatch");
    csr_read_addr=12'h342; #1;
    if (csr_read_data != 64'd2) $fatal(1,"mcause width/value mismatch");
    csr_read_addr=12'h343; #1;
    if (csr_read_data != 64'hff) $fatal(1,"mtval mismatch");
    csr_read_addr=12'hC02; #1;
    if (csr_read_data != 64'd1) $fatal(1,"minstret must count the older normal instruction, not the trap");

    $display("PASS: ROB-to-CSR precise exception directed test");
    $finish;
  end
endmodule
