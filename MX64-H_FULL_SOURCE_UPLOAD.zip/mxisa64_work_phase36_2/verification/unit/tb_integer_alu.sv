`timescale 1ns/1ps
module tb_integer_alu;
  import mx64_pkg::*;
  logic [63:0] a, b, result;
  logic [4:0] op;
  logic zero, signed_lt, unsigned_lt;

  integer_alu dut(.*);

  task automatic check(input logic [4:0] test_op,
                       input logic [63:0] lhs,
                       input logic [63:0] rhs,
                       input logic [63:0] expected);
    begin
      op = test_op; a = lhs; b = rhs; #1;
      if (result !== expected)
        $fatal(1, "ALU op=%0d a=%h b=%h got=%h expected=%h",
               test_op, lhs, rhs, result, expected);
    end
  endtask

  initial begin
    a='0; b='0; op=ALU_ADD; #1;
    check(ALU_ADD, 64'hffff_ffff_ffff_ffff, 64'd1, 64'd0);
    check(ALU_SUB, 64'd0, 64'd1, 64'hffff_ffff_ffff_ffff);
    check(ALU_AND, 64'hf0, 64'h3c, 64'h30);
    check(ALU_OR,  64'hf0, 64'h0f, 64'hff);
    check(ALU_XOR, 64'hff, 64'h0f, 64'hf0);
    check(ALU_NOT, 64'h0, 64'h0, 64'hffff_ffff_ffff_ffff);
    check(ALU_SLL, 64'd1, 64'd63, 64'h8000_0000_0000_0000);
    check(ALU_SRL, 64'h8000_0000_0000_0000, 64'd63, 64'd1);
    check(ALU_SRA, 64'h8000_0000_0000_0000, 64'd63, 64'hffff_ffff_ffff_ffff);
    check(ALU_SLT, 64'hffff_ffff_ffff_ffff, 64'd0, 64'd1);
    check(ALU_SLTU, 64'hffff_ffff_ffff_ffff, 64'd0, 64'd0);
    check(ALU_PASS, 64'h1234, 64'h5678, 64'h1234);
    $display("PASS: integer_alu directed tests");
    $finish;
  end
endmodule
