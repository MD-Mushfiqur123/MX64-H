`timescale 1ns/1ps
module tb_physical_regfile;
  localparam int DEPTH=8, TAG_W=3, RP=2, WP=2;
  logic clk=0, rst_n=0;
  logic [RP-1:0][TAG_W-1:0] raddr;
  logic [RP-1:0][63:0] rdata;
  logic [RP-1:0] rvalid;
  logic [WP-1:0] wen;
  logic [WP-1:0][TAG_W-1:0] waddr;
  logic [WP-1:0][63:0] wdata;

  always #5 clk=~clk;

  physical_regfile #(.DEPTH(DEPTH), .READ_PORTS(RP), .WRITE_PORTS(WP)) dut(.*);

  initial begin
    raddr='0; wen='0; waddr='0; wdata='0;
    repeat(2) @(posedge clk);
    rst_n <= 1;
    @(negedge clk);
    raddr[0]=3'd2;
    #1;
    if (rvalid[0] !== 1'b0) $fatal(1, "reset validity expected zero");
    wen[0]=1; waddr[0]=3'd2; wdata[0]=64'hfeed_beef_1234_5678;
    #1;
    if (rdata[0] !== 64'hfeed_beef_1234_5678 || !rvalid[0])
      $fatal(1, "write-through forwarding failed");
    @(posedge clk);
    @(negedge clk);
    wen='0; #1;
    if (rdata[0] !== 64'hfeed_beef_1234_5678 || !rvalid[0])
      $fatal(1, "stored read failed");

    // Collision contract: port 0 wins both before and after the clock edge.
    wen[0]=1; wen[1]=1;
    waddr[0]=3'd2; waddr[1]=3'd2;
    wdata[0]=64'h0000_0000_0000_a0a0;
    wdata[1]=64'h0000_0000_0000_b1b1;
    #1;
    if (rdata[0] !== 64'h0000_0000_0000_a0a0 || !rvalid[0])
      $fatal(1, "same-cycle collision forwarding priority failed");
    @(posedge clk);
    @(negedge clk);
    wen='0; #1;
    if (rdata[0] !== 64'h0000_0000_0000_a0a0 || !rvalid[0])
      $fatal(1, "stored collision priority disagrees with forwarding");

    $display("PASS: physical_regfile directed tests");
    $finish;
  end
endmodule
