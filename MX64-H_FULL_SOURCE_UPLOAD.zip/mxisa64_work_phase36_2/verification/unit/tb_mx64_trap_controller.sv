`timescale 1ns/1ps
module tb_mx64_trap_controller;
  import mx64_pkg::*;
  localparam int WIDTH=2;
  logic clk=0, rst_n=0;
  logic [WIDTH-1:0] retire_valid='0, retire_exception='0, normal_retire_ready='1;
  logic [WIDTH-1:0][63:0] retire_pc='0, retire_exception_value='0;
  logic [WIDTH-1:0][3:0] retire_exception_code='0;
  logic [1:0] current_privilege=2'b11, retired_count;
  logic [63:0] trap_vector=64'h8000;
  logic [WIDTH-1:0] rob_retire_ready;
  logic trap_valid, trap_is_interrupt, flush_speculative, redirect_valid;
  logic [63:0] trap_pc, trap_cause, trap_value, redirect_pc;

  logic csr_read_en=0, csr_write_en=0;
  logic [11:0] csr_read_addr='0, csr_write_addr='0;
  logic [63:0] csr_read_data, csr_write_data='0;
  logic csr_read_legal, csr_write_legal;
  logic [1:0] privilege_mode;
  logic [47:0] csr_trap_vector, mret_pc;

  always #5 clk=~clk;

  mx64_trap_controller #(.WIDTH(WIDTH)) dut (
    .clk, .rst_n, .retire_valid, .retire_exception, .retire_pc,
    .retire_exception_code, .retire_exception_value, .normal_retire_ready,
    .current_privilege, .trap_vector, .rob_retire_ready, .trap_valid,
    .trap_pc, .trap_cause, .trap_value, .trap_is_interrupt,
    .flush_speculative, .redirect_valid, .redirect_pc, .retired_count
  );

  mx64_csr_file csr (
    .clk, .rst_n, .csr_read_en, .csr_read_addr, .csr_read_data, .csr_read_legal,
    .csr_write_en, .csr_write_addr, .csr_write_data, .csr_write_legal,
    .current_privilege, .privilege_mode, .trap_valid, .trap_pc, .trap_cause,
    .trap_value, .trap_is_interrupt, .trap_vector(csr_trap_vector),
    .mret(1'b0), .mret_pc, .retired_count
  );

  initial begin
    repeat (2) @(negedge clk);
    rst_n=1;

    // Configure a direct-mode trap vector in the CSR file.
    csr_write_en=1; csr_write_addr=12'h305; csr_write_data=64'h0000_0000_0000_8000;
    @(posedge clk); @(negedge clk); csr_write_en=0;
    trap_vector={16'd0, csr_trap_vector};

    // A lane-1 fault may not retire beside the older normal lane-0 instruction.
    retire_valid=2'b11;
    retire_exception=2'b10;
    retire_pc[0]=64'h1000; retire_pc[1]=64'h1004;
    retire_exception_code[1]=EXC_ILLEGAL;
    retire_exception_value[1]=64'h0000_0000_0000_00ff;
    #1;
    if (trap_valid || rob_retire_ready !== 2'b01 || retired_count != 2'd1)
      $fatal(1,"lane-1 fault must wait; older lane-0 instruction retires first");
    @(posedge clk); @(negedge clk);

    // The fault is now at the ROB head and is taken precisely.
    retire_valid=2'b01;
    retire_exception=2'b01;
    retire_pc[0]=64'h1004;
    retire_exception_code[0]=EXC_ILLEGAL;
    retire_exception_value[0]=64'h0000_0000_0000_00ff;
    #1;
    if (!trap_valid || !flush_speculative || !redirect_valid ||
        rob_retire_ready !== 2'b01 || trap_pc != 64'h1004 ||
        trap_cause != 64'd2 || trap_value != 64'hff || retired_count != 2'd0)
      $fatal(1,"head exception trap outputs are not precise");
    if (redirect_pc[47:0] != 48'h8000)
      $fatal(1,"redirect did not use mtvec output");
    @(posedge clk); @(negedge clk);

    // Verify CSR capture, including mcause width and mepc alignment.
    csr_read_en=1; csr_read_addr=12'h341; #1;
    if (csr_read_data != 64'h1004) $fatal(1,"mepc did not capture faulting PC");
    csr_read_addr=12'h342; #1;
    if (csr_read_data != 64'd2) $fatal(1,"mcause was not encoded at XLEN width");
    csr_read_addr=12'h343; #1;
    if (csr_read_data != 64'hff) $fatal(1,"mtval did not capture exception metadata");
    csr_read_en=0;

    // ECALL cause is privilege-dependent in the two-level profile.
    current_privilege=2'b00;
    retire_exception_code[0]=EXC_ECALL;
    #1; if (trap_cause != 64'd8) $fatal(1,"U-mode ECALL cause must be 8");
    current_privilege=2'b11;
    #1; if (trap_cause != 64'd11) $fatal(1,"M-mode ECALL cause must be 11");

    // An unsupported exception enum must stall rather than be consumed.
    retire_exception_code[0]=4'hf;
    #1;
    if (trap_valid || rob_retire_ready[0])
      $fatal(1,"unknown exception enum must remain held at the ROB head");

    $display("PASS: MX64 precise trap controller/CSR directed test");
    $finish;
  end
endmodule
