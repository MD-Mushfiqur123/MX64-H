`timescale 1ns/1ps
module tb_rob_selective_recovery;
  localparam int DEPTH=8, WIDTH=2, TAGW=3, GENW=16, FULLW=19;
  logic clk=0, rst_n=0, flush=0;
  logic tag_query_valid=0, tag_query_found;
  logic [FULLW-1:0] tag_query_tag='0;
  logic recover_valid=0, recover_found;
  logic [FULLW-1:0] recover_tag='0;
  logic [WIDTH-1:0] alloc_valid, alloc_ready;
  logic [WIDTH-1:0][FULLW-1:0] alloc_tag;
  logic [WIDTH-1:0][63:0] alloc_pc;
  logic [WIDTH-1:0][4:0] alloc_rd;
  logic [WIDTH-1:0][6:0] alloc_kind, alloc_prd, alloc_old_prd;
  logic [WIDTH-1:0] alloc_exception='0;
  logic [WIDTH-1:0][3:0] alloc_exception_code='0;
  logic [WIDTH-1:0][63:0] alloc_exception_value='0;
  logic [WIDTH-1:0] complete_valid='0, complete_exception='0;
  logic [WIDTH-1:0][FULLW-1:0] complete_tag='0;
  logic [WIDTH-1:0][63:0] complete_value='0;
  logic [WIDTH-1:0][3:0] complete_exception_code='0;
  logic [WIDTH-1:0][63:0] complete_exception_value='0;
  logic [WIDTH-1:0] retire_valid, retire_ready='0, retire_exception;
  logic [WIDTH-1:0][FULLW-1:0] retire_tag;
  logic [WIDTH-1:0][63:0] retire_pc, retire_value;
  logic [WIDTH-1:0][4:0] retire_rd;
  logic [WIDTH-1:0][6:0] retire_kind, retire_prd, retire_old_prd;
  logic [WIDTH-1:0][3:0] retire_exception_code;
  logic [WIDTH-1:0][63:0] retire_exception_value;
  logic full, empty;
  logic [$clog2(DEPTH+1)-1:0] occupancy;
  logic [FULLW-1:0] saved_tags [0:3];
  always #5 clk=~clk;

  reorder_buffer #(.DEPTH(DEPTH), .WIDTH(WIDTH), .TAG_W(TAGW),
    .GEN_W(GENW), .FULL_TAG_W(FULLW)) dut (.*);

  initial begin
    alloc_valid=2'b11; alloc_pc='0; alloc_rd='0; alloc_kind='0;
    alloc_prd='0; alloc_old_prd='0;
    repeat (2) @(posedge clk); rst_n=1;
    #1; saved_tags[0]=alloc_tag[0]; saved_tags[1]=alloc_tag[1];
    @(posedge clk); @(negedge clk);
    alloc_valid=2'b11; #1;
    saved_tags[2]=alloc_tag[0]; saved_tags[3]=alloc_tag[1];
    @(posedge clk); @(negedge clk); alloc_valid='0;

    tag_query_valid=1; tag_query_tag=saved_tags[3]; #1;
    if (!tag_query_found) $fatal(1,"younger ROB tag should be live before recovery");
    recover_valid=1; recover_tag=saved_tags[2]; #1;
    if (!recover_found) $fatal(1,"recovery branch tag lookup failed");
    @(posedge clk); @(negedge clk);
    recover_valid=0;
    if (occupancy != 3) $fatal(1,"ROB must retain older entries and branch only");
    #1; if (tag_query_found) $fatal(1,"younger ROB entry survived selective recovery");
    tag_query_valid=0;
    $display("PASS: selective ROB recovery directed test");
    $finish;
  end
endmodule
