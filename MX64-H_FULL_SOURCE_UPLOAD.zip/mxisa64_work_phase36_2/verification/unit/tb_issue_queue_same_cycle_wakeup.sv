`timescale 1ns/1ps
module tb_issue_queue_same_cycle_wakeup;
  localparam int DEPTH=8, WIDTH=2, PHYS_W=7, ROBW=mx64_pkg::ROB_TAG_W;
  logic clk=0, rst_n=0, flush=0, recover_valid=0;
  logic [31:0] recover_seq='0;
  logic [WIDTH-1:0] enq_valid='0, enq_ready, wakeup_valid='0;
  logic [WIDTH-1:0][PHYS_W-1:0] wakeup_tag='0;
  logic [WIDTH-1:0][63:0] wakeup_data='0;
  mx64_pkg::issue_uop_t enq_uop [0:WIDTH-1];
  logic [WIDTH-1:0] issue_valid, issue_ready='0;
  mx64_pkg::issue_uop_t issue_uop [0:WIDTH-1];
  logic [2*WIDTH-1:0] ref_acquire_valid;
  logic [2*WIDTH-1:0][PHYS_W-1:0] ref_acquire_tag;
  logic [2*DEPTH-1:0] ref_release_valid;
  logic [2*DEPTH-1:0][PHYS_W-1:0] ref_release_tag;
  logic [$clog2(DEPTH+1)-1:0] occupancy;
  logic full, empty;
  always #5 clk=~clk;

  issue_queue #(.DEPTH(DEPTH), .WIDTH(WIDTH), .WAKEUP_WIDTH(WIDTH),
    .PHYS_W(PHYS_W), .ROB_TAG_W(ROBW)) dut (.*);

  initial begin
    enq_uop[0]='0; enq_uop[1]='0;
    repeat (2) @(negedge clk); rst_n=1;

    // Both source operands wake in the same cycle as lane-0 enqueue.
    @(negedge clk);
    enq_valid=2'b01;
    enq_uop[0].valid=1; enq_uop[0].seq_num=32'd1;
    enq_uop[0].src1_ready=0; enq_uop[0].src1_tag=7'd12;
    enq_uop[0].src2_ready=0; enq_uop[0].src2_tag=7'd13;
    wakeup_valid=2'b11;
    wakeup_tag[0]=7'd12; wakeup_data[0]=64'h1111;
    wakeup_tag[1]=7'd13; wakeup_data[1]=64'h2222;
    #1;
    if (ref_acquire_valid != '0)
      $fatal(1,"already-woken enqueue operands must not acquire references");
    @(negedge clk); enq_valid=0; wakeup_valid=0;
    if (occupancy != 1) $fatal(1,"enqueued entry missing");

    issue_ready=2'b01; #1;
    if (!issue_valid[0] || !issue_uop[0].src1_ready || !issue_uop[0].src2_ready ||
        issue_uop[0].src1_value != 64'h1111 || issue_uop[0].src2_value != 64'h2222)
      $fatal(1,"same-cycle wakeup values/readiness were not captured at enqueue");
    if (ref_release_valid != '0)
      $fatal(1,"no references should have been acquired for operands already ready at enqueue");
    @(negedge clk);
    $display("PASS: issue queue captures two same-cycle wakeups at enqueue");
    $finish;
  end
endmodule
