`timescale 1ns/1ps
module tb_branch_checkpoint_manager;
  localparam int ARCH=32, PHYS=80, PW=7, N=4, IDW=2, ROBW=22;
  logic clk=0, rst_n=0, flush_all=0;
  logic capture_valid, capture_ready;
  logic [IDW-1:0] capture_id;
  logic [ROBW-1:0] capture_rob_tag, resolve_rob_tag, recover_rob_tag;
  logic [31:0] capture_seq, recover_seq;
  logic [ARCH-1:0][PW-1:0] capture_rat, restore_rat;
  logic [PHYS-1:0] capture_free_bitmap, restore_free_bitmap;
  logic [1:0] commit_free_valid=0;
  logic [1:0][PW-1:0] commit_free_tag='0;
  logic resolve_valid, resolve_mispredict, resolve_tag_live, resolve_found;
  logic recover_valid;
  logic [$clog2(N+1)-1:0] checkpoint_count;

  always #5 clk = ~clk;
  branch_checkpoint_manager #(.ARCH_REGS(ARCH), .PHYS_REGS(PHYS),
    .PHYS_W(PW), .ROB_TAG_W(ROBW), .NUM_CHECKPOINTS(N), .ID_W(IDW)) dut (.*);

  initial begin
    capture_valid=0; capture_rob_tag='0; capture_seq='0;
    capture_rat='0; capture_free_bitmap='0;
    resolve_valid=0; resolve_rob_tag='0; resolve_mispredict=0; resolve_tag_live=0;
    repeat (2) @(posedge clk); rst_n=1;

    // Capture two nested unresolved branches.
    @(negedge clk);
    capture_valid=1; capture_rob_tag=22'h000101; capture_seq=32'd10;
    capture_rat[3]=7'd41; capture_free_bitmap[41]=1;
    #1; if (!capture_ready || capture_id != 0) $fatal(1,"first checkpoint allocation");
    @(posedge clk); @(negedge clk);
    capture_rob_tag=22'h000202; capture_seq=32'd20;
    capture_rat[3]=7'd42; capture_free_bitmap[41]=0; capture_free_bitmap[42]=1;
    #1; if (!capture_ready || capture_id != 1) $fatal(1,"second checkpoint allocation");
    @(posedge clk); @(negedge clk); capture_valid=0;

    // A matching tag must not resolve a checkpoint without a valid handshake.
    resolve_valid=0; resolve_tag_live=1; resolve_rob_tag=22'h000101;
    #1; if (!resolve_found || recover_valid) $fatal(1,"resolve fired without valid");
    @(posedge clk); @(negedge clk); resolve_tag_live=0;
    if (checkpoint_count != 2) $fatal(1,"checkpoint changed without resolve_valid");

    // A later commit of an older instruction must be merged into every live
    // checkpoint's free bitmap, even though the branch snapshot is older.
    commit_free_valid[0]=1; commit_free_tag[0]=7'd43;
    @(posedge clk); @(negedge clk); commit_free_valid='0;

    // A correctly predicted older branch releases only itself.
    resolve_valid=1; resolve_tag_live=1; resolve_rob_tag=22'h000101; resolve_mispredict=0;
    #1; if (!resolve_found || recover_valid) $fatal(1,"correct resolution handshake");
    @(posedge clk); @(negedge clk); resolve_valid=0; resolve_tag_live=0;
    if (checkpoint_count != 1) $fatal(1,"correct resolution did not preserve younger checkpoint");

    // A later misprediction restores its own snapshot and discards itself.
    resolve_valid=1; resolve_tag_live=1; resolve_rob_tag=22'h000202; resolve_mispredict=1;
    #1; if (!recover_valid || recover_seq != 32'd20 || restore_rat[3] != 7'd42 ||
        !restore_free_bitmap[42] || !restore_free_bitmap[43])
      $fatal(1,"tagged checkpoint restore mismatch or committed-free merge");
    @(posedge clk); @(negedge clk); resolve_valid=0; resolve_tag_live=0;
    if (checkpoint_count != 0) $fatal(1,"recovered checkpoint was not released");

    $display("PASS: tagged branch checkpoint lifecycle directed test");
    $finish;
  end
endmodule
