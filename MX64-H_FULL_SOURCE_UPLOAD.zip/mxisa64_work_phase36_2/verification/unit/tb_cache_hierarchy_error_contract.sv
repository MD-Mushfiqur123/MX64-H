`timescale 1ns/1ps
module tb_cache_hierarchy_error_contract;
  localparam int PADDR_W=16, LINE_BYTES=16, SETS=2, DATA_W=64;
  logic clk=0, rst_n=0;
  logic req_valid=0, req_ready, req_write=0;
  logic [PADDR_W-1:0] req_addr='0;
  logic [DATA_W-1:0] req_wdata='0;
  logic [DATA_W/8-1:0] req_byte_enable='1;
  logic rsp_valid, rsp_ready=0, rsp_error;
  logic [DATA_W-1:0] rsp_rdata;
  logic mem_req_valid, mem_req_ready=0, mem_req_write;
  logic [PADDR_W-1:0] mem_req_addr;
  logic [LINE_BYTES*8-1:0] mem_req_wdata;
  logic [LINE_BYTES-1:0] mem_req_wstrb;
  logic mem_rsp_valid=0, mem_rsp_ready, mem_rsp_error=0;
  logic [LINE_BYTES*8-1:0] mem_rsp_rdata='0;
  logic invalidate_all=0;
  always #5 clk=~clk;

  cache_hierarchy #(.PADDR_W(PADDR_W), .LINE_BYTES(LINE_BYTES), .SETS(SETS), .DATA_W(DATA_W)) dut (.*);

  task automatic accept_request(input logic [PADDR_W-1:0] address, input logic is_write);
    @(negedge clk); req_addr=address; req_write=is_write; req_valid=1;
    do @(posedge clk); while (!req_ready);
    @(negedge clk); req_valid=0;
  endtask

  initial begin
    repeat (2) @(negedge clk); rst_n=1;

    // First miss installs line 0.
    accept_request(16'h0000, 1'b0);
    mem_req_ready=1;
    wait(mem_req_valid); @(posedge clk);
    @(negedge clk); mem_req_ready=0; mem_rsp_valid=1; mem_rsp_error=0;
    mem_rsp_rdata={2{64'h0123456789abcdef}};
    do @(posedge clk); while (!mem_rsp_ready);
    @(negedge clk); mem_rsp_valid=0;
    wait(rsp_valid); rsp_ready=1; @(posedge clk);
    @(negedge clk); rsp_ready=0;

    // Mark line dirty with a hit, then conflict at same set (address 0x20).
    accept_request(16'h0000, 1'b1);
    wait(rsp_valid); rsp_ready=1; @(posedge clk);
    @(negedge clk); rsp_ready=0;
    accept_request(16'h0020, 1'b0);
    wait(mem_req_valid && mem_req_write); mem_req_ready=1; @(posedge clk);
    @(negedge clk); mem_req_ready=0; mem_rsp_valid=1; mem_rsp_error=1;
    do @(posedge clk); while (!mem_rsp_ready);
    @(negedge clk); mem_rsp_valid=0;
    wait(rsp_valid); #1;
    if (!rsp_error) $fatal(1,"failed dirty-victim writeback must fail the pending demand request");
    if (dut.valid_q[0] !== 1'b1 || dut.dirty_q[0] !== 1'b1)
      $fatal(1,"failed writeback must preserve the dirty victim line");
    repeat (2) begin @(posedge clk); #1; if (!rsp_valid || !rsp_error) $fatal(1,"error response must remain stable under backpressure"); end
    rsp_ready=1; @(posedge clk);
    @(negedge clk); rsp_ready=0;
    $display("PASS: cache reports dirty-victim writeback failure and preserves victim");
    $finish;
  end
endmodule
