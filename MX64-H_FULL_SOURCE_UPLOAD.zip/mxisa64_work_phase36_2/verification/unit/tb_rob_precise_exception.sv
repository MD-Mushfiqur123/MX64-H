`timescale 1ns/1ps
module tb_rob_precise_exception;
  localparam int DEPTH=8, WIDTH=2, TAGW=3, GENW=16, FULLW=19;
  logic clk=0, rst_n=0, flush=0, tag_query_valid=0, tag_query_found;
  logic [FULLW-1:0] tag_query_tag='0, recover_tag='0;
  logic recover_valid=0, recover_found;
  logic [WIDTH-1:0] alloc_valid, alloc_ready;
  logic [WIDTH-1:0][FULLW-1:0] alloc_tag;
  logic [WIDTH-1:0][63:0] alloc_pc;
  logic [WIDTH-1:0][4:0] alloc_rd;
  logic [WIDTH-1:0][6:0] alloc_kind, alloc_prd, alloc_old_prd;
  logic [WIDTH-1:0] alloc_exception='0;
  logic [WIDTH-1:0][3:0] alloc_exception_code='0;
  logic [WIDTH-1:0][63:0] alloc_exception_value='0;
  logic [WIDTH-1:0] complete_valid, complete_exception;
  logic [WIDTH-1:0][FULLW-1:0] complete_tag;
  logic [WIDTH-1:0][63:0] complete_value;
  logic [WIDTH-1:0][3:0] complete_exception_code='0;
  logic [WIDTH-1:0][63:0] complete_exception_value='0;
  logic [WIDTH-1:0] retire_valid, retire_ready, retire_exception;
  logic [WIDTH-1:0][FULLW-1:0] retire_tag;
  logic [WIDTH-1:0][63:0] retire_pc, retire_value;
  logic [WIDTH-1:0][4:0] retire_rd;
  logic [WIDTH-1:0][6:0] retire_kind, retire_prd, retire_old_prd;
  logic [WIDTH-1:0][3:0] retire_exception_code;
  logic [WIDTH-1:0][63:0] retire_exception_value;
  logic full, empty;
  logic [WIDTH-1:0][FULLW-1:0] saved_tags;
  logic [$clog2(DEPTH+1)-1:0] occupancy;
  always #5 clk=~clk;

  reorder_buffer #(.DEPTH(DEPTH), .WIDTH(WIDTH), .TAG_W(TAGW),
    .GEN_W(GENW), .FULL_TAG_W(FULLW)) dut (
    .clk, .rst_n, .flush, .tag_query_valid, .tag_query_tag, .tag_query_found,
    .recover_valid, .recover_tag, .recover_found,
    .alloc_valid, .alloc_ready, .alloc_tag, .alloc_pc, .alloc_rd, .alloc_kind,
    .alloc_prd, .alloc_old_prd, .alloc_exception, .alloc_exception_code,
    .alloc_exception_value, .complete_valid, .complete_tag, .complete_value,
    .complete_exception, .complete_exception_code, .complete_exception_value,
    .retire_valid, .retire_ready, .retire_tag, .retire_pc,
    .retire_rd, .retire_kind, .retire_prd, .retire_old_prd, .retire_value,
    .retire_exception, .retire_exception_code, .retire_exception_value,
    .full, .empty, .occupancy);

  initial begin
    alloc_valid=2'b11; alloc_pc='0; alloc_rd='0; alloc_kind='0;
    alloc_prd='0; alloc_old_prd='0; complete_valid='0;
    complete_tag='0; complete_value='0; complete_exception='0;
    complete_exception_code='0; complete_exception_value='0;
    retire_ready=2'b11;
    repeat (2) @(posedge clk); rst_n=1;
    #1; saved_tags=alloc_tag;
    @(posedge clk); @(negedge clk);
    alloc_valid='0; complete_valid=2'b11;
    complete_tag=saved_tags;
    complete_exception=2'b01; // oldest entry faults; younger entry is normal
    complete_exception_code[0]=4'd1; // EXC_ILLEGAL
    complete_exception_value[0]=64'h0000_0000_0000_00ff;
    @(posedge clk); @(negedge clk); complete_valid='0;
    #1;
    if (retire_valid !== 2'b01 || retire_exception[0] !== 1'b1 ||
        retire_exception_code[0] !== 4'd1 || retire_exception_value[0] !== 64'hff)
      $fatal(1,"faulting head metadata/retirement boundary mismatch");
    $display("PASS: precise exception retirement directed test");
    $finish;
  end
endmodule
