`timescale 1ns/1ps
module tb_rename_commit_map;
  localparam int ARCH_REGS=32, PHYS_REGS=40, WIDTH=2;
  localparam int ARCH_W=$clog2(ARCH_REGS), PHYS_W=$clog2(PHYS_REGS);
  logic clk=0, rst_n=0, flush=0;
  always #5 clk=~clk;

  logic [ARCH_REGS-1:0][PHYS_W-1:0] restore_rat;
  logic [PHYS_REGS-1:0] restore_free_bitmap;
  logic [WIDTH-1:0] in_valid, in_ready, out_valid, out_ready, in_writes_rd;
  logic [WIDTH-1:0][ARCH_W-1:0] in_rs1, in_rs2, in_rd;
  logic [WIDTH-1:0][PHYS_W-1:0] out_prs1, out_prs2, out_prd, out_old_prd;
  logic [WIDTH-1:0] commit_free_valid, commit_map_valid;
  logic [WIDTH-1:0][PHYS_W-1:0] commit_free_tag, commit_map_new_prd;
  logic [WIDTH-1:0][ARCH_W-1:0] commit_map_arch_rd;
  logic [ARCH_REGS-1:0][PHYS_W-1:0] rat_debug, committed_rat_debug;
  logic [PHYS_REGS-1:0] free_debug, committed_free_bitmap_debug;

  rename_unit #(.ARCH_REGS(ARCH_REGS), .PHYS_REGS(PHYS_REGS), .WIDTH(WIDTH)) dut (
    .clk, .rst_n, .flush, .recover(1'b0), .restore_rat, .restore_free_bitmap,
    .in_valid, .in_ready, .in_rs1, .in_rs2, .in_rd, .in_writes_rd,
    .out_valid, .out_ready, .out_prs1, .out_prs2, .out_prd, .out_old_prd,
    .out_rat_snapshot(), .out_free_snapshot(),
    .commit_free_valid, .commit_free_tag,
    .commit_map_valid, .commit_map_arch_rd, .commit_map_new_prd,
    .rat_debug, .committed_rat_debug, .free_debug, .committed_free_bitmap_debug
  );

  initial begin
    restore_rat='0;
    restore_free_bitmap='0;
    in_valid='0; in_rs1='0; in_rs2='0; in_rd='0; in_writes_rd='0;
    out_ready='0; commit_free_valid='0; commit_free_tag='0;
    commit_map_valid='0; commit_map_arch_rd='0; commit_map_new_prd='0;
    repeat (2) @(negedge clk);
    rst_n=1;
    #1;
    if (rat_debug[0] !== '0 || committed_rat_debug[0] !== '0)
      $fatal(1, "x0 mapping must remain physical zero");
    if (committed_free_bitmap_debug[5] !== 1'b0)
      $fatal(1, "initial committed mapping must not appear free");

    // A committed destination write updates the committed map, not the
    // speculative map. The displaced initial mapping p5 becomes reclaimable.
    commit_map_valid[0]=1;
    commit_map_arch_rd[0]=5;
    commit_map_new_prd[0]=6'd33;
    commit_free_valid[0]=1;
    commit_free_tag[0]=6'd5;
    @(posedge clk);
    @(negedge clk);
    commit_map_valid='0; commit_free_valid='0;
    if (committed_rat_debug[5] !== 6'd33)
      $fatal(1, "committed RAT did not accept retirement mapping");
    if (rat_debug[5] !== 6'd5)
      $fatal(1, "commit must not mutate speculative RAT");
    if (!free_debug[5])
      $fatal(1, "old physical mapping was not freed");
    if (!committed_free_bitmap_debug[5] || committed_free_bitmap_debug[33])
      $fatal(1, "committed free bitmap does not match the committed RAT");

    // The freed initial mapping is eligible for subsequent allocation.
    in_valid[0]=1;
    in_rd[0]=6;
    in_writes_rd[0]=1;
    out_ready[0]=1;
    #1;
    if (!out_valid[0] || out_prd[0] !== 6'd5 || out_old_prd[0] !== 6'd6)
      $fatal(1, "freed initial mapping was not reallocated oldest-first");
    @(posedge clk);
    @(negedge clk);
    in_valid='0; in_writes_rd='0; out_ready='0;
    if (rat_debug[6] !== 6'd5)
      $fatal(1, "speculative RAT did not install reclaimed physical tag");

    // A non-writing operation must not update the committed RAT. The
    // dispatch controller is responsible for masking commit_map_valid.
    commit_map_valid[0]=0;
    commit_map_arch_rd[0]=5;
    commit_map_new_prd[0]=6'd34;
    @(posedge clk);
    @(negedge clk);
    if (committed_rat_debug[5] !== 6'd33)
      $fatal(1, "inactive commit lane changed committed RAT");

    $display("PASS: rename committed-map directed tests");
    $finish;
  end
endmodule
