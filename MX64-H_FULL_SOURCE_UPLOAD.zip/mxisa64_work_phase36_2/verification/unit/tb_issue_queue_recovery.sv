`timescale 1ns/1ps
module tb_issue_queue_recovery;
  localparam int DEPTH=8, WIDTH=2, PHYS_W=7, ROBW=mx64_pkg::ROB_TAG_W;
  logic clk=0, rst_n=0, flush=0, recover_valid=0;
  logic [31:0] recover_seq='0;
  logic [WIDTH-1:0] enq_valid, enq_ready, wakeup_valid='0;
  logic [WIDTH-1:0][PHYS_W-1:0] wakeup_tag='0;
  logic [WIDTH-1:0][63:0] wakeup_data='0;
  mx64_pkg::issue_uop_t enq_uop [0:WIDTH-1];
  logic [WIDTH-1:0] issue_valid, issue_ready;
  mx64_pkg::issue_uop_t issue_uop [0:WIDTH-1];
  logic [$clog2(DEPTH+1)-1:0] occupancy;
  logic full, empty;
  always #5 clk=~clk;

  issue_queue #(.DEPTH(DEPTH), .WIDTH(WIDTH), .PHYS_W(PHYS_W), .ROB_TAG_W(ROBW)) dut (.*);

  initial begin
    enq_valid=0; issue_ready=0;
    enq_uop[0]='0; enq_uop[1]='0;
    repeat (2) @(posedge clk); rst_n=1;

    @(negedge clk);
    enq_valid=2'b11;
    enq_uop[0].seq_num=32'd10; enq_uop[0].src1_ready=1; enq_uop[0].src2_ready=1;
    enq_uop[1].seq_num=32'd20; enq_uop[1].src1_ready=1; enq_uop[1].src2_ready=1;
    @(posedge clk); @(negedge clk);
    enq_valid=2'b01;
    enq_uop[0].seq_num=32'd30; enq_uop[0].src1_ready=1; enq_uop[0].src2_ready=1;
    @(posedge clk); @(negedge clk); enq_valid=0;
    if (occupancy != 3) $fatal(1,"three entries expected before recovery");

    recover_valid=1; recover_seq=32'd20;
    @(posedge clk); @(negedge clk); recover_valid=0;
    if (occupancy != 2) $fatal(1,"recovery must remove only younger queue entries");
    issue_ready=2'b11; #1;
    if (issue_valid != 2'b11 || issue_uop[0].seq_num != 32'd10 ||
        issue_uop[1].seq_num != 32'd20)
      $fatal(1,"older queued entries were not preserved in age order");
    // A trap/flush must suppress issue combinationally in the same cycle,
    // not merely clear queue state at the active edge.
    flush=1; #1;
    if (issue_valid != '0 || enq_ready != '0)
      $fatal(1,"flush must immediately suppress issue and enqueue handshakes");
    @(posedge clk); @(negedge clk); flush=0;
    if (occupancy != 0) $fatal(1,"flush did not clear all issue queue entries");
    $display("PASS: issue queue selective recovery and flush gating directed test");
    $finish;
  end
endmodule
