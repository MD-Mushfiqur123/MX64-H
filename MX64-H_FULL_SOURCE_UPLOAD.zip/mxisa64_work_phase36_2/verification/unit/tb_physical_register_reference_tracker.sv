`timescale 1ns/1ps
module tb_physical_register_reference_tracker;
  localparam int N=16, TAG_W=4, CW=4;
  logic clk=0, rst_n=0, clear_all=0;
  logic [1:0] acquire_valid=0, release_valid=0;
  logic [1:0][TAG_W-1:0] acquire_tag='0, release_tag='0;
  logic [N-1:0] referenced_bitmap, reclaim_bitmap;
  logic [N-1:0][CW-1:0] reference_count;
  always #5 clk=~clk;

  physical_register_reference_tracker #(
    .PHYS_REGS(N), .TAG_W(TAG_W), .COUNT_W(CW), .INIT_ARCH_REGS(8),
    .ACQUIRE_WIDTH(2), .RELEASE_WIDTH(2)
  ) dut (.*);

  initial begin
    repeat (2) @(negedge clk); rst_n=1;
    #1;
    if (reference_count[1] != 1 || reference_count[7] != 1 || reference_count[8] != 0)
      $fatal(1,"reset must establish identity-map ownership for architectural registers only");

    @(negedge clk); acquire_valid=2'b01; acquire_tag[0]=4'd9;
    @(negedge clk); acquire_valid=0;
    if (reference_count[9] != 1) $fatal(1,"acquire failed");

    // clear_all restores the identity-map baseline and must not expose p1..p7
    // as reclaimable due to a combinational pre-clear zero transition.
    clear_all=1; #1;
    if (reclaim_bitmap != '0) $fatal(1,"reclaim must be suppressed during clear_all");
    @(negedge clk); clear_all=0;
    if (reference_count[1] != 1 || reference_count[7] != 1 || reference_count[9] != 0)
      $fatal(1,"clear_all did not restore architectural references and clear speculative references");

    // Same-cycle acquire/release netting on a non-architectural tag.
    acquire_valid=1; acquire_tag[0]=4'd10;
    @(negedge clk); acquire_valid=0; release_valid=1; release_tag[0]=4'd10;
    #1;
    if (!reclaim_bitmap[10]) $fatal(1,"nonzero-to-zero transition must pulse reclaim");
    @(negedge clk); release_valid=0;
    if (reference_count[10] != 0) $fatal(1,"release did not drain reference");
    $display("PASS: reference tracker reset, clear_all preservation, and reclaim directed test");
    $finish;
  end
endmodule
