# Unit test entry points

The directed SystemVerilog testbenches in this directory are initial test vectors, not a complete verification suite.

Example with a simulator that supports the required SystemVerilog features:

```bash
iverilog -g2012 -s tb_integer_alu -o build/tb_alu \
  rtl/common/mx64_pkg.sv rtl/execution/integer_alu.sv \
  verification/unit/tb_integer_alu.sv
vvp build/tb_alu
```

The physical register file test uses unpacked arrays and packed multidimensional ports; confirm simulator support or use Verilator. A passing directed test is not a substitute for formal and randomized verification.

Phase 17 adds `tb_mx64_trap_controller.sv` for the trap controller and
`tb_mx64_precise_exception.sv` for ROB-to-CSR precise exception flow. The
`tb_issue_queue_recovery.sv` test also checks that a full flush suppresses issue
and enqueue combinationally. These testbenches remain unexecuted until the final
HDL verification stage, consistent with the project phase policy.
