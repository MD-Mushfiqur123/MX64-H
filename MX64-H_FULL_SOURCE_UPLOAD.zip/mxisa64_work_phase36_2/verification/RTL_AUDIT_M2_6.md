# M2.6 physical register file collision-priority audit

## Finding

The physical register file sequential write loop applied port 0 last, so port 0
won when both write ports targeted the same physical register. Its combinational
write-to-read bypass loop originally iterated in ascending order, making the
highest-numbered write port win in the same collision. A read in the collision
cycle could therefore observe a different value from the value stored after the
clock edge.

## Correction

- The bypass loop now iterates from `WRITE_PORTS-1` down to zero, so port 0 is
  assigned last and matches sequential storage priority.
- The directed SystemVerilog testbench exercises same-address dual-write
  collision both before and after the active edge.
- The static RTL source checker asserts that the priority direction and policy
  remain aligned.

## Verification boundary

The testbench is authored but not executed. Python static checks confirm source
structure only. HDL compilation, simulation, formal verification and synthesis
remain deferred to the final verification stage.
