# Phase 37.1 Directed RTL Testbenches

The current environment did not have an HDL compiler/simulator, so these are authored testbenches, not executed test results. Use Verilator with timing/assertions enabled as the first local run.

## Memory issue queue

File order:
1. `rtl/common/mx64_pkg.sv`
2. `rtl/scheduler/mx64_memory_issue_queue.sv`
3. `verification/phase37_1/tb_mx64_memory_issue_queue.sv`

Example from repository root:

```sh
verilator --binary --timing --assert -Wall -Wno-fatal \
  --top-module tb_mx64_memory_issue_queue \
  rtl/common/mx64_pkg.sv \
  rtl/scheduler/mx64_memory_issue_queue.sv \
  verification/phase37_1/tb_mx64_memory_issue_queue.sv
./obj_dir/Vtb_mx64_memory_issue_queue
```

Scenarios: in-order oldest memory op, no bypass past an unresolved older op, tag wakeup, reference release on wakeup, same-cycle enqueue+wakeup, duplicate-tag wakeup collision with PRF port-0 priority, stalled payload stability, flush cleanup, and branch-recovery cleanup.

## ROB memory completion lane

File order:
1. `rtl/scheduler/reorder_buffer.sv`
2. `verification/phase37_1/tb_rob_memory_completion_lane.sv`

```sh
verilator --binary --timing --assert -Wall -Wno-fatal \
  --top-module tb_rob_memory_completion_lane \
  rtl/scheduler/reorder_buffer.sv \
  verification/phase37_1/tb_rob_memory_completion_lane.sv
./obj_dir/Vtb_rob_memory_completion_lane
```

This directly verifies the added completion lane at index `WIDTH+1`; it does not replace an integration test of the frontend/LSU adapter.
