`timescale 1ns/1ps
module tb_rob_memory_completion_lane;
  localparam int DEPTH=48, WIDTH=2, COMPLETE_WIDTH=WIDTH+2;
  localparam int TAG_W=6, GEN_W=16, FULL_TAG_W=TAG_W+GEN_W;
  logic clk=0, rst_n=0, flush=0;
  logic tag_query_valid=0, tag_query_found;
  logic [FULL_TAG_W-1:0] tag_query_tag='0;
  logic recover_valid=0, recover_found;
  logic [FULL_TAG_W-1:0] recover_tag='0;
  logic [WIDTH-1:0] alloc_valid='0, alloc_ready;
  logic [WIDTH-1:0][FULL_TAG_W-1:0] alloc_tag;
  logic [WIDTH-1:0][63:0] alloc_pc='0;
  logic [WIDTH-1:0][4:0] alloc_rd='0;
  logic [WIDTH-1:0][6:0] alloc_kind='0, alloc_prd='0, alloc_old_prd='0;
  logic [WIDTH-1:0] alloc_exception='0;
  logic [WIDTH-1:0][3:0] alloc_exception_code='0;
  logic [WIDTH-1:0][63:0] alloc_exception_value='0;
  logic [COMPLETE_WIDTH-1:0] complete_valid='0;
  logic [COMPLETE_WIDTH-1:0][FULL_TAG_W-1:0] complete_tag='0;
  logic [COMPLETE_WIDTH-1:0][63:0] complete_value='0;
  logic [COMPLETE_WIDTH-1:0] complete_exception='0;
  logic [COMPLETE_WIDTH-1:0][3:0] complete_exception_code='0;
  logic [COMPLETE_WIDTH-1:0][63:0] complete_exception_value='0;
  logic [WIDTH-1:0] retire_valid, retire_ready='1;
  logic [WIDTH-1:0][FULL_TAG_W-1:0] retire_tag;
  logic [WIDTH-1:0][63:0] retire_pc;
  logic [WIDTH-1:0][4:0] retire_rd;
  logic [WIDTH-1:0][6:0] retire_kind, retire_prd, retire_old_prd;
  logic [WIDTH-1:0][63:0] retire_value;
  logic [WIDTH-1:0] retire_exception;
  logic [WIDTH-1:0][3:0] retire_exception_code;
  logic [WIDTH-1:0][63:0] retire_exception_value;
  logic full, empty;
  logic [$clog2(DEPTH+1)-1:0] occupancy;
  logic [FULL_TAG_W-1:0] allocated_tag;

  always #5 clk=~clk;
  reorder_buffer #(.DEPTH(DEPTH), .WIDTH(WIDTH), .COMPLETE_WIDTH(COMPLETE_WIDTH),
    .TAG_W(TAG_W), .GEN_W(GEN_W), .FULL_TAG_W(FULL_TAG_W)) dut (.*);

  task automatic tick; @(posedge clk); #1; endtask
  initial begin
    tick(); rst_n=1; tick();
    alloc_valid=2'b01; alloc_rd[0]=5'd3; alloc_kind[0]=7'b0010100;
    alloc_prd[0]=7'd35; alloc_old_prd[0]=7'd3; alloc_pc[0]=64'h1000; #1;
    if (!alloc_ready[0]) $fatal(1,"ROB did not accept memory instruction");
    allocated_tag=alloc_tag[0];
    tick(); alloc_valid='0;
    // Lane WIDTH+1 is reserved for memory completion; WIDTH is branch.
    complete_valid[WIDTH+1]=1'b1;
    complete_tag[WIDTH+1]=allocated_tag;
    complete_value[WIDTH+1]=64'h55AA;
    tick(); complete_valid='0;
    #1;
    if (!retire_valid[0]) $fatal(1,"memory completion did not mark ROB entry done");
    if (retire_tag[0] !== allocated_tag) $fatal(1,"retired wrong ROB identity");
    if (retire_value[0] !== 64'h55AA) $fatal(1,"ROB did not retain memory completion value");
    tick();
    if (!empty) $fatal(1,"ROB did not retire memory-completed entry");
    $display("PASS: dedicated memory completion lane reaches ROB retirement");
    $finish;
  end
endmodule
