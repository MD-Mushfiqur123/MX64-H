`timescale 1ns/1ps
module tb_mx64_memory_issue_queue;
  import mx64_pkg::*;
  localparam int DEPTH=8, WIDTH=2, PHYS_W=7, WAKEUP_WIDTH=4;
  logic clk=0, rst_n=0, flush=0, recover_valid=0;
  logic [31:0] recover_seq=0;
  logic [WIDTH-1:0] enq_valid=0, enq_ready;
  issue_uop_t enq_uop[0:WIDTH-1];
  logic [WAKEUP_WIDTH-1:0] wakeup_valid=0;
  logic [WAKEUP_WIDTH-1:0][PHYS_W-1:0] wakeup_tag='0;
  logic [WAKEUP_WIDTH-1:0][63:0] wakeup_data='0;
  logic issue_valid, issue_ready=0;
  issue_uop_t issue_uop;
  logic [2*WIDTH-1:0] ref_acquire_valid;
  logic [2*WIDTH-1:0][PHYS_W-1:0] ref_acquire_tag;
  logic [2*DEPTH-1:0] ref_release_valid;
  logic [2*DEPTH-1:0][PHYS_W-1:0] ref_release_tag;
  logic [$clog2(DEPTH+1)-1:0] occupancy;

  always #5 clk=~clk;
  mx64_memory_issue_queue #(.DEPTH(DEPTH), .WIDTH(WIDTH), .WAKEUP_WIDTH(WAKEUP_WIDTH)) dut (.*);

  task automatic tick; @(posedge clk); #1; endtask
  task automatic clear_inputs;
    enq_valid='0; wakeup_valid='0; issue_ready=0; recover_valid=0; flush=0;
  endtask

  initial begin
    enq_uop[0]='0; enq_uop[1]='0;
    tick(); rst_n=1; tick();

    // Older memory op is unresolved; younger ready op must not bypass it.
    enq_uop[0]='0; enq_uop[0].valid=1; enq_uop[0].is_load=1;
    enq_uop[0].seq_num=32'd10; enq_uop[0].src1_tag=7'd5;
    enq_uop[0].src1_ready=0; enq_uop[0].src2_ready=1;
    enq_uop[1]='0; enq_uop[1].valid=1; enq_uop[1].is_store=1;
    enq_uop[1].seq_num=32'd11; enq_uop[1].src1_ready=1; enq_uop[1].src2_ready=1;
    enq_valid=2'b11; #1;
    if (enq_ready !== 2'b11) $fatal(1,"queue should accept two entries");
    if (!ref_acquire_valid[0] || ref_acquire_tag[0] != 7'd5)
      $fatal(1,"unresolved older source reference not acquired");
    tick(); enq_valid=0;
    #1;
    if (issue_valid !== 1'b0) $fatal(1,"younger ready memory op bypassed older unresolved op");

    // Wake oldest op; issue candidate must be oldest and stable under stall.
    wakeup_valid[0]=1; wakeup_tag[0]=7'd5; wakeup_data[0]=64'h1234;
    #1;
    if (!ref_release_valid[0] || ref_release_tag[0] != 7'd5)
      $fatal(1,"wakeup did not release the retained source reference");
    tick(); wakeup_valid='0;
    #1;
    if (!issue_valid || issue_uop.seq_num != 32'd10 || issue_uop.src1_value != 64'h1234)
      $fatal(1,"oldest memory op did not wake and issue");
    begin : p_stable
      issue_uop_t held;
      held=issue_uop;
      repeat (2) begin
        tick();
        if (!issue_valid || issue_uop !== held) $fatal(1,"issue payload changed under backpressure");
      end
    end
    issue_ready=1; tick(); issue_ready=0;
    #1;
    if (!issue_valid || issue_uop.seq_num != 32'd11) $fatal(1,"younger op not presented after older accepted");
    issue_ready=1; tick(); issue_ready=0;
    #1;
    if (issue_valid || occupancy != 0) $fatal(1,"memory queue did not drain");

    // Same-cycle enqueue + wakeup must capture the producer result.
    enq_uop[0]='0; enq_uop[0].valid=1; enq_uop[0].is_load=1;
    enq_uop[0].seq_num=32'd12; enq_uop[0].src1_tag=7'd9;
    enq_uop[0].src1_ready=0; enq_uop[0].src2_ready=1;
    enq_valid=2'b01; wakeup_valid[1]=1; wakeup_tag[1]=7'd9; wakeup_data[1]=64'hBEEF;
    #1;
    if (!enq_ready[0]) $fatal(1,"same-cycle wakeup enqueue was not accepted");
    if (ref_acquire_valid[0]) $fatal(1,"reference acquired for operand woken at enqueue");
    tick(); enq_valid=0; wakeup_valid='0;
    #1;
    if (!issue_valid || issue_uop.src1_value != 64'hBEEF) $fatal(1,"same-cycle enqueue wakeup was lost");
    issue_ready=1; tick(); clear_inputs();

    // Colliding wakeup lanes for one physical tag must use PRF port-0 priority.
    enq_uop[0]='0; enq_uop[0].valid=1; enq_uop[0].is_load=1;
    enq_uop[0].seq_num=32'd121; enq_uop[0].src1_tag=7'd13;
    enq_uop[0].src1_ready=0; enq_uop[0].src2_ready=1;
    enq_valid=2'b01; #1;
    if (!enq_ready[0] || !ref_acquire_valid[0]) $fatal(1,"collision test enqueue failed");
    tick(); enq_valid=0;
    wakeup_valid=4'b0011; wakeup_tag[0]=7'd13; wakeup_tag[1]=7'd13;
    wakeup_data[0]=64'h1111; wakeup_data[1]=64'h2222; #1;
    if (!issue_valid || issue_uop.src1_value != 64'h1111)
      $fatal(1,"memory wakeup priority differs from PRF port-0 priority");
    tick(); clear_inputs();

    // Flush releases any unresolved source retained by a queued memory op.
    enq_uop[0]='0; enq_uop[0].valid=1; enq_uop[0].is_load=1;
    enq_uop[0].seq_num=32'd13; enq_uop[0].src1_tag=7'd10;
    enq_uop[0].src1_ready=0; enq_uop[0].src2_ready=1;
    enq_valid=2'b01; #1;
    if (!enq_ready[0] || !ref_acquire_valid[0]) $fatal(1,"flush test enqueue/acquire failed");
    tick(); enq_valid=0;
    flush=1; #1;
    if (!ref_release_valid[0] || ref_release_tag[0] != 7'd10)
      $fatal(1,"flush did not release unresolved memory source");
    tick(); flush=0; #1;
    if (occupancy != 0) $fatal(1,"flush did not clear memory issue queue");

    // Branch recovery keeps the branch/older prefix and releases younger entries.
    enq_uop[0]='0; enq_uop[0].valid=1; enq_uop[0].is_load=1;
    enq_uop[0].seq_num=32'd20; enq_uop[0].src1_tag=7'd11;
    enq_uop[0].src1_ready=0; enq_uop[0].src2_ready=1;
    enq_uop[1]='0; enq_uop[1].valid=1; enq_uop[1].is_store=1;
    enq_uop[1].seq_num=32'd21; enq_uop[1].src1_tag=7'd12;
    enq_uop[1].src1_ready=0; enq_uop[1].src2_ready=1;
    enq_valid=2'b11; #1;
    if (enq_ready !== 2'b11) $fatal(1,"recovery test could not enqueue two memory ops");
    tick(); enq_valid=0;
    recover_valid=1; recover_seq=32'd20; #1;
    begin : p_check_recover_release
      logic found_younger_release;
      found_younger_release=1'b0;
      for (int r=0; r<2*DEPTH; r++)
        if (ref_release_valid[r] && ref_release_tag[r] == 7'd12)
          found_younger_release=1'b1;
      if (!found_younger_release) $fatal(1,"recovery did not release younger memory source");
    end
    tick(); recover_valid=0; #1;
    if (occupancy != 1) $fatal(1,"recovery did not preserve older memory operation");
    flush=1; #1; tick(); flush=0; #1;
    if (occupancy != 0) $fatal(1,"post-recovery cleanup failed");

    $display("PASS: memory issue ordering, wakeup, backpressure, recovery, flush and reference lifecycle");
    $finish;
  end
endmodule
