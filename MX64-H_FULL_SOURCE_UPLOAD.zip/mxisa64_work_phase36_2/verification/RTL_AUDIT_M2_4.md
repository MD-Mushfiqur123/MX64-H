# MX64 RTL audit — M2.4 package review

**Review level:** source inspection and repository-structure checks only. No HDL simulator, formal engine, or synthesis engine was available in the authoring environment, so this is not a compile or functional verification report.

## What is present

- 64-bit integer ALU and a directed testbench.
- Physical register file and free-list / rename building blocks.
- Integer issue queue and a two-lane integer execution slice.
- ROB and an integration draft connecting integer completion to retirement.
- A two-wide dispatch-controller draft.
- Architecture, ISA, memory/cache, PDK, verification, and Windows setup documentation.

## Important implementation gaps found during source review

1. **The PRF/busy-table path is not integrated.** The dispatch controller receives source readiness and source values as external inputs. There is no complete register-read, busy-table, bypass, or PRF writeback integration in the top-level datapath.
2. **Stale physical destination reclamation is not closed end-to-end.** `rename_unit` computes `out_old_prd`, but the dispatch controller does not expose it through the ROB/retirement interface. The free-list commit-free inputs are external. A complete implementation must carry the stale physical destination through the ROB and return it only when its owning instruction retires.
3. **Branch speculation recovery is incomplete.** Restore-map and restore-free-bitmap inputs exist, but branch checkpoint allocation, branch masks, misprediction detection, selective younger-uop squash, and precise recovery sequencing are not implemented end-to-end.
4. **Exception/interrupt handling is incomplete.** The integer backend currently drives completion exception low. The ROB has an exception bit, but trap CSRs, cause/value capture, architectural trap sequencing, and interrupt boundaries are not integrated.
5. **Execution support is intentionally limited.** The connected execution cluster is integer-ALU-only. Multiply/divide, branch resolution, load/store execution, LSU queues, memory ordering, TLB/MMU, and cache controllers are not implemented as a complete core.
6. **ROB generation protection is finite.** Phase 11 expands the current 48-entry profile to a 14-bit tag (6-bit slot index + 8-bit epoch), rejecting stale completions across 256 allocations per slot. This is still finite-width protection; flush must cancel old long-latency requests, and the final epoch/wrap contract needs verification.
7. **Top-level integration is incomplete.** `mx64_top.sv` is a shell and does not yet instantiate a fully operational fetch/decode/rename/execute/memory/commit processor.

## Design checks motivated by the references

- Rename must remove WAR/WAW name dependencies while preserving RAW data dependencies. For dual-wide rename, lane 1 must observe lane 0's mapping update when both are accepted in program order.
- ROB retirement must preserve program order even when completion is out of order. An exception may become architecturally visible only at the retirement head.
- Branch recovery needs a correct checkpoint/allocation-history strategy; restoring only a stale free-list bitmap can leak or double-allocate physical registers.
- Dispatch must reserve all required structures atomically, or provide a rollback protocol. A uop must never enter an issue queue without a corresponding live ROB entry.

## Current verification status

| Check | Status |
|---|---|
| Repository structure checker | PASS |
| ZIP archive integrity | PASS |
| Windows batch script static inspection | Reviewed; not executed on Windows |
| Icarus compile of ALU testbench | NOT RUN |
| ALU simulation | NOT RUN |
| Rename / free-list simulation | NOT RUN |
| Issue queue / ROB simulation | NOT RUN |
| Full-core simulation | NOT RUN |
| Formal properties | NOT RUN |
| Synthesis / timing / area | NOT RUN |
| PDK signoff / GDS | NOT RUN |

The next engineering gate should be to run the ALU test on the user's Windows machine, then add independent tests for free-list allocation under backpressure, dual-wide rename dependencies, issue wakeup/select, ROB wraparound and generation behavior, and atomic dispatch under simultaneous resource pressure.
