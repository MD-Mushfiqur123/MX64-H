// Bindable property template. Signal names must be connected to the final ROB.
module rob_properties #(
  parameter int DEPTH = 48
) (
  input logic clk,
  input logic rst_n,
  input logic [DEPTH-1:0] retire_valid
);
  // Example invariant: at most RETIRE_WIDTH entries may retire per cycle.
  // Replace/extend once final ROB interface is frozen.
  property p_reset_suppresses_retire;
    @(posedge clk) !rst_n |-> !(|retire_valid);
  endproperty
  assert property (p_reset_suppresses_retire);
endmodule
