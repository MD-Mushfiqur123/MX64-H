# M1.2 implementation status

Added initial RTL modules:
- `free_list.sv`: parameterized physical-register free bitmap allocator.
- `rename_unit.sv`: two-lane rename-map scaffold with lane-0-to-lane-1 dependency forwarding and externally supplied recovery snapshot.
- `reorder_buffer.sv`: two-wide allocation/completion/retirement scaffold with per-slot 16-bit epoch (22-bit full tag for the current 48-entry profile) to reject stale completion tags after flush/reuse.

## Known limitations requiring next review

These are initial implementation units, not verified production blocks.

1. The rename unit still requires HDL verification for simultaneous commit frees, allocation pressure, and recovery snapshot consistency.
2. The free-list implementation uses a simple combinational priority scan; timing/area optimization is not done.
3. The ROB is a first functional-structure draft. Simultaneous multi-port allocation/completion/retirement, generation handling, wraparound and count arithmetic require simulator and formal verification before integration.
4. Branch checkpoints must capture both RAT and free-list state at the correct speculation boundary. A branch flush must preserve older in-flight work; restoring the committed map blindly is not valid.
5. ROB tags include a 16-bit per-slot epoch in the current profile. It wraps after 65,536 allocations of the same slot; pre-flush long-latency requests must be canceled and wrap behavior must be verified.
6. The ROB/rename path now carries physical destination metadata and updates a committed RAT at normal retirement, but store-commit side effects, exception vectoring and full branch recovery remain unimplemented.
7. Python regression and static source checks pass. No SystemVerilog compiler, simulator or formal tool was available, so no HDL compile/simulation/formal pass is claimed.

## Next required tests

- Rename: x0, RAW/WAR/WAW, two-wide same-destination, free-list exhaustion, commit free, checkpoint restore.
- ROB: 0/1/2 allocations, 0/1/2 retirements, wraparound, full/empty, simultaneous alloc/retire, out-of-order completion, stale completion after flush, exception at head.
- Formal: occupancy bounds, unique live tags, in-order retirement, no stale completion acceptance, no duplicate physical allocation.


## Review corrections applied in repository snapshot

- Free-list bit polarity is now consistent: `1` means free, allocation clears the bit, and retirement free sets it.
- Dual-wide rename now gates the younger lane on the older lane's handshake and updates the speculative RAT only on accepted transfers.
- ROB allocation tag returns the next generation value, and lane 1 allocation is restricted to a contiguous prefix.
- ROB count delta expressions were widened to avoid one-bit addition truncation.

These corrections are code-review changes only. They have not been compiler- or simulator-validated because no HDL compiler/simulator is installed in the execution environment.


## M2.7 retirement-to-rename commit metadata

- ROB entries now retain both the newly allocated physical destination and the
  previous physical destination alongside the architectural destination.
- Both physical tags are returned with the in-order retirement payload.
- `rename_unit` now maintains a committed RAT distinct from its speculative RAT.
- The dispatch controller advances the committed RAT only on accepted,
  non-exception retirement handshakes, and frees the old physical mapping at
  that same commit point.
- Same-cycle dual retirement to the same architectural register is applied in
  lane order, so the younger lane's mapping becomes the final committed mapping.
- The committed RAT is not overwritten by speculative flush; the speculative
  RAT remains restored from the externally selected branch checkpoint.

## Remaining correctness work

- The branch checkpoint manager must capture and restore the speculative RAT
  and free-list bitmap atomically at a precise ROB boundary.
- Exception retirement must be integrated with a trap controller that flushes
  younger operations and restores the correct architectural state.
- The committed RAT and free-list path needs directed simulation and formal
  checks for repeated destinations, dual retire, flush/commit overlap, and
  physical-tag uniqueness.
- No HDL compiler or simulator is installed in this environment; the changes
  are source-reviewed and covered by conservative static checks only.

- Commit-map/free-list updates are additionally gated by the ROB kind's
  `writes_rd` bit, preventing non-writing instructions with a nonzero decoded
  `rd` field from corrupting the committed RAT.

- Added `tb_rename_commit_map.sv` for committed-vs-speculative RAT separation,
  x0 invariance, retirement mapping update and old-tag free behavior. It is
  authored but unexecuted because no HDL simulator is installed.

- Free-list policy corrected: physical register p0 is permanently reserved;
  initial mappings p1..p31 start reserved but become reclaimable after their
  replacement commits. The restore bitmap is masked only at p0, and the
  allocator scans all nonzero physical tags. This avoids permanently leaking
  the 31 initial architectural mappings.

## M2.8 precise exception boundary and branch checkpoint storage

- ROB retirement now blocks lane 1 whenever the oldest/head entry carries an
  exception. The faulting head may be accepted for trap handling, but no
  younger instruction can retire in the same cycle.
- Added `rtl/rename/branch_checkpoint_manager.sv`. It captures speculative RAT
  and free-list bitmap snapshots on an accepted capture handshake, returns the
  selected snapshot on recovery, removes the mispredicted branch checkpoint
  and all younger checkpoints, and retains older checkpoints.
- Added directed testbenches:
  - `tb_rob_precise_exception.sv`: oldest-entry exception must suppress the
    younger retirement lane.
  - `tb_branch_checkpoint_manager.sv`: captures two snapshots, restores the
    older selected snapshot, and checks younger checkpoint invalidation.
- Added static source-contract checks for exception gating and checkpoint
  capture/restore/age-discard behavior.

### Integration boundary / not yet complete

The checkpoint manager is a standalone RTL block in this phase. The dispatch
controller does not yet allocate checkpoint IDs into branch ROB metadata, and
there is no branch-resolution/trap controller wiring `recover_id`, restore
snapshots, and the ROB's selective recovery. The current ROB still exposes a
whole-ROB `flush`; therefore branch recovery that preserves older in-flight
instructions is not yet implemented end-to-end. Exception retirement also
still needs a trap controller to select the architectural trap PC/cause and
flush younger state. The new testbenches are authored but unexecuted.


## Phase 16 — tagged branch recovery plumbing and selective squash

- Reworked `branch_checkpoint_manager` to key snapshots by the full ROB tag and
  retain a 32-bit global dispatch sequence. Correctly resolved branches release
  only their own checkpoint; a misprediction restores that checkpoint and
  discards it plus all younger checkpoints while preserving older unresolved
  branches.
- `rename_unit` now exposes per-lane post-rename RAT and free-list snapshots.
  `free_list` includes same-cycle accepted allocations and older commit frees in
  each lane snapshot, so a lane-0 branch snapshot excludes younger lane-1 work.
- `mx64_dispatch_controller` now has a dedicated branch/jump dispatch interface,
  captures checkpoints only on accepted control-transfer dispatch, performs a
  full ROB-tag query on resolution, restores rename state on misprediction, and
  exports redirect PC/ROB tag/sequence to the frontend and branch execution unit.
- `reorder_buffer` supports full-tag lookup and selective rollback: it retains all
  older instructions and the branch, invalidates younger entries, advances the
  killed slots' epochs, and moves the tail to the slot after the branch.
- `issue_queue` uses the global dispatch sequence to remove only younger entries
  during recovery while preserving older queued work. It blocks issue/enqueue for
  the one-cycle recovery operation.
- Older committed physical-register frees are merged into every live checkpoint;
  checkpoint state changes only after an explicit valid resolution handshake.
- Branch resolution has backpressure (`branch_resolve_ready`) and accepted branch
  results use a dedicated extra ROB completion port. The destination result is
  separate from the redirect PC so link instructions can return PC+4 correctly.
- Added directed testbench sources for tagged checkpoint lifecycle, selective ROB
  recovery and issue-queue selective recovery. They remain unexecuted.

### Phase 16 integration boundary

The dispatch/backend RTL now exposes the control-transfer and branch-resolution
contracts, but `mx64_top` remains a nonfunctional shell: a branch execution unit,
frontend redirect connection, and the rest of the complete core are not yet
instantiated. No branch-resolution hardware is claimed. The ROB and issue-queue
selective-squash logic is source-reviewed only. HDL compilation/simulation/formal
verification/synthesis remain deferred as previously requested.


## Phase 17 — precise synchronous exception metadata and trap control

- Expanded the exception enum to cover instruction/load/store misalignment,
  access faults and page faults while preserving the previous enum values.
- Added a privileged-profile cause mapper, including U-mode/M-mode ECALL
  cause selection. The numeric mapping and `mtval` policy are documented as a
  proposal, not a frozen ISA commitment.
- The ROB now accepts decode-time exception metadata at allocation, marks such
  entries complete without sending them to an execution queue, and carries the
  exception code and `mtval` value to retirement. Completion-time exception
  metadata is supported for future execution/LSU fault sources.
- Dispatch routes decode exceptions directly to the ROB and prevents them from
  entering the integer issue queue or branch execution interface.
- Added `mx64_trap_controller`: a lane-1 exception waits behind older lane-0
  retirement; only the faulting ROB head triggers the CSR trap pulse, full
  speculative flush and `mtvec` redirect. The trap instruction is not counted
  in `minstret`; normal two-wide retirement increments by 0, 1 or 2.
- `rename_unit` now exports a free bitmap reconstructed from the committed RAT
  for use during trap flush recovery. The wrapper must mux this bitmap and the
  committed RAT into the existing dispatch restore inputs when trap flush is
  asserted.
- Fixed CSR `mcause` concatenation to exactly XLEN bits and aligned `mepc` to
  the four-byte base instruction boundary. CSR `minstret` now accepts a 0..2
  retirement count.
- The issue queue now suppresses issue and enqueue combinationally during a
  full flush, preventing wrong-path work from launching in the same cycle that
  a precise trap is accepted. Its existing recovery testbench now checks this.
- Added `tb_mx64_trap_controller.sv` for lane-1 deferral, head-trap, cause,
  `mtval`, `mepc`, `mtvec`, U/M ECALL mapping and retirement counting, plus
  `tb_mx64_precise_exception.sv` for a ROB-to-trap-CSR path with a decode-time
  exception allocated as an already-complete ROB entry. They are authored but
  unexecuted. `tb_rename_commit_map.sv` also checks the committed free bitmap.

### Phase 17 integration boundary

The trap controller and metadata paths are module-level RTL contracts.
`mx64_top` remains a nonfunctional shell and does not instantiate the CSR,
trap controller, frontend, branch unit or complete backend. Decode/LSU sources
must supply valid exception enum and `exception_value` metadata. The wrapper
must connect `flush_speculative` to the dispatch flush and select the committed
RAT/free bitmap for restoration. Interrupt delivery, MRET privilege-state
restoration, debug traps, LSU-generated exceptions and end-to-end architectural
recovery are not yet implemented. `make check` and `make test` pass, including
83 RTL source-contract checks, but HDL compilation, simulation, formal
verification and synthesis remain deferred.
