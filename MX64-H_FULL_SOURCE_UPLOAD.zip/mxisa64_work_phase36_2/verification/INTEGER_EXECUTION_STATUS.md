# M2.1 integer execution integration status

Added `rtl/execution/integer_execution_cluster.sv`.

## Datapath
- Two-wide dispatch into the existing age-ordered issue queue.
- Two combinational 64-bit integer ALUs.
- One-cycle registered completion outputs carrying ROB tag, destination physical
  tag, destination-write intent and result data.
- Completion buses feed the issue queue's two wakeup ports on the following
  cycle; only destination-producing operations wake source operands.
- Global flush clears queued work and suppresses pending completion-valid bits.

## Contract and limits
- This is an integer-ALU execution slice, not the complete execution backend.
- The caller must dispatch only integer ALU operations. Loads, stores and
  branches must be routed to dedicated units; simulation assertions guard this.
- The ALU result is single-cycle. There is no multi-cycle backpressure, replay,
  exception generation, branch redirect, LSU, divider, multiplier or ROB
  completion handshake yet.
- `completion_valid` is a one-cycle pulse per issued uop. The ROB integration
  must consume both lanes and validate tags/generations.
- A global flush is assumed. Selective branch-age squash is not implemented.
- No HDL compile/simulation/formal pass is claimed in this environment.

## Required next tests
1. ADD/SUB/logic/shift operations produce expected completion values.
2. Two independent uops complete on the same cycle.
3. A dependent uop wakes from a completion and issues no earlier than the
   following cycle in this registered-completion implementation.
4. `writes_dst=0` does not broadcast a wakeup.
5. Flush clears pending completion-valid and issue queue occupancy.
6. ROB tags and destination tags remain lane-aligned.
7. Illegal load/store/branch dispatch trips the simulation assertion.
