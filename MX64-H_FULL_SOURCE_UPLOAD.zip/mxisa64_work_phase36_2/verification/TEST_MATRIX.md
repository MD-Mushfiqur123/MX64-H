# Verification Test Matrix

| ID | Block | Scenario | Expected property |
|---|---|---|---|
| DEC-001 | Decode | Every legal opcode | Correct uop |
| DEC-002 | Decode | Reserved opcode | Illegal instruction |
| ALU-001 | ALU | 0, 1, max, min signed operands | Exact 64-bit result |
| REN-001 | Rename | RAW chain | Correct physical source |
| REN-002 | Rename | WAR/WAW sequence | No false dependency |
| REN-003 | Rename | Two-wide same destination | Program-order mapping |
| REN-004 | Rename | Branch rollback | Exact prior map restored |
| ROB-001 | ROB | Circular wraparound | No overwrite/loss |
| ROB-002 | ROB | Younger completes first | In-order retirement |
| ROB-003 | ROB | Head exception | Younger instructions do not retire |
| IQ-001 | Issue | Operand wakes same cycle | No early/duplicate issue |
| EXE-001 | Execute | Long latency overtaken | Correct tagged writeback |
| BR-001 | Branch | Mispredict with younger uops | Younger state flushed |
| LSU-001 | LSU | Full store-to-load forwarding | Correct loaded value |
| LSU-002 | LSU | Partial byte overlap | Correct merge |
| LSU-003 | LSU | Older store address unresolved | Safe stall/replay |
| CACHE-001 | L1D | Dirty eviction | Writeback preserves data |
| CACHE-002 | L1I | Refill under backpressure | No lost response |
| L2-001 | L2 | Concurrent L1I/L1D requests | Correct arbitration/data |
| MMU-001 | MMU | Non-canonical VA | Precise fault |
| MMU-002 | MMU | Permission failure | No memory side effect |
| FORM-001 | ROB | Retirement ordering | Assertion holds |
| FORM-002 | LSU | Store visibility | No speculative external write |
| FORM-003 | Free list | Allocation/free uniqueness | No duplicate physical tags |
