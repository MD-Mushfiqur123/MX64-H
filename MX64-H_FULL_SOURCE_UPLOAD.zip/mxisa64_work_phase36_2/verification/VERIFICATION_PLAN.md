# MX64 Verification Plan

Version: 1.0-draft

## Verification philosophy

Verification is independent from RTL generation. The verification agent must derive tests from ISA and microarchitecture specifications, not merely mirror implementation code. No test may be weakened or deleted solely to obtain a pass.

## Test layers

### 1. Static checks
- SystemVerilog lint.
- Width/sign warnings.
- Latch detection.
- Multiple-driver detection.
- Unused/undriven signal review.
- CDC review when multiple clock domains are introduced.

### 2. Unit simulation
- Decoder exhaustive legal/illegal encoding tests.
- ALU arithmetic and shift corner cases.
- Physical register file read/write/forwarding.
- Free-list allocation/free invariants.
- RAT rename and recovery.
- ROB allocation, completion, wraparound and retirement.
- Issue queue wakeup/select and flush.
- Multiplier/divider corner cases.
- Branch target and misprediction recovery.
- LSU forwarding, byte masks and replay.
- Cache hit/miss/refill/eviction/writeback.
- TLB permission, canonicality and translation fault.

### 3. Integration simulation
- Dependency chains and independent instruction streams.
- RAW/WAR/WAW dependency stress.
- Dual-issue same-register corner cases.
- Long-latency completion out of order.
- ROB full/empty transitions.
- Branch misprediction with many younger instructions.
- Exception at ROB head with younger completed instructions.
- Load/store alias and partial-overlap cases.
- L1 miss with concurrent requests.
- L1/L2 backpressure and response reordering.
- FENCE/FENCE.I once semantics are frozen.

### 4. Differential testing
Build an executable ISA reference model. Generate constrained-random instruction streams and compare committed architectural state and memory against the RTL. The reference model must be independently implemented and reviewed.

### 5. Formal properties
Required properties include:
- x0 always reads zero.
- No instruction retires more than once.
- Retirement order is strictly increasing by program age.
- No younger instruction retires past an older incomplete or faulting instruction.
- A killed instruction never writes architectural state.
- A speculative store never reaches external memory before commit.
- ROB occupancy remains within bounds.
- Free-list entries are neither duplicated nor simultaneously allocated and free.
- Physical destination tags are not reused while live.
- Every accepted request receives exactly one response or an explicit cancellation.
- Cache dirty data is not silently discarded.
- Flush eventually removes all younger speculative entries.
- Valid/ready payload stability under backpressure.

Liveness properties require bounded assumptions about downstream readiness; document those assumptions.

### 6. Synthesis and physical verification
- Synthesis elaboration and mapped-netlist checks.
- No unintended latches or black boxes.
- Area and timing report review.
- SRAM macro mapping review.
- Formal equivalence where supported.
- STA across all required PVT corners.
- DRC/LVS/antenna/density signoff under selected foundry decks.

## Coverage model

Track:
- Instruction opcode and operand corner coverage.
- Register dependency patterns.
- ROB occupancy bins.
- Issue queue occupancy bins.
- Branch prediction outcome and recovery depth.
- LSU overlap/forwarding patterns.
- Cache hit/miss/eviction and dirty-line coverage.
- TLB hit/miss/fault coverage.
- Exception and interrupt boundary coverage.

Coverage closure requires a reviewed plan; a raw percentage alone is not acceptance.

## Release gates

A milestone is accepted only when:
1. Spec is versioned and reviewed.
2. Tests are reproducible from a clean checkout.
3. All required tests pass with recorded tool versions and exit codes.
4. No unresolved critical failures remain.
5. Coverage gaps are documented and accepted.
6. Independent reviewer signs off.
