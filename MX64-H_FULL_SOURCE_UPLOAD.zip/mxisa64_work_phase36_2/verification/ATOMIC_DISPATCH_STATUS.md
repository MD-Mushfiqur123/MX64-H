# M2.3 atomic dispatch status

Added `rtl/core/mx64_dispatch_controller.sv` and changed the issue queue
enqueue-ready contract to report capacity independently of valid.

## Intended atomic handshake
- Rename proposes up to two in-order uops.
- IQ capacity is exposed through a standard ready signal.
- ROB allocation valid is gated by rename-valid and IQ-ready.
- IQ dispatch valid is gated by rename-valid and ROB-ready.
- Rename advances only when both ROB and IQ accept the lane.
- ROB tags are packed into the issue uop before enqueue.

## Important limitations / review findings
- This is a first integration draft and has not been compiled or simulated.
- The controller assumes `rename_unit`'s packed lane-array ports and current
  `decoded_uop_t` layout.
- `src1_ready/src2_ready/src1_value/src2_value` must be supplied by a PRF and
  bypass network. This controller does not instantiate the PRF.
- Commit freeing of old physical mappings is externally supplied. The current
  ROB does not yet retain old physical destination tags, so automatic commit
  free is not wired.
- The current backend assertion checks same-lane ROB allocation handshake.
- Branches, loads, stores and jumps are not valid integer-ALU dispatches; they
  must be steered to their dedicated execution units before this controller is
  used as a complete dispatch path.
- Rename/free-list checkpoint restoration must be sourced from a matching
  speculative checkpoint; a generic flush must not blindly restore stale state.
- Full two-wide lane ordering, simultaneous RAT dependencies, free-list
  exhaustion and ROB/IQ backpressure require directed simulation/formal tests.

## Required next verification
1. Decode lane 0 writing x5 and lane 1 reading x5; confirm lane 1 sees lane 0's
   newly allocated physical mapping.
2. Stall ROB and then stall IQ separately; confirm no partial allocation.
3. Exhaust free physical registers; confirm rename stalls without corrupting RAT.
4. Verify x0 always maps to physical zero and never allocates a destination.
5. Verify two accepted lanes allocate two unique ROB and physical tags.
6. Confirm no ROB entry leaks when IQ is full and no IQ entry leaks when ROB full.

## Additional free-list handshake correction
- Added `alloc_take` to the free-list interface. Candidate tags can be previewed
  combinationally, but a physical register is removed from the free bitmap only
  when the corresponding rename lane actually handshakes. This prevents a
  stalled rename lane from leaking a physical register.
- This correction itself still requires simulator/formal validation.

- ROB allocation now permits lane 1 to allocate at the current tail when lane 0
  is invalid, while preserving in-order dual-lane allocation when lane 0 is
  valid. This supports sparse valid masks without silently dropping lane 1.
